import os
import xml.etree.ElementTree as ET
import datetime
from pathlib import Path
import re

def analyze_xml_files(directory_path):
    """Analyzes all XML files in the given directory and extracts their content."""
    results = {}
    
    try:
        if not os.path.exists(directory_path):
            print(f"Error: Directory not found: {directory_path}")
            return results, False
        
        xml_files = [f for f in os.listdir(directory_path) if f.endswith('.xml')]
        
        if not xml_files:
            print(f"No XML files found in: {directory_path}")
            return results, True
        
        for xml_file in xml_files:
            file_path = os.path.join(directory_path, xml_file)
            file_data = {}
            
            try:
                tree = ET.parse(file_path)
                root = tree.getroot()
                
                for child in root:
                    if 'name' in child.attrib:
                        name = child.attrib['name']
                        value = child.text if child.text else ""
                        value_type = child.tag
                        
                        file_data[name] = {
                            "value": value,
                            "type": value_type
                        }
                
                results[xml_file] = {
                    "data": file_data,
                    "file_path": file_path,
                    "file_exists": True
                }
                
            except Exception as e:
                print(f"Error analyzing {file_path}: {e}")
                results[xml_file] = {
                    "data": {},
                    "file_path": file_path,
                    "file_exists": os.path.exists(file_path),
                    "error": str(e)
                }
        
        return results, True
        
    except Exception as e:
        print(f"General error: {e}")
        return results, False

def get_preference_description(name):
    """Returns a human-readable description for common Android preference names."""
    descriptions = {
        "dark_mode": "Dark Mode Setting / Configuración de Modo Oscuro",
        "night_mode": "Night Mode Setting / Configuración de Modo Nocturno",
        "bluetooth": "Bluetooth Settings / Configuración de Bluetooth",
        "wifi": "Wi-Fi Settings / Configuración de Wi-Fi",
        "location": "Location Settings / Configuración de Ubicación",
        "volume": "Volume Settings / Configuración de Volumen",
        "sound": "Sound Settings / Configuración de Sonido",
        "brightness": "Brightness Settings / Configuración de Brillo",
        "language": "Language Settings / Configuración de Idioma",
        "time": "Time Settings / Configuración de Hora",
        "notification": "Notification Settings / Configuración de Notificaciones",
        "battery": "Battery Settings / Configuración de Batería",
        "data": "Data Usage Settings / Configuración de Uso de Datos",
        "security": "Security Settings / Configuración de Seguridad"
    }
    
    if name in descriptions:
        return descriptions[name]
    
    for key, desc in descriptions.items():
        if key in name.lower():
            return desc
    
    return "Setting Value / Valor de Configuración"

def categorize_preference(name):
    """Categorizes preferences based on name patterns"""
    name_lower = name.lower()
    
    categories = {
        "Display": ["dark", "display", "brightness", "screen", "theme", "night"],
        "Network": ["wifi", "bluetooth", "data", "network", "mobile", "airplane"],
        "Sound": ["sound", "volume", "audio", "vibration", "ringtone"],
        "Security": ["lock", "password", "pin", "pattern", "fingerprint", "security"],
        "System": ["language", "time", "date", "timezone", "battery", "storage"],
        "User": ["account", "user", "profile"],
        "App Settings": ["app", "application", "permission", "notification"]
    }
    
    for category, patterns in categories.items():
        for pattern in patterns:
            if pattern in name_lower:
                return category
    
    return "Miscellaneous"

def analyze_preference_value(value, value_type):
    """Analyzes the value of a preference and returns insights"""
    if value_type == "boolean":
        return "Enabled / Habilitado" if value.lower() in ["true", "1"] else "Disabled / Deshabilitado"
    
    if value_type in ["int", "long", "float"]:
        try:
            num_value = float(value)
            if num_value == 0:
                return "Value: 0 (Disabled / Deshabilitado)"
            elif num_value == 1:
                return "Value: 1 (Enabled / Habilitado)"
            elif num_value > 1000000000:  # Timestamp check
                try:
                    date = datetime.datetime.fromtimestamp(num_value/1000)
                    return f"Timestamp: {date.strftime('%Y-%m-%d %H:%M:%S')}"
                except:
                    return f"Numeric value: {value}"
            else:
                return f"Numeric value: {value}"
        except ValueError:
            return f"Value: {value}"
    
    if value_type == "string":
        if re.match(r'^#[0-9a-fA-F]{6,8}$', value):
            return f"Color value: {value}"
        elif re.match(r'^\d{4}-\d{2}-\d{2}', value):
            return f"Date value: {value}"
        else:
            return f"Text value: {value}"
    
    return f"Value: {value}"

def generate_html_report(results, directory_info, output_path):
    """Generates an HTML report with the analyzed XML files"""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    directory_path, directory_exists = directory_info
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    file_count = len(results)

    # Generate colors for different categories
    category_colors = {
        "Display": "#3498db", "Network": "#2ecc71", "Sound": "#e74c3c",
        "Security": "#f39c12", "System": "#9b59b6", "User": "#1abc9c",
        "App Settings": "#d35400", "Miscellaneous": "#7f8c8d"
    }
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Android Shared Preferences Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50; --primary: #34495e; --primary-light: #4a6278;
            --accent: #3498db; --accent-light: #5dade2; --text: #ecf0f1;
            --text-secondary: #bdc3c7; --background: #0b0b1a; --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1); --success: #27ae60;
            --warning: #f39c12; --danger: #e74c3c; --grid-line: rgba(52, 152, 219, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Montserrat', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(52, 152, 219, 0.03) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(52, 152, 219, 0.02) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.3;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Orbitron', sans-serif; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .stat-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}

        .stat-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .stat-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;
        }}

        .stat-value {{ font-size: 2rem; font-weight: 700; color: var(--accent-light); }}

        .source-container {{ margin-top: 2rem; margin-bottom: 2rem; }}

        .source-card {{
            background-color: var(--primary); border-radius: 12px;
            padding: 1.5rem; margin-bottom: 1.5rem; border-left: 4px solid var(--accent);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); position: relative; overflow: hidden;
        }}

        .source-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}

        .source-title {{
            font-family: 'Orbitron', sans-serif; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; display: flex; align-items: center;
        }}

        .source-path {{
            font-family: monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem;
            width: 100%; overflow-x: auto; margin-top: 0.5rem; white-space: nowrap;
        }}

        .source-status {{
            font-size: 0.8rem; padding: 0.3rem 0.8rem; border-radius: 12px;
            font-weight: 600; letter-spacing: 0.5px;
        }}

        .source-found {{ background-color: var(--success); color: var(--text); }}
        .source-not-found {{ background-color: var(--danger); color: var(--text); }}

        .preferences-container {{ margin-top: 1.5rem; }}

        .preference-card {{
            background-color: var(--card-bg); border-radius: 8px; padding: 1rem;
            margin-bottom: 1rem; border-left: 4px solid var(--accent);
            transition: transform 0.2s ease, box-shadow 0.2s ease; position: relative; overflow: hidden;
        }}

        .preference-card:hover {{ transform: translateX(5px); box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2); }}

        .preference-name {{
            font-weight: 600; color: var(--accent-light); font-size: 1.1rem;
            margin-bottom: 0.3rem; display: flex; align-items: center;
        }}

        .preference-type {{
            font-size: 0.75rem; color: var(--text-secondary); background-color: rgba(255, 255, 255, 0.1);
            padding: 0.2rem 0.5rem; border-radius: 10px; margin-left: 0.5rem;
            text-transform: uppercase; letter-spacing: 0.5px;
        }}

        .preference-value {{
            font-family: monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem; word-break: break-all;
        }}

        .preference-description {{ font-size: 0.9rem; color: var(--text-secondary); margin-top: 0.5rem; }}
        .data-insight {{ margin-top: 0.5rem; font-size: 0.9rem; color: var(--accent-light); font-style: italic; }}
        .category-badge {{ padding: 0.2rem 0.6rem; border-radius: 10px; font-size: 0.75rem; font-weight: 600; }}

        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}

        .error-message {{ color: var(--danger); margin-top: 0.5rem; font-style: italic; font-size: 0.9rem; }}
        .search-bar {{
            background-color: var(--primary-dark); border: 1px solid var(--border-color);
            border-radius: 30px; padding: 0.8rem 1.5rem; width: 100%; max-width: 600px;
            margin: 1rem auto 2rem; display: block; color: var(--text);
            font-family: 'Montserrat', sans-serif; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }}

        .expandable-toggle {{
            background-color: var(--primary-dark); color: var(--text); border: none;
            width: 100%; text-align: left; padding: 0.8rem; border-radius: 8px;
            margin-bottom: 0.5rem; cursor: pointer; display: flex;
            justify-content: space-between; align-items: center; font-weight: 600;
        }}

        .expandable-content {{ display: none; padding: 0.5rem; background-color: rgba(0, 0, 0, 0.1); border-radius: 0 0 8px 8px; }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .source-header {{ flex-direction: column; align-items: flex-start; }}
            .source-status {{ margin-top: 0.5rem; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Android Shared Preferences Analysis</h1>
            <p class="subtitle">📅 Generated on {now} | Generado el {now}</p>
        </div>

        <!-- Dashboard Stats -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-label">Files Analyzed / Archivos Analizados</div>
                <div class="stat-value">{file_count}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Directory / Directorio</div>
                <div class="stat-value">{os.path.basename(directory_path)}</div>
            </div>
        </div>

        <!-- Search Bar -->
        <input type="text" id="searchInput" placeholder="Search preferences... / Buscar preferencias..." class="search-bar">"""

    if not directory_exists:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ Directory not found / Directorio no encontrado</div>
            <p>The specified directory could not be found. | El directorio especificado no pudo ser encontrado.</p>
        </div>"""
    elif not results:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No XML files found / No se encontraron archivos XML</div>
            <p>No XML files were found in the specified directory. | No se encontraron archivos XML en el directorio especificado.</p>
        </div>"""
    else:
        # Process files
        html += """
        <div class="source-container">"""
        
        for file_name, file_info in results.items():
            file_path = file_info["file_path"]
            file_exists = file_info["file_exists"]
            status_text = "Found / Encontrado" if file_exists else "Not Found / No Encontrado"
            status_class = "source-found" if file_exists else "source-not-found"
            
            html += f"""
            <div class="source-card">
                <div class="source-header">
                    <div class="source-title">
                        <span style="margin-right:10px;">📄</span> {file_name}
                    </div>
                    <span class="source-status {status_class}">{status_text}</span>
                </div>
                <div class="source-path">{file_path}</div>"""
            
            if "error" in file_info:
                html += f"""
                <div class="error-message">Error: {file_info["error"]}</div>"""
            
            if file_exists and "data" in file_info and file_info["data"]:
                html += """
                <div class="preferences-container">"""
                
                # Group preferences by category
                categorized_prefs = {}
                for pref_name, pref_data in file_info["data"].items():
                    category = categorize_preference(pref_name)
                    if category not in categorized_prefs:
                        categorized_prefs[category] = []
                    categorized_prefs[category].append((pref_name, pref_data))
                
                # Create expandable sections for each category
                for category, prefs in categorized_prefs.items():
                    color = category_colors.get(category, "#7f8c8d")
                    
                    html += f"""
                    <div class="expandable-section">
                        <button class="expandable-toggle" onclick="toggleSection(this)">
                            {category} ({len(prefs)})
                        </button>
                        <div class="expandable-content">"""
                    
                    for pref_name, pref_data in prefs:
                        pref_value = pref_data.get("value", "")
                        pref_type = pref_data.get("type", "")
                        description = get_preference_description(pref_name)
                        insight = analyze_preference_value(pref_value, pref_type)
                        
                        html += f"""
                        <div class="preference-card" data-category="{category}">
                            <div class="preference-name">
                                {pref_name}
                                <span class="preference-type">{pref_type}</span>
                            </div>
                            <div class="preference-value">{pref_value}</div>
                            <div class="preference-description">{description}</div>
                            <div class="data-insight">{insight}</div>
                            <span class="category-badge" style="background-color:{color};">{category}</span>
                        </div>"""
                    
                    html += """
                        </div>
                    </div>"""
                
                html += """
                </div>"""
            
            html += """
            </div>"""
        
        html += """
        </div>"""

    # Footer
    html += f"""
        <div class="footer">
            <p>📁 Report path / Ruta del informe: <code id="reportPath">{output_path}</code></p>
            <p>📁 Directory analyzed / Directorio analizado: <code>{directory_path}</code></p>
            <p>ForenSage © 2025 - Android Forensic Tool</p>
        </div>
    </div>

   <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('input', function() {{
            let searchTerm = this.value.toLowerCase();
            let cards = document.querySelectorAll('.preference-card');
            
            cards.forEach(card => {{
                let prefName = card.querySelector('.preference-name').textContent.toLowerCase();
                let prefValue = card.querySelector('.preference-value').textContent.toLowerCase();
                
                if (prefName.includes(searchTerm) || prefValue.includes(searchTerm)) {{
                    card.style.display = 'block';
                    // Make sure parent expandable section is open
                    let parent = card.closest('.expandable-content');
                    if (parent) {{
                        parent.style.display = 'block';
                        let toggle = parent.previousElementSibling;
                        toggle.classList.add('active');
                    }}
                }} else {{
                    card.style.display = 'none';
                }}
            }});
        }});

        // Toggle expandable sections
        function toggleSection(el) {{
            el.classList.toggle('active');
            let content = el.nextElementSibling;
            content.style.display = content.style.display === 'block' ? 'none' : 'block';
        }}

        // Set absolute path for report
        document.getElementById('reportPath').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # Directory to analyze
    directory_to_analyze = "/media/adrian/data/data/com.android.settings/shared_prefs"
    
    # For output, create relative path
    base_path = Path.home() / "ForenSage"
    output_html = base_path / "results/amecho_divice_info.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    # Analyze XML files
    results, directory_exists = analyze_xml_files(directory_to_analyze)
    
    # Generate HTML report
    generate_html_report(results, (directory_to_analyze, directory_exists), str(output_html))

if __name__ == "__main__":
    main()