import os
import datetime
from pathlib import Path
import re

def analyze_bt_config(file_path):
    """Analyzes a Bluetooth configuration file and extracts its content without assumptions."""
    results = {}
    
    try:
        if not os.path.exists(file_path):
            print(f"Error: File not found: {file_path}")
            return results, False
        
        with open(file_path, 'r', errors='replace') as f:
            content = f.readlines()
        
        bt_data = {}
        current_section = "General"
        
        for line in content:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
                
            # Try to parse the line based on common formats
            if '=' in line:
                # Key-value format
                parts = line.split('=', 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    value = parts[1].strip()
                    
                    # Remove quotes if present
                    if value.startswith('"') and value.endswith('"'):
                        value = value[1:-1]
                    
                    bt_data[key] = {
                        "value": value,
                        "section": current_section,
                        "type": detect_value_type(value)
                    }
            elif '[' in line and ']' in line:
                # Section header format [Section]
                section_match = re.match(r'\[(.*?)\]', line)
                if section_match:
                    current_section = section_match.group(1)
                    bt_data[f"SECTION_{current_section}"] = {
                        "value": "",
                        "section": "Structure",
                        "type": "section_header"
                    }
            elif line.endswith(':'):
                # Colon-terminated section header
                current_section = line[:-1].strip()
                bt_data[f"SECTION_{current_section}"] = {
                    "value": "",
                    "section": "Structure",
                    "type": "section_header"
                }
            else:
                # Handle space-separated key-value or standalone entries
                parts = line.split(None, 1)
                if len(parts) > 1:
                    key = parts[0].strip()
                    value = parts[1].strip()
                    bt_data[key] = {
                        "value": value,
                        "section": current_section,
                        "type": detect_value_type(value)
                    }
                else:
                    # Standalone entry
                    bt_data[f"ENTRY_{line}"] = {
                        "value": line,
                        "section": current_section,
                        "type": "standalone"
                    }
        
        results["bt_config"] = {
            "data": bt_data,
            "file_path": file_path,
            "file_exists": True
        }
        
        return results, True
        
    except Exception as e:
        print(f"Error analyzing {file_path}: {e}")
        return {"bt_config": {
            "data": {},
            "file_path": file_path,
            "file_exists": os.path.exists(file_path),
            "error": str(e)
        }}, False

def detect_value_type(value):
    """Detects the type of a value without making domain-specific assumptions."""
    if not value:
        return "empty"
        
    # Boolean check
    if value.lower() in ['true', 'false', 'yes', 'no', 'on', 'off', '0', '1']:
        return "boolean_like"
    
    # Number check
    if re.match(r'^-?\d+$', value):
        return "integer"
        
    if re.match(r'^-?\d+\.\d+$', value):
        return "float"
    
    # Hexadecimal check
    if re.match(r'^0x[0-9a-fA-F]+$', value):
        return "hexadecimal"
    
    # MAC address pattern check (multiple formats)
    if re.match(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$', value) or re.match(r'^[0-9A-Fa-f]{12}$', value):
        return "mac_address"
    
    # UUID pattern check
    if re.match(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$', value):
        return "uuid"
    
    # JSON-like check
    if (value.startswith('{') and value.endswith('}')) or (value.startswith('[') and value.endswith(']')):
        return "json_like"
    
    # Path-like check
    if '/' in value and not ' ' in value:
        return "path_like"
    
    # Default to string
    return "string"

def categorize_entry(key, value_type):
    """Categorizes entries based on observed patterns without domain assumptions"""
    key_lower = key.lower()
    
    # Simple keyword-based categorization
    if key_lower.startswith('section_'):
        return "File Structure"
    
    if value_type == "mac_address":
        return "Hardware Identifiers"
        
    if value_type == "uuid":
        return "Service Identifiers"
        
    if "time" in key_lower or "date" in key_lower:
        return "Time Settings"
        
    if "version" in key_lower:
        return "Version Information"
        
    if "name" in key_lower:
        return "Name Identifiers"
        
    if "path" in key_lower or value_type == "path_like":
        return "File Paths"
        
    if "enable" in key_lower or "disable" in key_lower or value_type == "boolean_like":
        return "Feature Flags"
        
    # Default category
    return "Configuration Values"

def generate_amecho_bt_html(results, file_info, output_path):
    """Generates an HTML report with the analyzed Bluetooth configuration file"""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    file_path, file_exists = file_info
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Generate colors for different categories
    category_colors = {
        "File Structure": "#3498db", 
        "Hardware Identifiers": "#2ecc71", 
        "Service Identifiers": "#e74c3c",
        "Time Settings": "#f39c12", 
        "Version Information": "#9b59b6", 
        "Name Identifiers": "#1abc9c",
        "File Paths": "#d35400", 
        "Feature Flags": "#8e44ad",
        "Configuration Values": "#7f8c8d"
    }
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bluetooth Configuration Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50; --primary: #34495e; --primary-light: #4a6278;
            --accent: #3498db; --accent-light: #5dade2; --text: #ecf0f1;
            --text-secondary: #bdc3c7; --background: #0b0b1a; --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1); --success: #27ae60;
            --warning: #f39c12; --danger: #e74c3c; --grid-line: rgba(52, 152, 219, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Montserrat', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(52, 152, 219, 0.03) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(52, 152, 219, 0.02) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.3;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Orbitron', sans-serif; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .stat-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}

        .stat-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .stat-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;
        }}

        .stat-value {{ font-size: 2rem; font-weight: 700; color: var(--accent-light); }}

        .source-container {{ margin-top: 2rem; margin-bottom: 2rem; }}

        .source-card {{
            background-color: var(--primary); border-radius: 12px;
            padding: 1.5rem; margin-bottom: 1.5rem; border-left: 4px solid var(--accent);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); position: relative; overflow: hidden;
        }}

        .source-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}

        .source-title {{
            font-family: 'Orbitron', sans-serif; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; display: flex; align-items: center;
        }}

        .source-path {{
            font-family: monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem;
            width: 100%; overflow-x: auto; margin-top: 0.5rem; white-space: nowrap;
        }}

        .source-status {{
            font-size: 0.8rem; padding: 0.3rem 0.8rem; border-radius: 12px;
            font-weight: 600; letter-spacing: 0.5px;
        }}

        .source-found {{ background-color: var(--success); color: var(--text); }}
        .source-not-found {{ background-color: var(--danger); color: var(--text); }}

        .bt-property-container {{ margin-top: 1.5rem; }}

        .bt-property-card {{
            background-color: var(--card-bg); border-radius: 8px; padding: 1rem;
            margin-bottom: 1rem; border-left: 4px solid var(--accent);
            transition: transform 0.2s ease, box-shadow 0.2s ease; position: relative; overflow: hidden;
        }}

        .bt-property-card:hover {{ transform: translateX(5px); box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2); }}

        .bt-property-name {{
            font-weight: 600; color: var(--accent-light); font-size: 1.1rem;
            margin-bottom: 0.3rem; display: flex; align-items: center;
        }}

        .bt-property-type {{
            font-size: 0.75rem; color: var(--text-secondary); background-color: rgba(255, 255, 255, 0.1);
            padding: 0.2rem 0.5rem; border-radius: 10px; margin-left: 0.5rem;
            text-transform: uppercase; letter-spacing: 0.5px;
        }}

        .bt-property-value {{
            font-family: monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem; word-break: break-all;
        }}

        .bt-property-section {{
            font-size: 0.85rem; color: var(--text-secondary); margin-top: 0.5rem;
            background-color: rgba(0, 0, 0, 0.15); padding: 0.2rem 0.5rem; border-radius: 4px;
            display: inline-block;
        }}

        .category-badge {{ padding: 0.2rem 0.6rem; border-radius: 10px; font-size: 0.75rem; font-weight: 600; }}

        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}

        .error-message {{ color: var(--danger); margin-top: 0.5rem; font-style: italic; font-size: 0.9rem; }}
        
        .category-section {{
            margin-bottom: 2rem;
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            padding: 1rem;
        }}
        
        .category-title {{
            font-family: 'Orbitron', sans-serif;
            color: var(--text);
            font-size: 1.2rem;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid var(--border-color);
        }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .source-header {{ flex-direction: column; align-items: flex-start; }}
            .source-status {{ margin-top: 0.5rem; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Bluetooth Configuration Analysis</h1>
            <p class="subtitle">📅 Generated on {now} | Generado el {now}</p>
        </div>

        <!-- Dashboard Stats -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-label">File / Archivo</div>
                <div class="stat-value">bt_config.conf</div>
            </div>"""
            
    # Get entry count
    entry_count = 0
    if file_exists and "bt_config" in results and "data" in results["bt_config"]:
        entry_count = len(results["bt_config"]["data"])
            
    html += f"""            
            <div class="stat-card">
                <div class="stat-label">Entries / Entradas</div>
                <div class="stat-value">{entry_count}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Status / Estado</div>
                <div class="stat-value">{("✓" if file_exists else "✗")}</div>
            </div>
        </div>"""

    if not file_exists:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ File not found / Archivo no encontrado</div>
            <p>The specified Bluetooth configuration file could not be found. | El archivo de configuración Bluetooth especificado no pudo ser encontrado.</p>
        </div>"""
    else:
        # Process file
        html += """
        <div class="source-container">"""
        
        file_info = results.get("bt_config", {})
        status_text = "Found / Encontrado" if file_exists else "Not Found / No Encontrado"
        status_class = "source-found" if file_exists else "source-not-found"
        
        html += f"""
        <div class="source-card">
            <div class="source-header">
                <div class="source-title">
                    <span style="margin-right:10px;">📄</span> bt_config.conf
                </div>
                <span class="source-status {status_class}">{status_text}</span>
            </div>
            <div class="source-path">{file_path}</div>"""
        
        if "error" in file_info:
            html += f"""
            <div class="error-message">Error: {file_info["error"]}</div>"""
        
        if file_exists and "data" in file_info and file_info["data"]:
            # Group properties by category
            categorized_props = {}
            for prop_name, prop_data in file_info["data"].items():
                prop_value = prop_data.get("value", "")
                prop_type = prop_data.get("type", "")
                category = categorize_entry(prop_name, prop_type)
                
                if category not in categorized_props:
                    categorized_props[category] = []
                    
                categorized_props[category].append((prop_name, prop_data))
            
            # Create sections for each category
            for category, props in categorized_props.items():
                color = category_colors.get(category, "#7f8c8d")
                
                html += f"""
                <div class="category-section">
                    <div class="category-title" style="color:{color};">
                        {category} ({len(props)})
                    </div>
                    <div class="bt-property-container">"""
                
                for prop_name, prop_data in props:
                    prop_value = prop_data.get("value", "")
                    prop_type = prop_data.get("type", "")
                    prop_section = prop_data.get("section", "")
                    
                    html += f"""
                    <div class="bt-property-card">
                        <div class="bt-property-name">
                            {prop_name}
                            <span class="bt-property-type">{prop_type}</span>
                        </div>
                        <div class="bt-property-value">{prop_value}</div>
                        <div class="bt-property-section">Section: {prop_section}</div>
                        <span class="category-badge" style="background-color:{color};">{category}</span>
                    </div>"""
                
                html += """
                    </div>
                </div>"""
        
        html += """
        </div>"""
    
    # Footer
    html += f"""
        <div class="footer">
            <p>📁 Report path / Ruta del informe: <code id="reportPath">{output_path}</code></p>
            <p>📁 File analyzed / Archivo analizado: <code>{file_path}</code></p>
            <p>ForenSage © 2025 - Android Forensic Tool</p>
        </div>
    </div>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # File to analyze
    file_to_analyze = "/home/adrian/ForenSage/analyze/amecho/bt_config.conf"
    
    # For output, create relative path
    base_path = Path.home() / "ForenSage"
    output_html = base_path / "results/amecho_bt_info.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    # Analyze BT config file
    results, file_exists = analyze_bt_config(file_to_analyze)
    
    # Generate HTML report
    generate_amecho_bt_html(results, (file_to_analyze, file_exists), str(output_html))

if __name__ == "__main__":
    main()