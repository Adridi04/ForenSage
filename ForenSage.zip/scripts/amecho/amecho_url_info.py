import os
import sqlite3
import datetime
from pathlib import Path
import re
import urllib.parse

def analyze_history_database(db_path):
    """Analyzes the history database and extracts URLs from the urls table."""
    results = {}
    
    try:
        if not os.path.exists(db_path):
            print(f"Error: Database file not found: {db_path}")
            return results, False
        
        try:
            # Connect to the SQLite database
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Get the table structure
            cursor.execute("PRAGMA table_info(urls)")
            columns = cursor.fetchall()
            column_names = [column[1] for column in columns]
            
            # Check if 'urls' table exists
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='urls'")
            if not cursor.fetchone():
                print(f"No 'urls' table found in: {db_path}")
                conn.close()
                return results, True
            
            # Get all URLs data
            cursor.execute("SELECT * FROM urls")
            rows = cursor.fetchall()
            
            # Structure the data
            results["metadata"] = {
                "columns": column_names,
                "row_count": len(rows),
                "file_path": db_path,
                "file_exists": True
            }
            
            # Process URL entries
            results["entries"] = []
            for row in rows:
                entry = {}
                for i, column_name in enumerate(column_names):
                    entry[column_name] = row[i]
                
                # Add analysis data
                entry["analysis"] = analyze_url_entry(entry)
                results["entries"].append(entry)
            
            conn.close()
            return results, True
            
        except sqlite3.Error as e:
            print(f"SQLite error: {e}")
            return {"error": str(e), "file_path": db_path, "file_exists": os.path.exists(db_path)}, True
            
    except Exception as e:
        print(f"General error: {e}")
        return {"error": str(e), "file_path": db_path}, False

def analyze_url_entry(entry):
    """Analyzes a URL entry and extracts insights."""
    analysis = {}
    
    # Process URL
    if "url" in entry:
        url = entry["url"]
        
        # Extract domain
        try:
            parsed_url = urllib.parse.urlparse(url)
            domain = parsed_url.netloc
            analysis["domain"] = domain
            
            # Identify protocol
            analysis["protocol"] = parsed_url.scheme if parsed_url.scheme else "unknown"
            
            # Extract path
            analysis["path"] = parsed_url.path
            
            # Extract query parameters
            if parsed_url.query:
                query_params = urllib.parse.parse_qs(parsed_url.query)
                analysis["query_params"] = query_params
                analysis["query_param_count"] = len(query_params)
            
            # Check for tracking parameters
            tracking_params = ['utm_source', 'utm_medium', 'utm_campaign', 'ref', 'fbclid', 'gclid']
            found_tracking = [param for param in tracking_params if param in str(parsed_url.query).lower()]
            if found_tracking:
                analysis["tracking_params"] = found_tracking
        except:
            analysis["parsing_error"] = "Could not parse URL"
    
    # Process timestamp if available
    if "last_visit_time" in entry:
        try:
            # Chrome's timestamp is microseconds since January 1, 1601
            chrome_epoch = datetime.datetime(1601, 1, 1)
            if isinstance(entry["last_visit_time"], int) and entry["last_visit_time"] > 0:
                # Convert to datetime
                visit_time = chrome_epoch + datetime.timedelta(microseconds=entry["last_visit_time"])
                analysis["visit_datetime"] = visit_time.strftime("%Y-%m-%d %H:%M:%S")
        except:
            analysis["timestamp_error"] = "Could not process timestamp"
    
    # Categorize the URL
    analysis["category"] = categorize_url(entry.get("url", ""))
    
    return analysis

def categorize_url(url):
    """Categorizes URLs based on patterns."""
    url_lower = url.lower()
    
    categories = {
        "Social Media": ["facebook.com", "twitter.com", "instagram.com", "linkedin.com", "tiktok.com", "pinterest", "reddit"],
        "Search Engine": ["google.com/search", "bing.com/search", "search.yahoo", "duckduckgo", "baidu.com"],
        "Video": ["youtube.com", "vimeo.com", "netflix", "hulu", "twitch.tv", "dailymotion"],
        "Shopping": ["amazon", "ebay", "walmart", "target.com", "etsy.com", "aliexpress", "shopping"],
        "News": ["cnn.com", "bbc", "nytimes", "reuters", "news", "washingtonpost"],
        "Email": ["gmail", "outlook", "yahoo.com/mail", "protonmail", "mail."],
        "Banking": ["bank", "chase.com", "wellsfargo", "paypal", "wise.com", "finance"],
        "Technology": ["github", "stackoverflow", "techcrunch", "wired.com", "tech", "developer"],
        "Gaming": ["steam", "epicgames", "playstation", "xbox", "nintendo", "game", "gaming"],
        "Travel": ["booking.com", "airbnb", "expedia", "tripadvisor", "hotels", "travel"]
    }
    
    for category, patterns in categories.items():
        for pattern in patterns:
            if pattern in url_lower:
                return category
    
    return "Other"

def get_domain_type(domain):
    """Returns a description based on the domain type."""
    if not domain:
        return "Unknown Domain"
    
    # Top-level domains categorization
    tld_matches = {
        "com": "Commercial",
        "org": "Organization",
        "gov": "Government",
        "edu": "Educational", 
        "net": "Network",
        "io": "Technology",
        "ai": "Artificial Intelligence",
        "dev": "Development"
    }
    
    # Extract TLD
    tld_match = re.search(r'\.([a-z]{2,})$', domain.lower())
    
    if tld_match:
        tld = tld_match.group(1)
        # Country code TLDs
        if len(tld) == 2 and tld not in tld_matches:
            return f"Country-specific ({tld.upper()})"
        return tld_matches.get(tld, "Other Domain")
    
    return "Unknown Domain"

def generate_amecho_url_html(results, db_path, output_path):
    """Generates an HTML report with the analyzed history data."""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Generate colors for different categories
    category_colors = {
        "Social Media": "#3b5998", "Search Engine": "#4285f4", "Video": "#ff0000",
        "Shopping": "#ff9900", "News": "#1d2951", "Email": "#168de2",
        "Banking": "#006f5f", "Technology": "#333333", "Gaming": "#7289da",
        "Travel": "#00a680", "Other": "#7f8c8d"
    }
    
    # Count categories for the dashboard
    category_counts = {}
    domain_counts = {}
    total_entries = 0
    
    if "entries" in results:
        for entry in results["entries"]:
            category = entry["analysis"].get("category", "Other")
            domain = entry["analysis"].get("domain", "unknown")
            
            if category in category_counts:
                category_counts[category] += 1
            else:
                category_counts[category] = 1
                
            if domain in domain_counts:
                domain_counts[domain] += 1
            else:
                domain_counts[domain] = 1
                
            total_entries += 1
    
    # Sort domains by frequency
    top_domains = sorted(domain_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browser History Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50; --primary: #34495e; --primary-light: #4a6278;
            --accent: #3498db; --accent-light: #5dade2; --text: #ecf0f1;
            --text-secondary: #bdc3c7; --background: #0b0b1a; --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1); --success: #27ae60;
            --warning: #f39c12; --danger: #e74c3c; --grid-line: rgba(52, 152, 219, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Montserrat', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(52, 152, 219, 0.03) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(52, 152, 219, 0.02) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.3;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Orbitron', sans-serif; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .stat-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}

        .stat-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .stat-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;
        }}

        .stat-value {{ font-size: 2rem; font-weight: 700; color: var(--accent-light); }}

        .entries-container {{ margin-top: 2rem; margin-bottom: 2rem; }}

        .category-section {{
            background-color: var(--primary); border-radius: 12px;
            padding: 1.5rem; margin-bottom: 1.5rem;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); position: relative; overflow: hidden;
        }}

        .category-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}

        .category-title {{
            font-family: 'Orbitron', sans-serif; font-size: 1.3rem;
            font-weight: 600; display: flex; align-items: center;
        }}

        .entry-card {{
            background-color: var(--card-bg); border-radius: 8px; padding: 1rem;
            margin-bottom: 1rem; border-left: 4px solid var(--accent);
            transition: transform 0.2s ease, box-shadow 0.2s ease; position: relative; overflow: hidden;
        }}

        .entry-card:hover {{ transform: translateX(5px); box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2); }}

        .entry-title {{
            font-weight: 600; color: var(--accent-light); font-size: 1.1rem;
            margin-bottom: 0.3rem; display: flex; align-items: center;
            word-break: break-all;
        }}

        .entry-domain {{
            font-size: 0.75rem; color: var(--text-secondary); background-color: rgba(255, 255, 255, 0.1);
            padding: 0.2rem 0.5rem; border-radius: 10px; margin-left: 0.5rem;
            text-transform: uppercase; letter-spacing: 0.5px;
        }}

        .entry-url {{
            font-family: monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem; word-break: break-all;
        }}

        .entry-details {{ font-size: 0.9rem; color: var(--text-secondary); margin-top: 0.5rem; }}
        .entry-insight {{ margin-top: 0.5rem; font-size: 0.9rem; color: var(--accent-light); font-style: italic; }}
        .category-badge {{ padding: 0.2rem 0.6rem; border-radius: 10px; font-size: 0.75rem; font-weight: 600; }}

        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}

        .error-message {{ color: var(--danger); margin-top: 0.5rem; font-style: italic; font-size: 0.9rem; }}
        
        .expandable-toggle {{
            background-color: var(--primary-dark); color: var(--text); border: none;
            width: 100%; text-align: left; padding: 0.8rem; border-radius: 8px;
            margin-bottom: 0.5rem; cursor: pointer; display: flex;
            justify-content: space-between; align-items: center; font-weight: 600;
        }}

        .expandable-content {{ display: none; padding: 0.5rem; background-color: rgba(0, 0, 0, 0.1); border-radius: 0 0 8px 8px; }}

        .pie-chart {{ height: 250px; width: 250px; margin: 0 auto; position: relative; }}
        .chart-container {{ display: flex; flex-wrap: wrap; justify-content: center; gap: 2rem; margin-bottom: 2rem; }}
        .chart-card {{ background-color: var(--primary); border-radius: 12px; padding: 1.5rem; min-width: 300px; flex: 1; }}
        .chart-title {{ font-size: 1.1rem; text-align: center; margin-bottom: 1rem; color: var(--accent-light); }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .category-header {{ flex-direction: column; align-items: flex-start; }}
        }}

        .time-badge {{
            background-color: var(--primary-dark);
            color: var(--text);
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            margin-left: 0.5rem;
        }}

        .domain-list {{ list-style: none; padding: 0; }}
        .domain-item {{ 
            display: flex; 
            justify-content: space-between; 
            padding: 0.5rem 1rem; 
            margin-bottom: 0.3rem; 
            background-color: rgba(0, 0, 0, 0.2); 
            border-radius: 5px; 
        }}
        .domain-bar {{ 
            background-color: var(--accent); 
            height: 4px; 
            margin-top: 0.3rem; 
            border-radius: 2px; 
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Browser History Analysis</h1>
            <p class="subtitle">📅 Generated on {now}</p>
        </div>

        <!-- Dashboard Stats -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-label">Entries Analyzed</div>
                <div class="stat-value">{total_entries}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Unique Domains</div>
                <div class="stat-value">{len(domain_counts)}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Categories</div>
                <div class="stat-value">{len(category_counts)}</div>
            </div>
        </div>"""

    # Add charts section
    html += """
        <!-- Visual Charts -->
        <div class="chart-container">
            <div class="chart-card">
                <div class="chart-title">Top Domains</div>
                <ul class="domain-list">"""
    
    # Add top domains
    max_count = top_domains[0][1] if top_domains else 0
    for domain, count in top_domains:
        percentage = int((count / max_count) * 100)
        html += f"""
                    <li class="domain-item">
                        <span>{domain}</span>
                        <span>{count}</span>
                        <div class="domain-bar" style="width: {percentage}%"></div>
                    </li>"""
    
    html += """
                </ul>
            </div>
            <div class="chart-card">
                <div class="chart-title">Categories Distribution</div>
                <ul class="domain-list">"""
    
    # Add category distribution
    sorted_categories = sorted(category_counts.items(), key=lambda x: x[1], reverse=True)
    max_cat_count = sorted_categories[0][1] if sorted_categories else 0
    for category, count in sorted_categories:
        percentage = int((count / max_cat_count) * 100)
        color = category_colors.get(category, "#7f8c8d")
        html += f"""
                    <li class="domain-item">
                        <span>{category}</span>
                        <span>{count}</span>
                        <div class="domain-bar" style="width: {percentage}%; background-color: {color};"></div>
                    </li>"""
    
    html += """
                </ul>
            </div>
        </div>"""

    if "error" in results:
        html += f"""
        <div class="warning-card">
            <div class="warning-title">⚠️ Error analyzing database</div>
            <p>{results["error"]}</p>
        </div>"""
    elif not os.path.exists(db_path):
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ Database file not found</div>
            <p>The specified database file could not be found.</p>
        </div>"""
    elif "entries" not in results or not results["entries"]:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No history entries found</div>
            <p>No browsing history entries were found in the database.</p>
        </div>"""
    else:
        # Group entries by category
        categorized_entries = {}
        for entry in results["entries"]:
            category = entry["analysis"].get("category", "Other")
            if category not in categorized_entries:
                categorized_entries[category] = []
            categorized_entries[category].append(entry)
        
        # Process entries by category
        html += """
        <div class="entries-container">"""
        
        for category, entries in sorted(categorized_entries.items(), key=lambda x: len(x[1]), reverse=True):
            color = category_colors.get(category, "#7f8c8d")
            
            html += f"""
            <div class="category-section" style="border-left: 4px solid {color};">
                <div class="category-header">
                    <div class="category-title" style="color: {color};">
                        {category} ({len(entries)})
                    </div>
                </div>
                <div class="expandable-section">
                    <button class="expandable-toggle" onclick="toggleSection(this)">
                        View Entries ({len(entries)})
                    </button>
                    <div class="expandable-content">"""
            
            # Process entries in this category
            for entry in entries[:100]:  # Limit to 100 entries per category to keep the file size reasonable
                url = entry.get("url", "")
                domain = entry["analysis"].get("domain", "unknown")
                visit_time = entry["analysis"].get("visit_datetime", "Unknown")
                
                html += f"""
                    <div class="entry-card">
                        <div class="entry-title">
                            {domain}
                            <span class="time-badge">{visit_time}</span>
                        </div>
                        <div class="entry-url">{url}</div>"""
                
                # Add additional insights if available
                if "tracking_params" in entry["analysis"]:
                    html += f"""
                        <div class="entry-insight">Contains tracking parameters: {', '.join(entry["analysis"]["tracking_params"])}</div>"""
                
                html += f"""
                        <span class="category-badge" style="background-color:{color};">{category}</span>
                    </div>"""
            
            # If there are more than 100 entries, add a note
            if len(entries) > 100:
                html += f"""
                    <div class="entry-insight">Showing 100 of {len(entries)} entries in this category</div>"""
            
            html += """
                    </div>
                </div>
            </div>"""
        
        html += """
        </div>"""

    # Footer
    html += f"""
        <div class="footer">
            <p>📁 Report path: <code id="reportPath">{output_path}</code></p>
            <p>📁 Database analyzed: <code>{db_path}</code></p>
            <p>ForenSage © 2025 - Digital Forensic Tool</p>
        </div>
    </div>

   <script>
        // Toggle expandable sections
        function toggleSection(el) {{
            el.classList.toggle('active');
            let content = el.nextElementSibling;
            content.style.display = content.style.display === 'block' ? 'none' : 'block';
        }}

        // Set absolute path for report
        document.getElementById('reportPath').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # Path to the browser history database
    db_path = "/home/adrian/ForenSage/analyze/amecho/History"
    
    # For output, create relative path
    base_path = Path.home() / "ForenSage"
    output_html = base_path / "results/amecho_url_info.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    # Analyze history database
    results, success = analyze_history_database(db_path)
    
    # Generate HTML report
    generate_amecho_url_html(results, db_path, str(output_html))

if __name__ == "__main__":
    main()