import os
import xml.etree.ElementTree as ET
import datetime
import base64
from pathlib import Path
import re

def analyze_amazon_settings_xml(file_path):
    """Analiza el archivo XML de configuración de Amazon Echo y extrae sus datos."""
    print(f"Analizando archivo: {file_path}")
    
    # Verificar que el archivo existe
    if not os.path.exists(file_path):
        print(f"ERROR: El archivo no existe: {file_path}")
        return {}, False
    
    try:
        # Intenta analizar el archivo XML
        tree = ET.parse(file_path)
        root = tree.getroot()
        
        print(f"Elemento raíz: {root.tag}")
        print(f"Número de elementos: {len(root)}")
        
        # Almacenará todos los datos del archivo
        file_data = {}
        
        # Campos importantes para destacar como información del dispositivo
        device_info_fields = [
            "serial", "device_id", "device_type", "model", 
            "firmware", "hardware", "mac", "ip"
        ]
        
        # Información del dispositivo
        device_info = {}
        image_count = 0
        
        # Recorrer cada elemento hijo en el XML
        for child in root:
            if 'name' in child.attrib:
                name = child.attrib['name']
                value = child.text if child.text else ""
                value_type = child.tag
                
                # Registrar información importante del dispositivo
                is_device_info = False
                for field in device_info_fields:
                    if field in name.lower():
                        device_info[name] = value
                        is_device_info = True
                        print(f"Información del dispositivo encontrada: {name} = {value}")
                        break
                
                # Verificar si puede ser una imagen codificada
                is_image = False
                image_data = None
                image_format = None
                
                # Solo verificar cadenas largas que podrían ser imágenes codificadas en base64
                if value_type == "string" and len(value) > 100 and not is_device_info:
                    # Patrones para URI de datos
                    if value.startswith("data:image"):
                        pattern = r'data:image/([a-zA-Z]+);base64,(.+)'
                        match = re.match(pattern, value)
                        if match:
                            image_format = match.group(1)
                            image_data = match.group(2)
                            is_image = True
                            image_count += 1
                            print(f"Imagen encontrada en campo: {name} (formato: {image_format})")
                    # Patrones para datos base64 sin URI
                    elif re.match(r'^[A-Za-z0-9+/]+={0,2}$', value):
                        try:
                            decoded = base64.b64decode(value)
                            # Verificar cabeceras de JPEG o PNG
                            if decoded.startswith(b'\xff\xd8'):  # Cabecera JPEG
                                is_image = True
                                image_data = value
                                image_format = "jpeg"
                                image_count += 1
                                print(f"Imagen JPEG encontrada en campo: {name}")
                            elif decoded.startswith(b'\x89PNG'):  # Cabecera PNG
                                is_image = True
                                image_data = value
                                image_format = "png"
                                image_count += 1
                                print(f"Imagen PNG encontrada en campo: {name}")
                        except:
                            pass
                
                # Almacenar los datos extraídos
                file_data[name] = {
                    "value": value[:100] + "..." if len(value) > 100 and not is_image else value,
                    "type": value_type,
                    "is_image": is_image,
                    "is_device_info": is_device_info,
                    "image_data": image_data,
                    "image_format": image_format
                }
        
        print(f"Análisis completado. Encontrados {len(file_data)} elementos.")
        print(f"Información del dispositivo: {len(device_info)} elementos")
        print(f"Imágenes encontradas: {image_count}")
        
        results = {
            "data": file_data,
            "device_info": device_info,
            "image_count": image_count,
            "file_path": file_path,
            "file_exists": True
        }
        
        return results, True
        
    except Exception as e:
        print(f"ERROR al analizar el archivo: {e}")
        return {
            "data": {},
            "file_path": file_path,
            "file_exists": os.path.exists(file_path),
            "error": str(e)
        }, False

def generate_html_report(results, output_path):
    """Genera un informe HTML con los datos analizados del XML"""
    print(f"Generando informe HTML en: {output_path}")
    
    # Crear directorio si no existe
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    file_path = results.get("file_path", "Desconocido")
    file_exists = results.get("file_exists", False)
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    device_info = results.get("device_info", {})
    image_count = results.get("image_count", 0)
    data = results.get("data", {})

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de Amazon Echo</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
            background-color: #f5f5f5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }}
        h1 {{
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }}
        .info-section {{
            margin-bottom: 30px;
        }}
        .info-title {{
            background-color: #3498db;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
        }}
        .info-item {{
            background-color: #ecf0f1;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #3498db;
        }}
        .info-item.device-info {{
            border-left: 4px solid #2ecc71;
        }}
        .info-label {{
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }}
        .info-value {{
            font-family: monospace;
            word-break: break-all;
            background: #f9f9f9;
            padding: 5px;
            border-radius: 3px;
        }}
        .image-container {{
            max-width: 300px;
            margin: 15px 0;
        }}
        .image-container img {{
            max-width: 100%;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        }}
        .footer {{
            margin-top: 30px;
            border-top: 1px solid #ddd;
            padding-top: 15px;
            text-align: center;
            color: #7f8c8d;
        }}
        .error {{
            background-color: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Análisis de Configuración de Amazon Echo</h1>
        <p>Generado el: {now}</p>
        <p>Archivo analizado: {file_path}</p>
"""

    if not file_exists:
        html += """
        <div class="error">
            <strong>Error:</strong> El archivo especificado no fue encontrado.
        </div>
"""
    elif "error" in results:
        html += f"""
        <div class="error">
            <strong>Error al analizar el archivo:</strong> {results["error"]}
        </div>
"""
    else:
        # Sección de información del dispositivo
        if device_info:
            html += """
        <div class="info-section">
            <h2 class="info-title">📱 Información del Dispositivo</h2>
            <div class="info-grid">
"""
            for name, value in device_info.items():
                html += f"""
                <div class="info-item device-info">
                    <div class="info-label">{name}</div>
                    <div class="info-value">{value}</div>
                </div>
"""
            html += """
            </div>
        </div>
"""
        
        # Sección de imágenes
        image_entries = [(name, data) for name, data in data.items() if data.get("is_image", False)]
        if image_entries:
            html += """
        <div class="info-section">
            <h2 class="info-title">🖼️ Imágenes Encontradas</h2>
            <div class="info-grid">
"""
            for name, data in image_entries:
                image_data = data.get("image_data", "")
                image_format = data.get("image_format", "jpeg")
                
                html += f"""
                <div class="info-item">
                    <div class="info-label">{name}</div>
"""
                
                # Mostrar la imagen según su formato
                if image_data:
                    if image_data.startswith("data:image"):
                        html += f"""
                    <div class="image-container">
                        <img src="{image_data}" alt="{name}">
                    </div>
"""
                    else:
                        html += f"""
                    <div class="image-container">
                        <img src="data:image/{image_format};base64,{image_data}" alt="{name}">
                    </div>
"""
                
                html += """
                </div>
"""
            html += """
            </div>
        </div>
"""
        
        # Otras configuraciones (excluyendo imágenes y información del dispositivo)
        other_entries = [(name, data) for name, data in data.items() 
                         if not data.get("is_image", False) and not data.get("is_device_info", False)]
        
        if other_entries:
            html += """
        <div class="info-section">
            <h2 class="info-title">⚙️ Otras Configuraciones</h2>
            <div class="info-grid">
"""
            for name, data in other_entries:
                value = data.get("value", "")
                value_type = data.get("type", "")
                
                html += f"""
                <div class="info-item">
                    <div class="info-label">{name} <small>({value_type})</small></div>
                    <div class="info-value">{value}</div>
                </div>
"""
            html += """
            </div>
        </div>
"""

    # Pie de página
    html += f"""
        <div class="footer">
            <p>Análisis de Amazon Echo XML • Generado el {now}</p>
        </div>
    </div>
</body>
</html>
"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe HTML generado correctamente en: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe HTML: {e}")
        return False

def main():
    # Usa la ruta que proporcionaste
    file_to_analyze = "/home/adrian/Escritorio/Volcados/Amazon Echo/com.amazon.settings.DNSVR_STORE.xml"
    
    # Ruta para el informe HTML (en el mismo directorio que el script)
    base_path = Path.home() / "ForenSage"
    output_html = base_path / "results/amecho_serial_number.html"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = os.path.join(script_dir, "")
    
    
    # Asegurar que el directorio de salida existe
    os.makedirs(output_dir, exist_ok=True)
    
    print("=== ANALIZADOR DE XML DE AMAZON ECHO ===")
    print(f"Archivo a analizar: {file_to_analyze}")
    print(f"Informe HTML se guardará en: {output_html}")
    
    # Analizar el archivo XML
    results, success = analyze_amazon_settings_xml(file_to_analyze)
    
    if not success:
        print("❌ No se pudo analizar el archivo correctamente.")
    
    # Generar informe HTML
    if generate_html_report(results, output_html):
        print("\n¡Análisis completado con éxito!")
        print(f"Abra el archivo {output_html} en su navegador para ver los resultados.")
    else:
        print("\n❌ Error al generar el informe HTML.")

if __name__ == "__main__":
    main()
