import os
import sqlite3
import datetime
from pathlib import Path
import re

def analyze_history_database2(database_path):
    """Analyzes the History database and extracts keyword search terms."""
    results = {}
    
    try:
        if not os.path.exists(database_path):
            print(f"Error: Database file not found: {database_path}")
            return results, False
        
        try:
            # Connect to the SQLite database
            conn = sqlite3.connect(database_path)
            cursor = conn.cursor()
            
            # Check if the keyword_search_terms table exists
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='keyword_search_terms'")
            if not cursor.fetchone():
                print(f"Table 'keyword_search_terms' not found in database: {database_path}")
                conn.close()
                return results, True
            
            # Get column names from keyword_search_terms table
            cursor.execute("PRAGMA table_info(keyword_search_terms)")
            columns = [column[1] for column in cursor.fetchall()]
            
            # Query all data from keyword_search_terms table
            cursor.execute("SELECT * FROM keyword_search_terms")
            rows = cursor.fetchall()
            
            # Prepare results
            search_terms = []
            for row in rows:
                term_data = {}
                for i, column_name in enumerate(columns):
                    term_data[column_name] = row[i]
                search_terms.append(term_data)
            
            results["keyword_search_terms"] = {
                "data": search_terms,
                "columns": columns,
                "count": len(search_terms)
            }
            
            conn.close()
            return results, True
            
        except sqlite3.Error as e:
            print(f"SQLite error: {e}")
            return results, True
        
    except Exception as e:
        print(f"General error: {e}")
        return results, False

def categorize_search_term(term):
    """Categorizes search terms based on patterns"""
    if not term or not isinstance(term, str):
        return "Undefined"
        
    term_lower = term.lower()
    
    categories = {
        "Shopping": ["buy", "price", "amazon", "ebay", "shop", "store", "purchase", "deal", "order"],
        "Travel": ["hotel", "flight", "booking", "trip", "vacation", "travel", "ticket", "resort", "airbnb"],
        "Technology": ["software", "hardware", "app", "computer", "phone", "device", "tech", "download", "update"],
        "Social": ["facebook", "instagram", "twitter", "tiktok", "social", "profile", "friend", "follow"],
        "Entertainment": ["movie", "music", "video", "game", "play", "watch", "stream", "netflix", "youtube"],
        "Information": ["how to", "what is", "define", "meaning", "wiki", "news", "weather", "map", "directions"],
        "Health": ["symptom", "doctor", "health", "medical", "diet", "exercise", "fitness", "covid", "disease"]
    }
    
    for category, patterns in categories.items():
        for pattern in patterns:
            if pattern in term_lower:
                return category
    
    return "Miscellaneous"

def get_search_term_insight(term_data):
    """Analyzes search term data and returns insights"""
    insights = []
    
    # Check for timestamps
    if "last_visit_time" in term_data:
        try:
            # Chrome timestamp is microseconds since Jan 1, 1601
            chrome_epoch = datetime.datetime(1601, 1, 1)
            timestamp = term_data["last_visit_time"]
            if timestamp:
                # Convert to seconds
                seconds_since_epoch = timestamp / 1000000
                date = chrome_epoch + datetime.timedelta(seconds=seconds_since_epoch)
                insights.append(f"Last visited: {date.strftime('%Y-%m-%d %H:%M:%S')}")
        except:
            pass
    
    # Check for search count
    if "url_count" in term_data and term_data["url_count"]:
        count = term_data["url_count"]
        if count > 10:
            insights.append(f"High frequency search ({count} times)")
        elif count > 5:
            insights.append(f"Moderate frequency search ({count} times)")
        else:
            insights.append(f"Low frequency search ({count} times)")
    
    # Check term length
    if "term" in term_data and term_data["term"]:
        term = term_data["term"]
        if len(term) > 30:
            insights.append("Long search query")
        elif len(term.split()) > 5:
            insights.append("Complex search query")
            
        # Check for possible sensitive searches
        sensitive_terms = ["password", "login", "account", "credit card", "address", "phone", "ssn", "social security"]
        for sensitive in sensitive_terms:
            if sensitive in term.lower():
                insights.append("Potentially sensitive search")
                break
    
    return insights if insights else ["Standard search term"]

def generate_amecho_search_html(results, database_info, output_path):
    """Generates an HTML report with the analyzed History database"""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    database_path, database_exists = database_info
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Generate colors for different categories
    category_colors = {
        "Shopping": "#3498db", "Travel": "#2ecc71", "Technology": "#e74c3c",
        "Social": "#f39c12", "Entertainment": "#9b59b6", "Information": "#1abc9c",
        "Health": "#d35400", "Miscellaneous": "#7f8c8d", "Undefined": "#95a5a6"
    }
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browser History Search Terms Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50; --primary: #34495e; --primary-light: #4a6278;
            --accent: #3498db; --accent-light: #5dade2; --text: #ecf0f1;
            --text-secondary: #bdc3c7; --background: #0b0b1a; --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1); --success: #27ae60;
            --warning: #f39c12; --danger: #e74c3c; --grid-line: rgba(52, 152, 219, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Montserrat', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(52, 152, 219, 0.03) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(52, 152, 219, 0.02) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.3;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Orbitron', sans-serif; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .stat-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}

        .stat-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .stat-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;
        }}

        .stat-value {{ font-size: 2rem; font-weight: 700; color: var(--accent-light); }}

        .source-container {{ margin-top: 2rem; margin-bottom: 2rem; }}

        .source-card {{
            background-color: var(--primary); border-radius: 12px;
            padding: 1.5rem; margin-bottom: 1.5rem; border-left: 4px solid var(--accent);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); position: relative; overflow: hidden;
        }}

        .source-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}

        .source-title {{
            font-family: 'Orbitron', sans-serif; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; display: flex; align-items: center;
        }}

        .source-path {{
            font-family: monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem;
            width: 100%; overflow-x: auto; margin-top: 0.5rem; white-space: nowrap;
        }}

        .source-status {{
            font-size: 0.8rem; padding: 0.3rem 0.8rem; border-radius: 12px;
            font-weight: 600; letter-spacing: 0.5px;
        }}

        .source-found {{ background-color: var(--success); color: var(--text); }}
        .source-not-found {{ background-color: var(--danger); color: var(--text); }}

        .search-terms-container {{ margin-top: 1.5rem; }}

        .search-term-card {{
            background-color: var(--card-bg); border-radius: 8px; padding: 1rem;
            margin-bottom: 1rem; border-left: 4px solid var(--accent);
            transition: transform 0.2s ease, box-shadow 0.2s ease; position: relative; overflow: hidden;
        }}

        .search-term-card:hover {{ transform: translateX(5px); box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2); }}

        .search-term {{
            font-weight: 600; color: var(--accent-light); font-size: 1.1rem;
            margin-bottom: 0.3rem; display: flex; align-items: center;
        }}

        .search-count {{
            font-size: 0.75rem; color: var(--text-secondary); background-color: rgba(255, 255, 255, 0.1);
            padding: 0.2rem 0.5rem; border-radius: 10px; margin-left: 0.5rem;
            text-transform: uppercase; letter-spacing: 0.5px;
        }}

        .search-timestamp {{
            font-family: monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem; word-break: break-all;
        }}

        .search-details {{ font-size: 0.9rem; color: var(--text-secondary); margin-top: 0.5rem; }}
        .data-insight {{ margin-top: 0.5rem; font-size: 0.9rem; color: var(--accent-light); font-style: italic; }}
        .category-badge {{ padding: 0.2rem 0.6rem; border-radius: 10px; font-size: 0.75rem; font-weight: 600; }}

        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}

        .error-message {{ color: var(--danger); margin-top: 0.5rem; font-style: italic; font-size: 0.9rem; }}

        .expandable-toggle {{
            background-color: var(--primary-dark); color: var(--text); border: none;
            width: 100%; text-align: left; padding: 0.8rem; border-radius: 8px;
            margin-bottom: 0.5rem; cursor: pointer; display: flex;
            justify-content: space-between; align-items: center; font-weight: 600;
        }}

        .expandable-content {{ display: none; padding: 0.5rem; background-color: rgba(0, 0, 0, 0.1); border-radius: 0 0 8px 8px; }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .source-header {{ flex-direction: column; align-items: flex-start; }}
            .source-status {{ margin-top: 0.5rem; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Browser History Search Terms Analysis</h1>
            <p class="subtitle">📅 Generated on {now} | Generado el {now}</p>
        </div>"""

    # Get search terms data
    search_terms_data = results.get("keyword_search_terms", {}).get("data", [])
    search_terms_count = len(search_terms_data)

    # Dashboard Stats
    html += f"""
        <!-- Dashboard Stats -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-label">Search Terms Analyzed / Términos de búsqueda analizados</div>
                <div class="stat-value">{search_terms_count}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Database / Base de datos</div>
                <div class="stat-value">{os.path.basename(database_path)}</div>
            </div>
        </div>"""

    if not database_exists:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ Database not found / Base de datos no encontrada</div>
            <p>The specified database could not be found. | La base de datos especificada no pudo ser encontrada.</p>
        </div>"""
    elif not search_terms_data:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No search terms found / No se encontraron términos de búsqueda</div>
            <p>No search terms were found in the keyword_search_terms table. | No se encontraron términos de búsqueda en la tabla keyword_search_terms.</p>
        </div>"""
    else:
        # Process search terms
        html += """
        <div class="source-container">
            <div class="source-card">
                <div class="source-header">
                    <div class="source-title">
                        <span style="margin-right:10px;">🔍</span> keyword_search_terms
                    </div>
                    <span class="source-status source-found">Found / Encontrado</span>
                </div>
                <div class="source-path">{database_path}</div>"""
        
        # Group search terms by category
        categorized_terms = {}
        for term_data in search_terms_data:
            term = term_data.get("term", "")
            category = categorize_search_term(term)
            if category not in categorized_terms:
                categorized_terms[category] = []
            categorized_terms[category].append(term_data)
        
        # Create expandable sections for each category
        html += """
                <div class="search-terms-container">"""
        
        for category, terms in categorized_terms.items():
            color = category_colors.get(category, "#7f8c8d")
            
            html += f"""
                    <div class="expandable-section">
                        <button class="expandable-toggle" onclick="toggleSection(this)">
                            {category} ({len(terms)})
                        </button>
                        <div class="expandable-content">"""
            
            for term_data in terms:
                term = term_data.get("term", "")
                url_count = term_data.get("url_count", 0)
                insights = get_search_term_insight(term_data)
                
                html += f"""
                            <div class="search-term-card" data-category="{category}">
                                <div class="search-term">
                                    {term}
                                    <span class="search-count">Count: {url_count}</span>
                                </div>"""
                
                # Add timestamp if available
                if "last_visit_time" in term_data:
                    try:
                        chrome_epoch = datetime.datetime(1601, 1, 1)
                        timestamp = term_data["last_visit_time"]
                        if timestamp:
                            seconds_since_epoch = timestamp / 1000000
                            date = chrome_epoch + datetime.timedelta(seconds=seconds_since_epoch)
                            formatted_date = date.strftime('%Y-%m-%d %H:%M:%S')
                            html += f"""
                                <div class="search-timestamp">Last visited: {formatted_date}</div>"""
                    except:
                        pass
                
                # Add insights
                for insight in insights:
                    html += f"""
                                <div class="data-insight">{insight}</div>"""
                
                html += f"""
                                <span class="category-badge" style="background-color:{color};">{category}</span>
                            </div>"""
            
            html += """
                        </div>
                    </div>"""
        
        html += """
                </div>
            </div>
        </div>"""

    # Footer
    html += f"""
        <div class="footer">
            <p>📁 Report path / Ruta del informe: <code id="reportPath">{output_path}</code></p>
            <p>📁 Database analyzed / Base de datos analizada: <code>{database_path}</code></p>
            <p>ForenSage © 2025 - Browser History Forensic Tool</p>
        </div>
    </div>

    <script>
        // Toggle expandable sections
        function toggleSection(el) {{
            el.classList.toggle('active');
            let content = el.nextElementSibling;
            content.style.display = content.style.display === 'block' ? 'none' : 'block';
        }}

        // Set absolute path for report
        document.getElementById('reportPath').textContent = document.location.pathname;
        
        // Automatically open the first section
        document.addEventListener('DOMContentLoaded', function() {{
            let firstToggle = document.querySelector('.expandable-toggle');
            if (firstToggle) {{
                firstToggle.click();
            }}
        }});
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # Database to analyze
    database_to_analyze = "/home/adrian/ForenSage/analyze/amecho/History"
    
    # For output, create relative path
    base_path = Path.home() / "ForenSage"
    output_html = base_path / "results/amecho_search_info.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    # Analyze History database
    results, database_exists = analyze_history_database2(database_to_analyze)
    
    # Generate HTML report
    generate_amecho_search_html(results, (database_to_analyze, database_exists), str(output_html))

if __name__ == "__main__":
    main()