import os
import xml.etree.ElementTree as ET
import datetime
from pathlib import Path

def analyze_xml_file(file_path):
    """Analyzes a single XML file and extracts its content without assuming structure."""
    file_data = {}
    
    try:
        # Verificar si el archivo existe
        if not os.path.exists(file_path):
            print(f"Error: File {file_path} does not exist.")
            return {}, False
        
        tree = ET.parse(file_path)
        root = tree.getroot()
        
        # Extraer información recursivamente de todos los elementos
        extract_elements(root, "", file_data)
        
        if not file_data:
            print(f"Warning: No data found in {file_path}")
        
        return file_data, True
    except ET.ParseError as e:
        print(f"Error parsing XML file {file_path}: {e}")
        return {}, False
    except Exception as e:
        print(f"Error analyzing {file_path}: {e}")
        return {}, False

def extract_elements(element, path, file_data):
    """Recursively extracts all elements from the XML"""
    current_path = path
    
    # Si el elemento tiene un atributo 'name', lo usamos para identificarlo
    if 'name' in element.attrib:
        name = element.attrib['name']
        if current_path:
            current_path = f"{current_path}.{name}"
        else:
            current_path = name
        
        # Guardar el valor del elemento
        if element.text and element.text.strip():
            file_data[current_path] = {
                "value": element.text.strip(),
                "type": determine_type(element.text.strip())
            }
    # Si no tiene atributo 'name', usamos el tag
    else:
        tag = element.tag
        if current_path:
            current_path = f"{current_path}.{tag}"
        else:
            current_path = tag
        
        # Si el elemento tiene texto, lo guardamos
        if element.text and element.text.strip():
            file_data[current_path] = {
                "value": element.text.strip(),
                "type": determine_type(element.text.strip())
            }
    
    # También guardamos los atributos
    for attr_name, attr_value in element.attrib.items():
        attr_path = f"{current_path}@{attr_name}"
        file_data[attr_path] = {
            "value": attr_value,
            "type": determine_type(attr_value)
        }
    
    # Proceso recursivo para los elementos hijos
    for child in element:
        extract_elements(child, current_path, file_data)

def determine_type(value):
    """Determina el tipo de dato basado en su valor"""
    value = value.strip() if isinstance(value, str) else value
    
    try:
        int_value = int(value)
        return "int"
    except (ValueError, TypeError):
        try:
            float_value = float(value)
            return "float"
        except (ValueError, TypeError):
            if isinstance(value, str) and value.lower() in ["true", "false"]:
                return "boolean"
            else:
                return "string"

def categorize_preference(name):
    """Categorizes preferences based on name patterns"""
    name_lower = name.lower()
    
    categories = {
        "Display": ["dark", "display", "brightness", "screen", "theme", "night"],
        "Network": ["wifi", "bluetooth", "data", "network", "mobile", "airplane"],
        "Sound": ["sound", "volume", "audio", "vibration", "ringtone"],
        "Security": ["lock", "password", "pin", "pattern", "fingerprint", "security"],
        "System": ["language", "time", "date", "timezone", "battery", "storage"],
        "User": ["account", "user", "profile"],
        "App Settings": ["app", "application", "permission", "notification"]
    }
    
    for category, patterns in categories.items():
        for pattern in patterns:
            if pattern in name_lower:
                return category
    
    return "Miscellaneous"

def analyze_preference_value(value, value_type):
    """Analyzes the value of a preference and returns insights"""
    if value_type == "boolean":
        return "Enabled / Habilitado" if value.lower() in ["true", "1"] else "Disabled / Deshabilitado"
    
    if value_type in ["int", "long", "float"]:
        try:
            num_value = float(value)
            if num_value == 0:
                return "Value: 0 (Disabled / Deshabilitado)"
            elif num_value == 1:
                return "Value: 1 (Enabled / Habilitado)"
            elif num_value > 1000000000:  # Timestamp check
                try:
                    date = datetime.datetime.fromtimestamp(num_value/1000)
                    return f"Timestamp: {date.strftime('%Y-%m-%d %H:%M:%S')}"
                except:
                    return f"Numeric value: {value}"
            else:
                return f"Numeric value: {value}"
        except ValueError:
            return f"Value: {value}"
    
    if value_type == "string":
        if value.startswith('#') and len(value) in [7, 9]:
            return f"Color value: {value}"
        elif '-' in value and value[4:5] == '-':
            return f"Date value: {value}"
        else:
            return f"Text value: {value}"
    
    return f"Value: {value}"

def get_preference_description(name):
    """Returns a human-readable description for common Android preference names."""
    descriptions = {
        "dark_mode": "Dark Mode Setting / Configuración de Modo Oscuro",
        "night_mode": "Night Mode Setting / Configuración de Modo Nocturno",
        "bluetooth": "Bluetooth Settings / Configuración de Bluetooth",
        "wifi": "Wi-Fi Settings / Configuración de Wi-Fi",
        "location": "Location Settings / Configuración de Ubicación",
        "volume": "Volume Settings / Configuración de Volumen",
        "sound": "Sound Settings / Configuración de Sonido",
        "brightness": "Brightness Settings / Configuración de Brillo",
        "language": "Language Settings / Configuración de Idioma",
        "time": "Time Settings / Configuración de Hora",
        "notification": "Notification Settings / Configuración de Notificaciones",
        "battery": "Battery Settings / Configuración de Batería",
        "data": "Data Usage Settings / Configuración de Uso de Datos",
        "security": "Security Settings / Configuración de Seguridad"
    }
    
    if name in descriptions:
        return descriptions[name]
    
    for key, desc in descriptions.items():
        if key in name.lower():
            return desc
    
    return "Setting Value / Valor de Configuración"

def generate_amecho_user_html(file_data, file_path, output_path):
    """Generates an HTML report with the analyzed XML file"""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    file_name = os.path.basename(file_path)
    file_exists = os.path.exists(file_path)
    
    # Category colors
    category_colors = {
        "Display": "#3498db", "Network": "#2ecc71", "Sound": "#e74c3c",
        "Security": "#f39c12", "System": "#9b59b6", "User": "#1abc9c",
        "App Settings": "#d35400", "Miscellaneous": "#7f8c8d"
    }
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XML File Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50; --primary: #34495e; --primary-light: #4a6278;
            --accent: #3498db; --accent-light: #5dade2; --text: #ecf0f1;
            --text-secondary: #bdc3c7; --background: #0b0b1a; --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1); --success: #27ae60;
            --warning: #f39c12; --danger: #e74c3c; --grid-line: rgba(52, 152, 219, 0.1);
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: 'Montserrat', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(52, 152, 219, 0.03) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(52, 152, 219, 0.02) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}
        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.3;
        }}
        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}
        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}
        .title {{
            font-family: 'Orbitron', sans-serif; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}
        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}
        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}
        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}
        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}
        .stat-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}
        .stat-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}
        .stat-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;
        }}
        .stat-value {{font-size: 2rem; font-weight: 700; color: var(--accent-light); }}
        .source-container {{ margin-top: 2rem; margin-bottom: 2rem; }}
        .source-card {{
            background-color: var(--primary); border-radius: 12px;
            padding: 1.5rem; margin-bottom: 1.5rem; border-left: 4px solid var(--accent);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); position: relative; overflow: hidden;
        }}
        .source-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}
        .source-title {{
            font-family: 'Orbitron', sans-serif; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; display: flex; align-items: center;
        }}
        .source-path {{
            font-family: monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem;
            width: 100%; overflow-x: auto; margin-top: 0.5rem; white-space: nowrap;
        }}
        .source-status {{
            font-size: 0.8rem; padding: 0.3rem 0.8rem; border-radius: 12px;
            font-weight: 600; letter-spacing: 0.5px;
        }}
        .source-found {{ background-color: var(--success); color: var(--text); }}
        .source-not-found {{ background-color: var(--danger); color: var(--text); }}
        .preferences-container {{ margin-top: 1.5rem; }}
        .preference-card {{
            background-color: var(--card-bg); border-radius: 8px; padding: 1rem;
            margin-bottom: 1rem; border-left: 4px solid var(--accent);
            transition: transform 0.2s ease, box-shadow 0.2s ease; position: relative; overflow: hidden;
        }}
        .preference-card:hover {{ transform: translateX(5px); box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2); }}
        .preference-name {{
            font-weight: 600; color: var(--accent-light); font-size: 1.1rem;
            margin-bottom: 0.3rem; display: flex; align-items: center;
        }}
        .preference-type {{
            font-size: 0.75rem; color: var(--text-secondary); background-color: rgba(255, 255, 255, 0.1);
            padding: 0.2rem 0.5rem; border-radius: 10px; margin-left: 0.5rem;
            text-transform: uppercase; letter-spacing: 0.5px;
        }}
        .preference-value {{
            font-family: monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem; word-break: break-all;
        }}
        .preference-description {{ font-size: 0.9rem; color: var(--text-secondary); margin-top: 0.5rem; }}
        .data-insight {{ margin-top: 0.5rem; font-size: 0.9rem; color: var(--accent-light); font-style: italic; }}
        .category-badge {{ padding: 0.2rem 0.6rem; border-radius: 10px; font-size: 0.75rem; font-weight: 600; }}
        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}
        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}
        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}
        .error-message {{ color: var(--danger); margin-top: 0.5rem; font-style: italic; font-size: 0.9rem; }}
        .expandable-toggle {{
            background-color: var(--primary-dark); color: var(--text); border: none;
            width: 100%; text-align: left; padding: 0.8rem; border-radius: 8px;
            margin-bottom: 0.5rem; cursor: pointer; display: flex;
            justify-content: space-between; align-items: center; font-weight: 600;
        }}
        .expandable-content {{ display: none; padding: 0.5rem; background-color: rgba(0, 0, 0, 0.1); border-radius: 0 0 8px 8px; }}
        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }}
        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .source-header {{ flex-direction: column; align-items: flex-start; }}
            .source-status {{margin-top: 0.5rem; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">XML File Analysis</h1>
            <p class="subtitle">📅 Generated on {now} | Generado el {now}</p>
        </div>

        <!-- Dashboard Stats -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-label">File / Archivo</div>
                <div class="stat-value">{file_name}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Preferences / Preferencias</div>
                <div class="stat-value">{len(file_data)}</div>
            </div>
        </div>"""

    if not file_exists:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ File not found / Archivo no encontrado</div>
            <p>The specified file could not be found. | El archivo especificado no pudo ser encontrado.</p>
        </div>"""
    elif not file_data:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No preferences found / No se encontraron preferencias</div>
            <p>No preferences were found in the specified file. | No se encontraron preferencias en el archivo especificado.</p>
        </div>"""
    else:
        # Process file data
        html += """
        <div class="source-container">
            <div class="source-card">
                <div class="source-header">
                    <div class="source-title">
                        <span style="margin-right:10px;">📄</span> {0}
                    </div>
                    <span class="source-status source-found">Found / Encontrado</span>
                </div>
                <div class="source-path">{1}</div>
                <div class="preferences-container">""".format(file_name, file_path)
        
        # Group preferences by category
        categorized_prefs = {}
        for pref_name, pref_data in file_data.items():
            category = categorize_preference(pref_name)
            if category not in categorized_prefs:
                categorized_prefs[category] = []
            categorized_prefs[category].append((pref_name, pref_data))
        
        # Create expandable sections for each category
        for category, prefs in categorized_prefs.items():
            color = category_colors.get(category, "#7f8c8d")
            
            html += f"""
                    <div class="expandable-section">
                        <button class="expandable-toggle" onclick="toggleSection(this)">
                            {category} ({len(prefs)})
                        </button>
                        <div class="expandable-content">"""
            
            for pref_name, pref_data in prefs:
                pref_value = pref_data.get("value", "")
                pref_type = pref_data.get("type", "")
                description = get_preference_description(pref_name)
                insight = analyze_preference_value(pref_value, pref_type)
                
                html += f"""
                        <div class="preference-card" data-category="{category}">
                            <div class="preference-name">
                                {pref_name}
                                <span class="preference-type">{pref_type}</span>
                            </div>
                            <div class="preference-value">{pref_value}</div>
                            <div class="preference-description">{description}</div>
                            <div class="data-insight">{insight}</div>
                            <span class="category-badge" style="background-color:{color};">{category}</span>
                        </div>"""
            
            html += """
                        </div>
                    </div>"""
        
        html += """
                </div>
            </div>
        </div>"""

    # Footer
    html += f"""
        <div class="footer">
            <p>📁 Report path / Ruta del informe: <code>{output_path}</code></p>
            <p>📁 File analyzed / Archivo analizado: <code>{file_path}</code></p>
            <p>ForenSage © 2025 - XML Analysis Tool</p>
        </div>
    </div>

   <script>
        // Toggle expandable sections
        function toggleSection(el) {{
            el.classList.toggle('active');
            let content = el.nextElementSibling;
            content.style.display = content.style.display === 'block' ? 'none' : 'block';
        }}
   </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # File to analyze
    file_path = "/home/adrian/ForenSage/analyze/amecho/0.xml"
    
    # For output, create relative path
    base_path = Path.home() / "ForenSage"
    output_html = base_path / "results/amecho_user_info.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    # Analyze XML file
    file_data, success = analyze_xml_file(file_path)
    
    # Logging para depuración
    print(f"Analizando: {file_path}")
    print(f"Datos extraídos: {len(file_data)} elementos")
    if success and file_data:
        print("Primeros 5 elementos encontrados:")
        for i, (key, value) in enumerate(list(file_data.items())[:5]):
            print(f"- {key}: {value}")
    
    # Generate HTML report
    generate_amecho_user_html(file_data, file_path, str(output_html))

if __name__ == "__main__":
    main()