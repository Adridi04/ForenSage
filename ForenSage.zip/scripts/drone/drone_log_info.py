import os
import datetime
import re
from pathlib import Path
import json

def analyze_dji_log_cache(base_path):
    """
    Analiza los archivos de caché de log de DJI en una ruta específica.
    Busca recursivamente todos los archivos .txt dentro de la estructura.
    
    Args:
        base_path: Ruta base donde comenzar la búsqueda
    
    Returns:
        Diccionario con información de los archivos analizados
    """
    print(f"Analizando logs en: {os.path.abspath(base_path)}")
    results = {
        "files_count": 0,
        "directories": {},
        "logs": [],
        "flight_data": {
            "dates": set(),
            "locations": set(),
            "drone_models": set()
        },
        "metadata": {
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_size": 0
        }
    }
    
    try:
        # Verificar si la ruta existe
        if not os.path.exists(base_path):
            print(f"La ruta {base_path} no existe")
            return results
            
        # Explorar directorio recursivamente
        for root, dirs, files in os.walk(base_path):
            # Filtrar solo archivos .txt
            txt_files = [f for f in files if f.lower().endswith('.txt')]
            
            if txt_files:
                print(f"Encontrados {len(txt_files)} archivos TXT en {root}")
                
                # Calcular ruta relativa para estructurar el árbol de directorios
                rel_path = os.path.relpath(root, start=base_path)
                
                # Procesar cada archivo .txt encontrado
                for file in txt_files:
                    file_path = os.path.join(root, file)
                    file_size = os.path.getsize(file_path)
                    results["metadata"]["total_size"] += file_size
                    results["files_count"] += 1
                    
                    # Información básica del archivo
                    file_info = {
                        "name": file,
                        "path": os.path.relpath(file_path, start=base_path),
                        "size": file_size,
                        "modified": datetime.datetime.fromtimestamp(os.path.getmtime(file_path)).strftime("%Y-%m-%d %H:%M:%S"),
                        "extracted_data": {}
                    }
                    
                    # Extraer información del contenido del archivo
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                            content = f.read()
                            file_info["extracted_data"] = extract_log_info(content)
                            
                            # Actualizar datos de vuelo globales
                            if "date" in file_info["extracted_data"]:
                                results["flight_data"]["dates"].add(file_info["extracted_data"]["date"])
                            if "location" in file_info["extracted_data"]:
                                results["flight_data"]["locations"].add(file_info["extracted_data"]["location"])
                            if "drone_model" in file_info["extracted_data"]:
                                results["flight_data"]["drone_models"].add(file_info["extracted_data"]["drone_model"])
                                
                        print(f"✓ Analizado: {file} - Extraídos {len(file_info['extracted_data'])} datos")
                    except Exception as e:
                        file_info["error"] = str(e)
                        print(f"✗ Error al analizar {file}: {e}")
                    
                    # Añadir a la lista global de logs
                    results["logs"].append(file_info)
                    
                    # Actualizar el árbol de directorios
                    add_to_directory_tree(results["directories"], rel_path, file_info)
    
    except Exception as e:
        print(f"Error general: {e}")
    
    # Convertir conjuntos a listas para JSON
    results["flight_data"]["dates"] = list(results["flight_data"]["dates"])
    results["flight_data"]["locations"] = list(results["flight_data"]["locations"])
    results["flight_data"]["drone_models"] = list(results["flight_data"]["drone_models"])
    
    print(f"Análisis completado: {results['files_count']} archivos analizados")
    return results

def add_to_directory_tree(directory_tree, path, file_info):
    """
    Añade un archivo a la estructura de árbol de directorios.
    
    Args:
        directory_tree: Diccionario que representa el árbol de directorios
        path: Ruta relativa donde se encuentra el archivo
        file_info: Información del archivo a añadir
    """
    if path == ".":
        # Si estamos en el directorio raíz
        if "files" not in directory_tree:
            directory_tree["files"] = []
        directory_tree["files"].append(file_info)
        return
        
    # Dividir la ruta en partes
    path_parts = path.split(os.sep)
    
    # Navegar por el árbol de directorios
    current = directory_tree
    for i, part in enumerate(path_parts):
        # Si no existe este directorio, crearlo
        if part not in current:
            current[part] = {"files": [], "subdirs": {}}
        
        # Si es el último directorio, añadir el archivo
        if i == len(path_parts) - 1:
            current[part]["files"].append(file_info)
        else:
            # Si no es el último, movernos al siguiente nivel
            current = current[part]["subdirs"]

def extract_log_info(content):
    """
    Extrae información relevante del contenido de un archivo de log.
    Busca patrones como coordenadas GPS, fechas, altitud, etc.
    
    Args:
        content: Contenido del archivo a analizar
    
    Returns:
        Diccionario con la información extraída
    """
    info = {}
    
    # Buscar coordenadas GPS (formatos comunes en DJI logs)
    gps_pattern = re.compile(r'lat[itude]*[:\s=]+(-?\d+\.\d+).*?lon[gitude]*[:\s=]+(-?\d+\.\d+)', re.IGNORECASE | re.DOTALL)
    gps_match = gps_pattern.search(content)
    if gps_match:
        info["latitude"] = gps_match.group(1)
        info["longitude"] = gps_match.group(2)
        info["location"] = f"{gps_match.group(1)},{gps_match.group(2)}"
    
    # Buscar fechas (varios formatos comunes)
    date_patterns = [
        # ISO format: 2023-01-25
        re.compile(r'(\d{4}-\d{2}-\d{2})'),
        # US format: 01/25/2023
        re.compile(r'(\d{2}/\d{2}/\d{4})'),
        # Timestamp format
        re.compile(r'timestamp[:\s=]+(\d{4}-\d{2}-\d{2})', re.IGNORECASE)
    ]
    
    for pattern in date_patterns:
        date_match = pattern.search(content)
        if date_match:
            info["date"] = date_match.group(1)
            break
    
    # Buscar modelo de dron - patrón mejorado
    drone_pattern = re.compile(r'(?:model|aircraft|drone|device)[:\s=]+([\w\d\s\-]+)', re.IGNORECASE)
    drone_match = drone_pattern.search(content)
    if drone_match:
        info["drone_model"] = drone_match.group(1).strip()
    else:
        # Buscar modelos específicos de DJI
        dji_models = ["Mavic", "Phantom", "Inspire", "Mini", "Air", "Spark", "Matrice"]
        for model in dji_models:
            if re.search(rf'\b{model}\b', content, re.IGNORECASE):
                info["drone_model"] = model
                break
    
    # Buscar altitud - patrón mejorado
    altitude_pattern = re.compile(r'alt[itude]*[:\s=]+(-?\d+\.?\d*)', re.IGNORECASE)
    altitude_match = altitude_pattern.search(content)
    if altitude_match:
        info["altitude"] = altitude_match.group(1)
    
    # Buscar velocidad - patrón mejorado
    speed_pattern = re.compile(r'(?:speed|velocity)[:\s=]+(\d+\.?\d*)', re.IGNORECASE)
    speed_match = speed_pattern.search(content)
    if speed_match:
        info["speed"] = speed_match.group(1)
    
    # Buscar firmware
    firmware_pattern = re.compile(r'(?:firmware|fw)[:\s=]+([\w\d\.\-]+)', re.IGNORECASE)
    firmware_match = firmware_pattern.search(content)
    if firmware_match:
        info["firmware"] = firmware_match.group(1)
    
    # Buscar batería
    battery_pattern = re.compile(r'(?:battery|batt)[:\s=]+(\d+)', re.IGNORECASE)
    battery_match = battery_pattern.search(content)
    if battery_match:
        info["battery"] = battery_match.group(1)
    
    # Buscar tiempo de vuelo
    flight_time_pattern = re.compile(r'(?:flight[_\s]?time|tiempo[_\s]?vuelo)[:\s=]+(\d+\.?\d*)', re.IGNORECASE)
    flight_time_match = flight_time_pattern.search(content)
    if flight_time_match:
        info["flight_time"] = flight_time_match.group(1)
    
    return info

def generate_log_html(results, output_path):
    """
    Genera un informe HTML con los resultados del análisis.
    
    Args:
        results: Diccionario con los resultados del análisis
        output_path: Ruta donde guardar el informe HTML
    """
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # Crear HTML con estilo similar al ejemplo proporcionado
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de Logs DJI</title>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #1a2b3c; --primary: #23374d; --primary-light: #345678;
            --accent: #00a8ff; --accent-light: #29b6f6; --text: #e0e6ed;
            --text-secondary: #a7b9cc; --background: #0a1622; --card-bg: #12202e;
            --border-color: rgba(0, 168, 255, 0.2); --success: #00e676;
            --warning: #ffab00; --danger: #ff1744; --grid-line: rgba(0, 168, 255, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Rajdhani', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(0, 168, 255, 0.05) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(0, 168, 255, 0.03) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.2;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Share Tech Mono', monospace; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .summary-section {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; margin-bottom: 2rem;
            display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;
        }}

        .summary-item {{
            background-color: rgba(0, 0, 0, 0.2);
            padding: 1rem; border-radius: 10px; text-align: center;
        }}

        .summary-value {{
            font-size: 2rem; font-weight: 700; color: var(--accent);
            font-family: 'Share Tech Mono', monospace;
        }}

        .summary-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px;
        }}

        .log-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; margin-bottom: 1.5rem;
            position: relative; overflow: hidden; transition: transform 0.3s ease;
        }}

        .log-card:hover {{ transform: translateY(-5px); }}

        .log-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .log-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem;
        }}

        .log-title {{
            font-family: 'Share Tech Mono', monospace; font-size: 1.2rem;
            color: var(--accent-light); font-weight: 600;
        }}

        .log-path {{
            font-family: 'Share Tech Mono', monospace; font-size: 0.9rem;
            color: var(--text-secondary); margin-top: 0.3rem;
        }}

        .log-details {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem;
            margin-top: 1rem;
        }}

        .log-detail-item {{
            background-color: var(--card-bg); padding: 0.8rem;
            border-radius: 8px; text-align: center;
        }}

        .log-detail-label {{
            font-size: 0.8rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px;
        }}

        .log-detail-value {{
            font-family: 'Share Tech Mono', monospace; font-size: 1rem;
            color: var(--accent); margin-top: 0.3rem;
        }}

        .map-section {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; margin: 2rem 0;
            text-align: center;
        }}

        .map-title {{
            font-family: 'Share Tech Mono', monospace; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; margin-bottom: 1rem;
            border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem;
        }}

        .map-placeholder {{
            background-color: var(--card-bg); border-radius: 10px; 
            height: 300px; display: flex; align-items: center; justify-content: center;
            color: var(--text-secondary); font-size: 1.2rem;
        }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem;
        }}

        /* Nuevos estilos para directorios */
        .directory-section {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; margin: 2rem 0;
        }}
        
        .directory-title {{
            font-family: 'Share Tech Mono', monospace; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; margin-bottom: 1rem;
            border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem;
        }}
        
        .directory-list {{
            margin-left: 20px;
        }}
        
        .directory-item {{
            margin: 0.5rem 0;
        }}
        
        .directory-name {{
            font-family: 'Share Tech Mono', monospace;
            color: var(--accent);
            cursor: pointer;
        }}
        
        .directory-files {{
            margin-left: 20px;
            display: none;
        }}
        
        .directory-file {{
            background-color: var(--card-bg);
            padding: 0.5rem;
            border-radius: 5px;
            margin: 0.3rem 0;
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.9rem;
            color: var(--text-secondary);
        }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .log-header {{ flex-direction: column; align-items: flex-start; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Análisis de Logs DJI</h1>
            <p class="subtitle">📅 Análisis generado el {results["metadata"]["timestamp"]}</p>
        </div>

        <!-- Resumen -->
        <div class="summary-section">
            <div class="summary-item">
                <div class="summary-value">{results["files_count"]}</div>
                <div class="summary-label">Archivos Analizados</div>
            </div>
            <div class="summary-item">
                <div class="summary-value">{len(results["flight_data"]["dates"])}</div>
                <div class="summary-label">Fechas de Vuelo</div>
            </div>
            <div class="summary-item">
                <div class="summary-value">{len(results["flight_data"]["locations"])}</div>
                <div class="summary-label">Ubicaciones</div>
            </div>
            <div class="summary-item">
                <div class="summary-value">{round(results["metadata"]["total_size"] / 1024, 2)}</div>
                <div class="summary-label">KB Procesados</div>
            </div>
        </div>"""

    # Mostrar todos los archivos de log con información detallada (no limitarse a 5)
    for i, log in enumerate(results["logs"]):
        html += f"""
        <!-- Tarjeta de Log #{i+1} -->
        <div class="log-card">
            <div class="log-header">
                <div>
                    <div class="log-title">{log["name"]}</div>
                    <div class="log-path">{log["path"]}</div>
                </div>
            </div>
            
            <div class="log-details">
                <div class="log-detail-item">
                    <div class="log-detail-label">Tamaño</div>
                    <div class="log-detail-value">{log["size"]} bytes</div>
                </div>
                <div class="log-detail-item">
                    <div class="log-detail-label">Modificado</div>
                    <div class="log-detail-value">{log["modified"].split()[0]}</div>
                </div>"""
            
        # Añadir detalles de información extraída
        for key, value in log["extracted_data"].items():
            if key in ["latitude", "longitude", "location"]:
                continue  # Estos se muestran en otra sección
            html += f"""
                <div class="log-detail-item">
                    <div class="log-detail-label">{key.replace('_', ' ').title()}</div>
                    <div class="log-detail-value">{value}</div>
                </div>"""
                
        # Si tiene coordenadas, mostrarlas juntas
        if "latitude" in log["extracted_data"] and "longitude" in log["extracted_data"]:
            html += f"""
                <div class="log-detail-item">
                    <div class="log-detail-label">Coordenadas</div>
                    <div class="log-detail-value">{log["extracted_data"]["latitude"]}, {log["extracted_data"]["longitude"]}</div>
                </div>"""
        
        # Si tiene error, mostrarlo
        if "error" in log:
            html += f"""
                <div class="log-detail-item">
                    <div class="log-detail-label">Error</div>
                    <div class="log-detail-value" style="color: var(--danger);">{log["error"]}</div>
                </div>"""
        
        html += """
            </div>
        </div>"""
    
    # Resumen de modelos de dron
    if results["flight_data"]["drone_models"]:
        html += """
        <!-- Modelos de Dron -->
        <div class="map-section">
            <div class="map-title">Modelos de Dron Detectados</div>
            <div class="log-details">"""
            
        for model in results["flight_data"]["drone_models"]:
            html += f"""
                <div class="log-detail-item">
                    <div class="log-detail-value">{model}</div>
                </div>"""
                
        html += """
            </div>
        </div>"""
    
    # Sección de mapa si hay ubicaciones
    if results["flight_data"]["locations"]:
        html += """
        <!-- Sección de Mapa -->
        <div class="map-section">
            <div class="map-title">Ubicaciones de Vuelo</div>
            <div class="map-placeholder">
                Se han detectado ubicaciones GPS. Use las coordenadas para visualizar en un mapa externo.
            </div>
            <div class="log-details">"""
            
        for i, location in enumerate(results["flight_data"]["locations"]):
            html += f"""
                <div class="log-detail-item">
                    <div class="log-detail-label">Ubicación #{i+1}</div>
                    <div class="log-detail-value">{location}</div>
                </div>"""
                
        html += """
            </div>
        </div>"""
    
    # Pie de página
    html += f"""
        <div class="footer">
            <p>📁 Ruta del informe: <code>{output_path}</code></p>
            <p>DJI LogSage © 2025 - Analizador de Logs de Dron</p>
        </div>
    </div>

    <script>
        // Añadir interactividad para expandir/colapsar directorios
        document.addEventListener('DOMContentLoaded', function() {{
            const dirButtons = document.querySelectorAll('.directory-name');
            dirButtons.forEach(function(btn) {{
                btn.addEventListener('click', function() {{
                    const files = this.nextElementSibling;
                    if (files.style.display === 'none' || files.style.display === '') {{
                        files.style.display = 'block';
                        this.textContent = this.textContent.replace('►', '▼');
                    }} else {{
                        files.style.display = 'none';
                        this.textContent = this.textContent.replace('▼', '►');
                    }}
                }});
            }});
        }});
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generando informe: {e}")
        return False

def main():
    # Usar rutas relativas como se solicita
    base_path = Path.home() / "ForenSage"
    cache_path = base_path / "analyze/drone/sdcard/DJI/dji.pilot/LOG/CACHE"
    output_html = base_path / "results/ddrone_log_info.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    print(f"Analizando archivos en: {os.path.abspath(cache_path)}")
    print(f"El informe se guardará en: {os.path.abspath(output_html)}")
    
    # Verificar que la ruta existe
    if not os.path.exists(cache_path):
        print(f"❌ Error: La ruta {cache_path} no existe.")
        # Como alternativa, buscar rutas similares
        alternative_paths = [
            Path.home() / "ForenSage/analyze/drone/sdcard/DJI",
            Path.home() / "ForenSage/analyze/drone/sdcard",
            Path.home() / "ForenSage/analyze/drone"
        ]
        
        for alt_path in alternative_paths:
            if os.path.exists(alt_path):
                print(f"ℹ️ Ruta alternativa encontrada: {alt_path}")
                cache_path = alt_path
                print(f"ℹ️ Usando: {cache_path}")
                break
    
    # Analizar archivos de log
    results = analyze_dji_log_cache(cache_path)
    
    # Generar informe HTML
    generate_log_html(results, output_html)
    
    # Guardar también resultados JSON para posible uso posterior
    json_output = output_html.with_suffix('.json')
    try:
        with open(json_output, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, default=str)
        print(f"✅ Datos JSON guardados en: {json_output}")
    except Exception as e:
        print(f"❌ Error guardando JSON: {e}")

if __name__ == "__main__":
    main()