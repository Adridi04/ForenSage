import os
import datetime
from pathlib import Path
import re
import base64
import imghdr
import mimetypes

def analyze_cache_images(directory_path):
    """Analiza todas las imágenes en la carpeta de caché del DJI."""
    results = {}
    
    try:
        abs_directory = os.path.abspath(directory_path)
        if not os.path.exists(abs_directory):
            print(f"Error: Directorio no encontrado: {abs_directory}")
            return results, False
        
        print(f"Escaneando directorio: {abs_directory}")
        all_files = os.listdir(abs_directory)
        print(f"Encontrados {len(all_files)} archivos en el directorio")
        
        # Filtrar solo archivos de imagen
        image_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp']
        image_files = []
        
        for file in all_files:
            file_path = os.path.join(directory_path, file)
            if os.path.isfile(file_path):
                # Verificar por extensión
                if any(file.lower().endswith(ext) for ext in image_extensions):
                    image_files.append(file)
                # Verificar por contenido (archivos sin extensión)
                elif imghdr.what(file_path) is not None:
                    image_files.append(file)
        
        print(f"Encontrados {len(image_files)} archivos de imagen: {image_files[:5] if image_files else []}")
        
        if not image_files:
            print(f"No se encontraron imágenes en: {abs_directory}")
            return results, True
        
        for img_file in image_files:
            file_path = os.path.join(directory_path, img_file)
            file_data = {}
            
            try:
                # Obtener metadatos del archivo
                file_stat = os.stat(file_path)
                file_size = file_stat.st_size
                mod_time = datetime.datetime.fromtimestamp(file_stat.st_mtime)
                create_time = datetime.datetime.fromtimestamp(file_stat.st_ctime)
                
                # Determinar tipo de imagen
                img_type = imghdr.what(file_path) or "desconocido"
                mime_type = mimetypes.guess_type(file_path)[0] or f"image/{img_type}"
                
                # Generar una vista previa en base64 (solo para archivos pequeños)
                preview_base64 = None
                if file_size < 5000000:  # Limitar a 5MB
                    try:
                        with open(file_path, 'rb') as f:
                            img_data = f.read()
                            preview_base64 = base64.b64encode(img_data).decode('utf-8')
                    except Exception as e:
                        print(f"No se pudo generar vista previa para {file_path}: {e}")
                
                # Extraer información GPS a partir del nombre del archivo
                gps_coords = None
                gps_pattern = re.compile(r'(\d+\.\d+)[_\-](\d+\.\d+)')
                gps_match = gps_pattern.search(img_file)
                if gps_match:
                    gps_coords = (gps_match.group(1), gps_match.group(2))
                
                # Extraer fecha de vuelo del nombre del archivo
                date_pattern = re.compile(r'(\d{4})[_\-]?(\d{2})[_\-]?(\d{2})')
                date_match = date_pattern.search(img_file)
                flight_date = None
                if date_match:
                    year, month, day = date_match.groups()
                    flight_date = f"{year}-{month}-{day}"
                
                # Almacenar datos
                file_data = {
                    "size": file_size,
                    "size_mb": round(file_size / (1024 * 1024), 2),
                    "modified": mod_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "created": create_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "type": img_type,
                    "mime": mime_type,
                    "preview": preview_base64,
                    "gps": gps_coords,
                    "flight_date": flight_date
                }
                
                results[img_file] = {
                    "data": file_data,
                    "file_path": file_path,
                    "file_exists": True
                }
                
            except Exception as e:
                print(f"Error al analizar {file_path}: {e}")
                results[img_file] = {
                    "data": {},
                    "file_path": file_path,
                    "file_exists": os.path.exists(file_path),
                    "error": str(e)
                }
        
        return results, True
        
    except Exception as e:
        print(f"Error general: {e}")
        return results, False

def categorize_image(filename, data):
    """Categoriza las imágenes en caché basándose en patrones de nombre o metadatos"""
    if not data:
        return "Sin clasificar"
    
    filename_lower = filename.lower()
    
    # Buscar patrones en el nombre del archivo
    if "thumb" in filename_lower or "miniatura" in filename_lower:
        return "Miniatura"
    elif "screenshot" in filename_lower or "captura" in filename_lower:
        return "Captura de pantalla"
    elif any(x in filename_lower for x in ["panorama", "pano"]):
        return "Panorámica"
    elif any(x in filename_lower for x in ["burst", "ráfaga"]):
        return "Ráfaga"
    elif data.get("flight_date"):
        return f"Vuelo {data.get('flight_date')}"
    elif data.get("gps"):
        return "Geo-etiquetada"
    
    # Por defecto
    return "Foto de vuelo"

def generate_drone_images_html(results, directory_info, output_path):
    """Genera un informe HTML con las imágenes analizadas"""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error al crear directorio de salida: {e}")
            return False
    
    directory_path, directory_exists = directory_info
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    file_count = len(results)

    # Generar colores para diferentes categorías
    category_colors = {
        "Foto de vuelo": "#3498db",
        "Miniatura": "#2ecc71",
        "Captura de pantalla": "#e74c3c",
        "Panorámica": "#9b59b6",
        "Ráfaga": "#f39c12",
        "Geo-etiquetada": "#16a085"
    }
    
    # Añadir colores para categorías dinámicas
    for key in results.keys():
        category = categorize_image(key, results[key].get("data", {}))
        if category.startswith("Vuelo 20") and category not in category_colors:
            category_colors[category] = "#3498db"  # Mismo azul para todas las fechas de vuelo
    
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de Imágenes en Caché del Dron DJI</title>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #1a2b3c; --primary: #23374d; --primary-light: #345678;
            --accent: #00a8ff; --accent-light: #29b6f6; --text: #e0e6ed;
            --text-secondary: #a7b9cc; --background: #0a1622; --card-bg: #12202e;
            --border-color: rgba(0, 168, 255, 0.2); --success: #00e676;
            --warning: #ffab00; --danger: #ff1744; --grid-line: rgba(0, 168, 255, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Rajdhani', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(0, 168, 255, 0.05) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(0, 168, 255, 0.03) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.2;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Share Tech Mono', monospace; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
            display: flex; flex-direction: column; justify-content: center; align-items: center;
        }}

        .stat-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}

        .stat-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .stat-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;
        }}

        .stat-value {{ font-size: 2rem; font-weight: 700; color: var(--accent-light); }}

        .gallery-container {{ 
            margin-top: 2rem; margin-bottom: 2rem; 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }}

        .image-card {{
            background-color: var(--primary); border-radius: 12px;
            border-left: 4px solid var(--accent);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); position: relative; overflow: hidden;
            height: 100%; display: flex; flex-direction: column;
        }}

        .image-preview {{
            width: 100%;
            height: 200px;
            overflow: hidden;
            position: relative;
            background-color: #0a1520;
            display: flex;
            align-items: center;
            justify-content: center;
        }}

        .image-preview img {{
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }}

        .image-preview img:hover {{
            transform: scale(1.05);
        }}

        .image-details {{
            padding: 1.5rem;
        }}

        .image-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}

        .image-title {{
            font-family: 'Share Tech Mono', monospace; font-size: 1.1rem;
            color: var(--accent-light); font-weight: 600; display: flex; align-items: center;
            word-break: break-all;
        }}

        .image-status {{
            font-size: 0.8rem; padding: 0.3rem 0.8rem; border-radius: 12px;
            font-weight: 600; letter-spacing: 0.5px;
        }}

        .image-found {{ background-color: var(--success); color: #000; }}
        .image-not-found {{ background-color: var(--danger); color: var(--text); }}

        .image-info {{
            background-color: var(--card-bg); border-radius: 8px; padding: 1rem;
            margin-top: 1rem; border-left: 4px solid var(--accent);
            display: flex; flex-direction: column; flex-grow: 1;
        }}

        .image-stats {{
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 0.8rem;
            margin-top: 1rem;
        }}

        .image-stat-item {{
            background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem;
            border-radius: 6px;
            text-align: center;
        }}

        .image-stat-label {{
            font-size: 0.7rem;
            color: var(--text-secondary);
            text-transform: uppercase;
        }}

        .image-stat-value {{
            font-family: 'Share Tech Mono', monospace;
            font-size: 1rem;
            color: var(--accent);
        }}

        .drone-icon-container {{
            position: relative;
            text-align: center;
            margin: 2rem 0;
        }}

        .drone-icon {{
            width: 100px;
            height: 100px;
            position: relative;
            display: inline-block;
        }}

        .drone-body {{
            width: 40px;
            height: 10px;
            background-color: var(--accent);
            position: absolute;
            top: 45px;
            left: 30px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 168, 255, 0.5);
        }}

        .drone-arm1, .drone-arm2, .drone-arm3, .drone-arm4 {{
            width: 50px;
            height: 4px;
            background-color: var(--accent-light);
            position: absolute;
            border-radius: 2px;
        }}

        .drone-arm1 {{ transform: rotate(45deg); top: 35px; left: 15px; }}
        .drone-arm2 {{ transform: rotate(-45deg); top: 35px; left: 35px; }}
        .drone-arm3 {{ transform: rotate(135deg); top: 60px; left: 15px; }}
        .drone-arm4 {{ transform: rotate(-135deg); top: 60px; left: 35px; }}
        
        .drone-prop1, .drone-prop2, .drone-prop3, .drone-prop4 {{
            width: 20px;
            height: 4px;
            background-color: var(--accent);
            position: absolute;
            border-radius: 2px;
            animation: spin 1s linear infinite;
        }}
        
        .drone-prop1 {{ top: 25px; left: 10px; }}
        .drone-prop2 {{ top: 25px; left: 70px; }}
        .drone-prop3 {{ top: 70px; left: 10px; }}
        .drone-prop4 {{ top: 70px; left: 70px; }}
        
        @keyframes spin {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}

        .drone-shadow {{
            width: 60px;
            height: 12px;
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 50%;
            position: absolute;
            bottom: -20px;
            left: 20px;
            filter: blur(5px);
        }}

        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}

        .error-message {{ color: var(--danger); margin-top: 0.5rem; font-style: italic; font-size: 0.9rem; }}

        .category-badge {{
            padding: 0.2rem 0.6rem; border-radius: 10px; font-size: 0.75rem; 
            font-weight: 600; margin-top: 0.5rem; align-self: flex-start;
        }}

        .no-image {{
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-secondary);
            font-style: italic;
            height: 100%;
        }}

        .coords {{
            font-family: 'Share Tech Mono', monospace;
            color: var(--accent-light);
            font-size: 0.85rem;
            margin-top: 0.5rem;
        }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .image-header {{ flex-direction: column; align-items: flex-start; }}
            .image-status {{ margin-top: 0.5rem; }}
            .gallery-container {{ grid-template-columns: 1fr; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Imágenes en Caché del Dron DJI</h1>
            <p class="subtitle">📅 Análisis generado el {now}</p>
        </div>

        <!-- Ícono animado del Dron -->
        <div class="drone-icon-container">
            <div class="drone-icon">
                <div class="drone-body"></div>
                <div class="drone-arm1"></div>
                <div class="drone-arm2"></div>
                <div class="drone-arm3"></div>
                <div class="drone-arm4"></div>
                <div class="drone-prop1"></div>
                <div class="drone-prop2"></div>
                <div class="drone-prop3"></div>
                <div class="drone-prop4"></div>
                <div class="drone-shadow"></div>
            </div>
        </div>

        <!-- Dashboard de Estadísticas -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-label">Imágenes</div>
                <div class="stat-value">{file_count}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Directorio</div>
                <div class="stat-value">{os.path.basename(directory_path)}</div>
            </div>
        </div>"""

    if not directory_exists:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ Directorio no encontrado</div>
            <p>El directorio de imágenes en caché especificado no pudo ser encontrado.</p>
        </div>"""
    elif not results:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron imágenes</div>
            <p>No se encontraron imágenes en el directorio especificado.</p>
        </div>"""
    else:
        # Procesar archivos
        html += """
        <div class="gallery-container">"""
        
        for file_name, file_info in results.items():
            file_path = file_info["file_path"]
            file_exists = file_info["file_exists"]
            status_text = "Encontrado" if file_exists else "No encontrado"
            status_class = "image-found" if file_exists else "image-not-found"
            
            data = file_info.get("data", {})
            category = categorize_image(file_name, data)
            color = category_colors.get(category, "#7f8c8d")
            
            html += f"""
            <div class="image-card">
                <div class="image-preview">"""
            
            # Mostrar imagen si existe y tiene vista previa
            if file_exists and data and data.get("preview"):
                img_type = data.get("type", "jpeg")
                mime = data.get("mime", f"image/{img_type}")
                html += f"""
                    <img src="data:{mime};base64,{data['preview']}" alt="{file_name}">"""
            else:
                html += """
                    <div class="no-image">Vista previa no disponible</div>"""
            
            html += """
                </div>
                <div class="image-details">
                    <div class="image-header">
                        <div class="image-title">
                            <span style="margin-right:10px;">📷</span> {}</div>
                        <span class="image-status {}">{}</span>
                    </div>""".format(
                        file_name[:25] + "..." if len(file_name) > 25 else file_name,
                        status_class,
                        status_text
                    )
            
            if "error" in file_info:
                html += f"""
                    <div class="error-message">Error: {file_info["error"]}</div>"""
            
            if file_exists and data:
                # Extraer información
                file_size = data.get("size_mb", 0)
                modified = data.get("modified", "Desconocido")
                img_type = data.get("type", "Desconocido").upper()
                gps = data.get("gps", None)
                
                html += f"""
                    <div class="image-info">
                        <div class="image-stats">
                            <div class="image-stat-item">
                                <div class="image-stat-label">Tamaño</div>
                                <div class="image-stat-value">{file_size} MB</div>
                            </div>
                            <div class="image-stat-item">
                                <div class="image-stat-label">Tipo</div>
                                <div class="image-stat-value">{img_type}</div>
                            </div>
                            <div class="image-stat-item">
                                <div class="image-stat-label">Modificado</div>
                                <div class="image-stat-value">{modified.split()[0]}</div>
                            </div>
                            <div class="image-stat-item">
                                <div class="image-stat-label">Hora</div>
                                <div class="image-stat-value">{modified.split()[1]}</div>
                            </div>
                        </div>"""
                
                if gps:
                    html += f"""
                        <div class="coords">GPS: {gps[0]}, {gps[1]}</div>"""
                
                html += f"""
                        <span class="category-badge" style="background-color:{color};">{category}</span>
                    </div>"""
            
            html += """
                </div>
            </div>"""
        
        html += """
        </div>"""

    # Pie de página
    html += f"""
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath">{output_path}</code></p>
            <p>📁 Directorio analizado: <code>{directory_path}</code></p>
            <p>DroneSage © 2025 - Analizador de Imágenes en Caché de Drones</p>
        </div>
    </div>

   <script>
        // Establecer ruta absoluta para el informe
        document.getElementById('reportPath').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Usar rutas relativas para el directorio a analizar
    base_path = Path.home() / "ForenSage"
    directory_to_analyze = base_path / "analyze/drone/sdcard/DJI/dji.go.v4/CACHE_IMAGE/"
    abs_directory = os.path.abspath(directory_to_analyze)
    
    # Para la salida, usar la ruta especificada
    output_html = base_path / "results/drone_images_info.html"
    
    # Asegurar que el directorio de salida exista
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    print(f"Analizando directorio: {abs_directory}")
    print(f"La salida se guardará en: {os.path.abspath(output_html)}")
    
    # Analizar imágenes
    results, directory_exists = analyze_cache_images(directory_to_analyze)
    
    # Generar informe HTML
    generate_drone_images_html(results, (directory_to_analyze, directory_exists), output_html)

if __name__ == "__main__":
    main()