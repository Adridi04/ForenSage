import os
import datetime
from pathlib import Path
import re
import json
import time

def analyze_media_files(directory_path):
    """Analyzes MP4 and .INFO files in the given directory and extracts basic information."""
    results = {}
    
    try:
        abs_directory = os.path.abspath(directory_path)
        if not os.path.exists(abs_directory):
            print(f"Error: Directory not found: {abs_directory}")
            return results, False
        
        print(f"Scanning directory: {abs_directory}")
        all_files = os.listdir(abs_directory)
        print(f"Found {len(all_files)} files in directory")
        
        # Get list of MP4 files and INFO files
        mp4_files = [f for f in all_files if f.lower().endswith('.mp4')]
        info_files = [f for f in all_files if f.lower().endswith('.info')]
        
        print(f"Found {len(mp4_files)} MP4 files and {len(info_files)} INFO files")
        
        if not mp4_files and not info_files:
            print(f"No MP4 or INFO files found in: {abs_directory}")
            return results, True
        
        # Create a dictionary to store matching pairs
        file_pairs = {}
        
        # Find matching pairs based on base filename
        for mp4_file in mp4_files:
            base_name = mp4_file[:-4]  # Remove .mp4 extension
            info_file = base_name + ".info"
            
            if info_file in info_files:
                file_pairs[base_name] = {
                    "mp4": mp4_file,
                    "info": info_file
                }
            else:
                file_pairs[base_name] = {
                    "mp4": mp4_file,
                    "info": None
                }
        
        # Add any INFO files that don't have matching MP4s
        for info_file in info_files:
            base_name = info_file[:-5]  # Remove .info extension
            if base_name not in file_pairs:
                file_pairs[base_name] = {
                    "mp4": None,
                    "info": info_file
                }
        
        # Process each file pair
        for base_name, files in file_pairs.items():
            file_data = {
                "base_name": base_name,
                "mp4_exists": files["mp4"] is not None,
                "info_exists": files["info"] is not None,
                "mp4_data": {},
                "info_data": {}
            }
            
            # Process MP4 file if it exists
            if files["mp4"]:
                mp4_path = os.path.join(directory_path, files["mp4"])
                try:
                    # Get file metadata
                    file_stat = os.stat(mp4_path)
                    file_size = file_stat.st_size
                    mod_time = datetime.datetime.fromtimestamp(file_stat.st_mtime)
                    creation_time = extract_timestamp_from_filename(files["mp4"])
                    
                    file_data["mp4_data"] = {
                        "filename": files["mp4"],
                        "path": mp4_path,
                        "size": file_size,
                        "size_mb": round(file_size / (1024 * 1024), 2),
                        "modified": mod_time.strftime("%Y-%m-%d %H:%M:%S"),
                        "creation_time": creation_time
                    }
                except Exception as e:
                    print(f"Error analyzing MP4 file {mp4_path}: {e}")
                    file_data["mp4_data"] = {
                        "filename": files["mp4"],
                        "path": mp4_path,
                        "error": str(e)
                    }
            
            # Process INFO file if it exists
            if files["info"]:
                info_path = os.path.join(directory_path, files["info"])
                try:
                    # Get file metadata
                    file_stat = os.stat(info_path)
                    file_size = file_stat.st_size
                    mod_time = datetime.datetime.fromtimestamp(file_stat.st_mtime)
                    
                    # Read INFO file content
                    info_content = {}
                    gps_data = {}
                    
                    try:
                        with open(info_path, 'r', encoding='utf-8', errors='replace') as f:
                            content = f.read()
                            
                            # Extract GPS data if available
                            lat_pattern = re.compile(r'latitude["\s:]+([+-]?\d+\.\d+)', re.IGNORECASE)
                            lon_pattern = re.compile(r'longitude["\s:]+([+-]?\d+\.\d+)', re.IGNORECASE)
                            alt_pattern = re.compile(r'altitude["\s:]+([+-]?\d+\.?\d*)', re.IGNORECASE)
                            
                            lat_match = lat_pattern.search(content)
                            lon_match = lon_pattern.search(content)
                            alt_match = alt_pattern.search(content)
                            
                            if lat_match and lon_match:
                                gps_data["latitude"] = lat_match.group(1)
                                gps_data["longitude"] = lon_match.group(1)
                                
                                if alt_match:
                                    gps_data["altitude"] = alt_match.group(1)
                            
                            # Try to parse as JSON
                            try:
                                info_content = json.loads(content)
                            except json.JSONDecodeError:
                                # Not valid JSON, store a preview
                                info_content = {"preview": content[:300] + ("..." if len(content) > 300 else "")}
                                
                                # Try to extract additional data with regex
                                battery_pattern = re.compile(r'battery["\s:]+(\d+)', re.IGNORECASE)
                                device_pattern = re.compile(r'device[_\s]?name["\s:]+([^,"\s]+)', re.IGNORECASE)
                                
                                battery_match = battery_pattern.search(content)
                                device_match = device_pattern.search(content)
                                
                                if battery_match:
                                    info_content["battery"] = battery_match.group(1)
                                
                                if device_match:
                                    info_content["device_name"] = device_match.group(1)
                    except Exception as read_error:
                        info_content = {"error_reading": str(read_error)}
                    
                    file_data["info_data"] = {
                        "filename": files["info"],
                        "path": info_path,
                        "size": file_size,
                        "modified": mod_time.strftime("%Y-%m-%d %H:%M:%S"),
                        "content": info_content,
                        "gps_data": gps_data
                    }
                except Exception as e:
                    print(f"Error analyzing INFO file {info_path}: {e}")
                    file_data["info_data"] = {
                        "filename": files["info"],
                        "path": info_path,
                        "error": str(e)
                    }
            
            # Store the result
            results[base_name] = file_data
        
        return results, True
        
    except Exception as e:
        print(f"General error: {e}")
        return results, False

def extract_timestamp_from_filename(filename):
    """Extract date and time from DJI filename format."""
    # Common DJI filename format: DJI_YYYY_MM_DD_HHMMSS_XXX.mp4
    pattern = re.compile(r'DJI_(\d{4})_?(\d{2})_?(\d{2})_?(\d{2})(\d{2})(\d{2})')
    match = pattern.search(filename)
    
    if match:
        year, month, day, hour, minute, second = match.groups()
        return f"{year}-{month}-{day} {hour}:{minute}:{second}"
    
    # Alternative format: DJI_YYYYMMDD_HHMMSS.mp4
    alt_pattern = re.compile(r'DJI_(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})')
    alt_match = alt_pattern.search(filename)
    
    if alt_match:
        year, month, day, hour, minute, second = alt_match.groups()
        return f"{year}-{month}-{day} {hour}:{minute}:{second}"
    
    return "Unknown"

def categorize_media(data):
    """Categorize media based on available data"""
    # Extract GPS data if available
    has_gps = False
    if data["info_exists"] and "gps_data" in data["info_data"] and data["info_data"]["gps_data"]:
        has_gps = True
    
    # Check for file times
    creation_time = None
    if data["mp4_exists"] and "creation_time" in data["mp4_data"]:
        creation_time = data["mp4_data"]["creation_time"]
    
    # Categorize based on presence of GPS data and file size
    if data["mp4_exists"]:
        file_size_mb = data["mp4_data"].get("size_mb", 0)
        
        if file_size_mb > 500:
            return "Long Flight", "🛫"
        elif file_size_mb > 200:
            return "Medium Flight", "✈️"
        elif file_size_mb > 50:
            return "Short Flight", "🚁"
        else:
            return "Quick Capture", "📸"
    else:
        return "Info Only", "ℹ️"

def generate_video_records_html(results, directory_info, output_path):
    """Generates an HTML report with the analyzed media files"""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    directory_path, directory_exists = directory_info
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    file_count = len(results)
    
    # Generate colors for different categories
    category_colors = {
        "Long Flight": "#e74c3c",
        "Medium Flight": "#f39c12", 
        "Short Flight": "#2ecc71",
        "Quick Capture": "#3498db",
        "Info Only": "#95a5a6"
    }
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DJI Media Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #1a2b3c; --primary: #23374d; --primary-light: #345678;
            --accent: #00a8ff; --accent-light: #29b6f6; --text: #e0e6ed;
            --text-secondary: #a7b9cc; --background: #0a1622; --card-bg: #12202e;
            --border-color: rgba(0, 168, 255, 0.2); --success: #00e676;
            --warning: #ffab00; --danger: #ff1744; --grid-line: rgba(0, 168, 255, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Rajdhani', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(0, 168, 255, 0.05) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(0, 168, 255, 0.03) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.2;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Share Tech Mono', monospace; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
            display: flex; flex-direction: column; justify-content: center; align-items: center;
        }}

        .stat-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}

        .stat-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .stat-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;
        }}

        .stat-value {{ font-size: 2rem; font-weight: 700; color: var(--accent-light); }}

        .media-container {{ 
            margin-top: 2rem; margin-bottom: 2rem; 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
        }}

        .media-card {{
            background-color: var(--primary); border-radius: 12px;
            padding: 1.5rem; border-left: 4px solid var(--accent);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); position: relative; overflow: hidden;
            height: 100%; display: flex; flex-direction: column;
        }}

        .media-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}

        .media-title {{
            font-family: 'Share Tech Mono', monospace; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; display: flex; align-items: center;
        }}

        .category-badge {{
            padding: 0.2rem 0.6rem; border-radius: 10px; font-size: 0.75rem; 
            font-weight: 600; margin-top: 0.5rem; align-self: flex-start;
        }}

        .file-info {{
            background-color: var(--card-bg); border-radius: 8px; padding: 1rem;
            margin-top: 1rem; border-left: 4px solid var(--accent);
            display: flex; flex-direction: column; flex-grow: 1;
        }}

        .file-section {{
            margin-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 1rem;
        }}

        .file-section:last-child {{
            border-bottom: none;
            padding-bottom: 0;
        }}

        .file-section-title {{
            font-size: 1rem;
            font-weight: 600;
            color: var(--accent);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        .file-property {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.3rem;
        }}

        .property-name {{
            color: var(--text-secondary);
            font-size: 0.9rem;
        }}

        .property-value {{
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.9rem;
            color: var(--text);
        }}

        .gps-data {{
            background-color: rgba(0, 0, 0, 0.2);
            padding: 0.8rem;
            border-radius: 6px;
            margin-top: 0.5rem;
        }}

        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .media-header {{ flex-direction: column; align-items: flex-start; }}
            .media-container {{ grid-template-columns: 1fr; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">DJI Media Analysis</h1>
            <p class="subtitle">📅 Analysis Generated on {now}</p>
        </div>

        <!-- Dashboard Stats -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-label">Media Records</div>
                <div class="stat-value">{file_count}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Directory</div>
                <div class="stat-value">{os.path.basename(directory_path)}</div>
            </div>
        </div>"""

    if not directory_exists:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ Directory not found</div>
            <p>The specified media directory could not be found.</p>
        </div>"""
    elif not results:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No media files found</div>
            <p>No MP4 or INFO files were found in the specified directory.</p>
        </div>"""
    else:
        # Process files
        html += """
        <div class="media-container">"""
        
        for base_name, data in results.items():
            category, icon = categorize_media(data)
            color = category_colors.get(category, "#7f8c8d")
            
            html += f"""
            <div class="media-card">
                <div class="media-header">
                    <div class="media-title">
                        <span style="margin-right:10px;">{icon}</span> {base_name}
                    </div>
                </div>"""
            
            # MP4 File Section
            if data["mp4_exists"]:
                mp4_data = data["mp4_data"]
                html += f"""
                <div class="file-info">
                    <div class="file-section">
                        <div class="file-section-title">
                            <span style="margin-right:8px;">🎬</span> MP4 File
                        </div>
                        <div class="file-property">
                            <span class="property-name">Filename:</span>
                            <span class="property-value">{mp4_data["filename"]}</span>
                        </div>
                        <div class="file-property">
                            <span class="property-name">Size:</span>
                            <span class="property-value">{mp4_data.get("size_mb", 0)} MB</span>
                        </div>
                        <div class="file-property">
                            <span class="property-name">Created:</span>
                            <span class="property-value">{mp4_data.get("creation_time", "Unknown")}</span>
                        </div>
                        <div class="file-property">
                            <span class="property-name">Modified:</span>
                            <span class="property-value">{mp4_data.get("modified", "Unknown")}</span>
                        </div>
                    </div>"""
            
                # INFO File Section
                if data["info_exists"]:
                    info_data = data["info_data"]
                    gps_data = info_data.get("gps_data", {})
                    
                    html += f"""
                    <div class="file-section">
                        <div class="file-section-title">
                            <span style="margin-right:8px;">ℹ️</span> INFO File
                        </div>
                        <div class="file-property">
                            <span class="property-name">Filename:</span>
                            <span class="property-value">{info_data["filename"]}</span>
                        </div>
                        <div class="file-property">
                            <span class="property-name">Size:</span>
                            <span class="property-value">{info_data.get("size", 0)} bytes</span>
                        </div>
                        <div class="file-property">
                            <span class="property-name">Modified:</span>
                            <span class="property-value">{info_data.get("modified", "Unknown")}</span>
                        </div>"""
                    
                    # Add GPS data if available
                    if gps_data:
                        html += f"""
                        <div class="gps-data">
                            <div class="file-property">
                                <span class="property-name">Latitude:</span>
                                <span class="property-value">{gps_data.get("latitude", "N/A")}</span>
                            </div>
                            <div class="file-property">
                                <span class="property-name">Longitude:</span>
                                <span class="property-value">{gps_data.get("longitude", "N/A")}</span>
                            </div>"""
                        
                        if "altitude" in gps_data:
                            html += f"""
                            <div class="file-property">
                                <span class="property-name">Altitude:</span>
                                <span class="property-value">{gps_data.get("altitude", "N/A")} m</span>
                            </div>"""
                        
                        html += """
                        </div>"""
                    
                    html += """
                    </div>"""
                
                html += f"""
                    <span class="category-badge" style="background-color:{color};">{category}</span>
                </div>"""
            elif data["info_exists"]:
                # Only INFO file exists
                info_data = data["info_data"]
                gps_data = info_data.get("gps_data", {})
                
                html += f"""
                <div class="file-info">
                    <div class="file-section">
                        <div class="file-section-title">
                            <span style="margin-right:8px;">ℹ️</span> INFO File Only
                        </div>
                        <div class="file-property">
                            <span class="property-name">Filename:</span>
                            <span class="property-value">{info_data["filename"]}</span>
                        </div>
                        <div class="file-property">
                            <span class="property-name">Size:</span>
                            <span class="property-value">{info_data.get("size", 0)} bytes</span>
                        </div>
                        <div class="file-property">
                            <span class="property-name">Modified:</span>
                            <span class="property-value">{info_data.get("modified", "Unknown")}</span>
                        </div>"""
                
                # Add GPS data if available
                if gps_data:
                    html += f"""
                    <div class="gps-data">
                        <div class="file-property">
                            <span class="property-name">Latitude:</span>
                            <span class="property-value">{gps_data.get("latitude", "N/A")}</span>
                        </div>
                        <div class="file-property">
                            <span class="property-name">Longitude:</span>
                            <span class="property-value">{gps_data.get("longitude", "N/A")}</span>
                        </div>"""
                    
                    if "altitude" in gps_data:
                        html += f"""
                        <div class="file-property">
                            <span class="property-name">Altitude:</span>
                            <span class="property-value">{gps_data.get("altitude", "N/A")} m</span>
                        </div>"""
                    
                    html += """
                    </div>"""
                
                html += f"""
                    </div>
                    <span class="category-badge" style="background-color:{color};">{category}</span>
                </div>"""
            
            html += """
            </div>"""
        
        html += """
        </div>"""

    # Footer
    html += f"""
        <div class="footer">
            <p>📁 Report path: <code id="reportPath">{output_path}</code></p>
            <p>📁 Directory analyzed: <code>{directory_path}</code></p>
            <p>DroneSage © 2025 - DJI Media Analyzer</p>
        </div>
    </div>

   <script>
        // Set absolute path for report
        document.getElementById('reportPath').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # Use relative paths for directory to analyze
    # Using the path provided by the user
    base_path = Path.home() / "ForenSage"
    directory_to_analyze = base_path / "analyze/drone/sdcard/DJI/dji.go.v4/DJI_RECORD/"
    abs_directory = os.path.abspath(directory_to_analyze)
    
    # For output, use the specified path
    output_html = base_path / "results/drone_media_analysis.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    print(f"Analyzing directory: {abs_directory}")
    print(f"Output will be saved to: {os.path.abspath(output_html)}")
    
    # Start time tracking
    start_time = time.time()
    
    # Analyze media files
    results, directory_exists = analyze_media_files(directory_to_analyze)
    
    # Generate HTML report
    generate_video_records_html(results, (directory_to_analyze, directory_exists), output_html)
    
    # End time tracking
    end_time = time.time()
    print(f"Analysis completed in {end_time - start_time:.2f} seconds")

if __name__ == "__main__":
    main()