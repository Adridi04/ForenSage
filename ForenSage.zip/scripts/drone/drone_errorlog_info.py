import os
import datetime
import re
from pathlib import Path

def analyze_error_logs(log_dir):
    """Analiza archivos de error en el directorio especificado sin asumir formato."""
    results = {
        "log_files": [],
        "total_errors": 0,
        "error_categories": {},
        "first_error_date": None,
        "last_error_date": None
    }
    
    try:
        # Verificar si el directorio existe
        if not os.path.exists(log_dir):
            print(f"Error: Directorio no encontrado: {log_dir}")
            return results, False
            
        # Obtener todos los archivos en el directorio (no solo .txt)
        log_files = [f for f in os.listdir(log_dir) if os.path.isfile(os.path.join(log_dir, f))]
        
        if not log_files:
            print(f"No se encontraron archivos en {log_dir}")
            return results, False
            
        print(f"Se encontraron {len(log_files)} archivos en {log_dir}")
        
        # Procesar cada archivo
        for log_file in log_files:
            file_path = os.path.join(log_dir, log_file)
            file_info = process_simple_log_file(file_path)
            
            if file_info:
                results["log_files"].append(file_info)
                results["total_errors"] += 1
                
                # Categorizamos por nombre de archivo o fecha si no hay tipo de error
                category = file_info.get("error_type", os.path.basename(file_path))
                if category in results["error_categories"]:
                    results["error_categories"][category] += 1
                else:
                    results["error_categories"][category] = 1
                
                # Actualizar rango de fechas
                file_date = file_info.get("file_date")
                if file_date:
                    if results["first_error_date"] is None or file_date < results["first_error_date"]:
                        results["first_error_date"] = file_date
                    if results["last_error_date"] is None or file_date > results["last_error_date"]:
                        results["last_error_date"] = file_date
        
        # Formatear fechas para la salida
        if results["first_error_date"]:
            results["first_error_date"] = results["first_error_date"].strftime("%Y-%m-%d %H:%M:%S")
        if results["last_error_date"]:
            results["last_error_date"] = results["last_error_date"].strftime("%Y-%m-%d %H:%M:%S")
            
        return results, True
        
    except Exception as e:
        print(f"Error al analizar archivos: {e}")
        return results, False

def find_dates_in_content(content):
    """Busca cualquier patrón de fecha en el contenido del archivo."""
    # Patrones de fecha comunes
    date_patterns = [
        r'(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})',  # YYYY-MM-DD HH:MM:SS
        r'(\d{2}/\d{2}/\d{4}\s\d{2}:\d{2}:\d{2})',  # MM/DD/YYYY HH:MM:SS
        r'(\d{2}-\d{2}-\d{4}\s\d{2}:\d{2}:\d{2})',  # DD-MM-YYYY HH:MM:SS
        r'(\d{4}/\d{2}/\d{2}\s\d{2}:\d{2}:\d{2})',  # YYYY/MM/DD HH:MM:SS
        r'(\d{2}/\d{2}/\d{2}\s\d{2}:\d{2}:\d{2})',  # DD/MM/YY HH:MM:SS
        r'(\d{1,2}\s(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s\d{4}\s\d{2}:\d{2}:\d{2})'  # D Mon YYYY HH:MM:SS
    ]
    
    for pattern in date_patterns:
        matches = re.findall(pattern, content)
        if matches:
            return matches
    
    return []

def process_simple_log_file(file_path):
    """Procesa un archivo de error extrayendo su contenido completo y metadata."""
    try:
        file_info = {
            "filename": os.path.basename(file_path),
            "file_path": file_path,
            "file_size": os.path.getsize(file_path),
            "modified": datetime.datetime.fromtimestamp(os.path.getmtime(file_path)).strftime("%Y-%m-%d %H:%M:%S"),
            "created": datetime.datetime.fromtimestamp(os.path.getctime(file_path)).strftime("%Y-%m-%d %H:%M:%S"),
            "error_type": "",
            "dates_found": [],
            "content": ""
        }
        
        # Fecha del archivo para ordenar y determinar rango
        file_info["file_date"] = datetime.datetime.fromtimestamp(os.path.getmtime(file_path))
        
        # Intentar leer el archivo con diferentes codificaciones
        encodings = ['utf-8', 'latin-1', 'cp1252', 'ascii']
        content = None
        
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding, errors='replace') as f:
                    content = f.read()
                break
            except Exception:
                continue
        
        if content:
            file_info["content"] = content
            
            # Buscar fechas en el contenido
            dates = find_dates_in_content(content)
            if dates:
                file_info["dates_found"] = dates
                
            # Usar la primera línea como tipo de error si no está vacía y es corta
            lines = content.split('\n')
            if lines and lines[0].strip():
                first_line = lines[0].strip()
                if len(first_line) < 100:  # Longitud razonable
                    file_info["error_type"] = first_line
        
        return file_info
        
    except Exception as e:
        print(f"Error al procesar el archivo {file_path}: {e}")
        try:
            # En caso de error, devolver al menos la información básica del archivo
            return {
                "filename": os.path.basename(file_path),
                "file_path": file_path,
                "file_size": os.path.getsize(file_path),
                "modified": datetime.datetime.fromtimestamp(os.path.getmtime(file_path)).strftime("%Y-%m-%d %H:%M:%S"),
                "error_type": "Error al leer archivo",
                "content": f"No se pudo leer el contenido: {str(e)}",
                "file_date": datetime.datetime.fromtimestamp(os.path.getmtime(file_path))
            }
        except:
            return None

def generate_error_log_report(results, output_path):
    """Genera un informe HTML simple para el análisis de errores."""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error al crear el directorio de salida: {e}")
            return False
    
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de Errores DJI</title>
    <style>
        :root {{
            --primary: #23374d;
            --accent: #00a8ff; 
            --text: #e0e6ed;
            --text-secondary: #a7b9cc; 
            --background: #0a1622; 
            --card-bg: #12202e;
            --border-color: #345678;
        }}

        body {{
            font-family: Arial, sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }}

        .header {{
            text-align: center;
            margin-bottom: 30px;
        }}
        
        .title {{
            font-size: 28px;
            color: var(--accent);
            margin-bottom: 10px;
        }}

        .summary-section {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}

        .summary-card {{
            background: var(--primary);
            border-radius: 8px;
            padding: 20px;
            text-align: center;
        }}

        .summary-title {{
            font-size: 18px;
            color: var(--text-secondary);
            margin-bottom: 10px;
        }}

        .summary-value {{
            font-size: 24px;
            color: var(--accent);
            font-weight: bold;
        }}

        .error-list {{
            background: var(--primary);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
        }}
        
        .error-list-title {{
            font-size: 20px;
            color: var(--accent);
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 10px;
        }}

        .error-item {{
            background-color: var(--card-bg);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid var(--accent);
        }}

        .error-header {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }}

        .error-filename {{
            font-size: 18px;
            color: var(--accent);
            font-weight: bold;
        }}

        .error-date {{
            color: var(--text-secondary);
        }}

        .error-content {{
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 6px;
            padding: 15px;
            font-family: monospace;
            font-size: 14px;
            max-height: 200px;
            overflow-y: auto;
            white-space: pre-wrap;
            word-break: break-word;
        }}

        .categories-section {{
            background: var(--primary);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
        }}

        .categories-title {{
            font-size: 20px;
            color: var(--accent);
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 10px;
        }}

        .category-item {{
            display: flex;
            justify-content: space-between;
            padding: 10px;
            background-color: var(--card-bg);
            border-radius: 6px;
            margin-bottom: 10px;
        }}

        .footer {{
            text-align: center;
            margin-top: 30px;
            color: var(--text-secondary);
            border-top: 1px solid var(--border-color);
            padding-top: 20px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Análisis de Errores DJI</h1>
            <p>Análisis generado el {now}</p>
        </div>

        <!-- Resumen -->
        <div class="summary-section">
            <div class="summary-card">
                <div class="summary-title">Total de Archivos</div>
                <div class="summary-value">{results["total_errors"]}</div>
            </div>
            <div class="summary-card">
                <div class="summary-title">Primer Error</div>
                <div class="summary-value" style="font-size: 18px;">
                    {results["first_error_date"] if results["first_error_date"] else "N/A"}
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-title">Último Error</div>
                <div class="summary-value" style="font-size: 18px;">
                    {results["last_error_date"] if results["last_error_date"] else "N/A"}
                </div>
            </div>
        </div>"""

    # Sección de Categorías (si hay categorías identificadas)
    if results["error_categories"]:
        html += f"""
        <div class="categories-section">
            <div class="categories-title">Categorías de Archivos</div>"""
            
        for category, count in sorted(results["error_categories"].items(), key=lambda x: x[1], reverse=True)[:10]:  # Mostrar solo las 10 principales
            html += f"""
            <div class="category-item">
                <div>{category}</div>
                <div>{count}</div>
            </div>"""
            
        html += """
        </div>"""

    # Lista de archivos de error
    html += """
        <div class="error-list">
            <div class="error-list-title">Archivos Encontrados</div>"""
            
    # Ordenar los archivos por fecha de modificación (más recientes primero)
    sorted_files = sorted(results["log_files"], 
                          key=lambda x: x.get("file_date", datetime.datetime.now()), 
                          reverse=True)
    
    for log_file in sorted_files:
        # Determinar qué fecha mostrar (prioridad: fechas encontradas en contenido, luego fecha de modificación)
        display_date = log_file.get("modified", "Fecha desconocida")
        if log_file.get("dates_found") and log_file["dates_found"]:
            display_date = log_file["dates_found"][0]  # Usar la primera fecha encontrada
        
        # Determinar qué mostrar como título (prioridad: tipo de error, luego nombre de archivo)
        display_title = log_file.get("error_type", "")
        if not display_title:
            display_title = log_file["filename"]
            
        html += f"""
            <div class="error-item">
                <div class="error-header">
                    <div class="error-filename">{display_title}</div>
                    <div class="error-date">{display_date}</div>
                </div>
                <div class="error-content">{log_file["content"]}</div>
            </div>"""
    
    html += """
        </div>

        <div class="footer">
            <p>DroneSage © 2025 - Analizador de Errores DJI</p>
        </div>
    </div>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error al generar informe: {e}")
        return False

def main():
    # Usar rutas relativas para el directorio de errores
    base_path = Path.home() / "ForenSage"
    log_dir = base_path / "analyze/drone/sdcard/DJI/dji.pilot/LOG/ERROR_POP_LOG"
    
    # Para la salida, usar un directorio de resultados
    output_html = base_path / "results/drone_errorlog_info.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    print(f"Analizando archivos en: {os.path.abspath(log_dir)}")
    print(f"El resultado se guardará en: {os.path.abspath(output_html)}")
    
    # Analizar archivos
    results, success = analyze_error_logs(log_dir)
    
    # Generar informe HTML
    if success:
        generate_error_log_report(results, output_html)
    else:
        print("No se pudo completar el análisis.")

if __name__ == "__main__":
    main()