import os
import re
import json
import datetime
from pathlib import Path

def extract_coordinates_from_file(file_path):
    """Extract GPS coordinates from flight record files."""
    coordinates = []
    timestamp_pattern = re.compile(r'OSD.createDate : (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})')
    lat_pattern = re.compile(r'OSD.latitude : ([-+]?\d*\.\d+|\d+)')
    lon_pattern = re.compile(r'OSD.longitude : ([-+]?\d*\.\d+|\d+)')
    alt_pattern = re.compile(r'OSD.altitude : ([-+]?\d*\.\d+|\d+)')
    
    current_point = {"timestamp": None, "lat": None, "lon": None, "alt": None}
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            for line in f:
                # Check for timestamp
                timestamp_match = timestamp_pattern.search(line)
                if timestamp_match:
                    # If we already have a point with coordinates, save it
                    if current_point["lat"] is not None and current_point["lon"] is not None:
                        coordinates.append(current_point.copy())
                    
                    # Start a new point
                    current_point = {
                        "timestamp": timestamp_match.group(1),
                        "lat": None, 
                        "lon": None,
                        "alt": None
                    }
                    continue
                
                # Check for latitude
                lat_match = lat_pattern.search(line)
                if lat_match:
                    try:
                        current_point["lat"] = float(lat_match.group(1))
                    except ValueError:
                        pass
                    continue
                
                # Check for longitude
                lon_match = lon_pattern.search(line)
                if lon_match:
                    try:
                        current_point["lon"] = float(lon_match.group(1))
                    except ValueError:
                        pass
                    continue
                
                # Check for altitude
                alt_match = alt_pattern.search(line)
                if alt_match:
                    try:
                        current_point["alt"] = float(alt_match.group(1))
                    except ValueError:
                        pass
                    continue
            
            # Don't forget to add the last point if it has coordinates
            if current_point["lat"] is not None and current_point["lon"] is not None:
                coordinates.append(current_point)
    
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
    
    return coordinates

def analyze_flight_records(directory_path):
    """Analyze all flight record files in the given directory."""
    flight_data = []
    metadata = {
        "total_files": 0,
        "processed_files": 0,
        "flight_dates": set(),
        "min_lat": 90,
        "max_lat": -90,
        "min_lon": 180,
        "max_lon": -180,
        "total_points": 0
    }
    
    try:
        if not os.path.exists(directory_path):
            print(f"Directory not found: {directory_path}")
            return flight_data, metadata, False
        
        # Find all .txt files in the directory and its subdirectories
        txt_files = []
        for root, _, files in os.walk(directory_path):
            for file in files:
                if file.endswith('.txt'):
                    txt_files.append(os.path.join(root, file))
        
        metadata["total_files"] = len(txt_files)
        
        # Process each file
        for file_path in txt_files:
            file_name = os.path.basename(file_path)
            print(f"Processing file: {file_name}")
            
            coordinates = extract_coordinates_from_file(file_path)
            
            if coordinates:
                # Add file info
                file_info = {
                    "file_name": file_name,
                    "file_path": file_path,
                    "points": coordinates,
                    "point_count": len(coordinates)
                }
                
                # Extract flight date from the first point if available
                if coordinates[0]["timestamp"]:
                    flight_date = coordinates[0]["timestamp"].split()[0]
                    file_info["flight_date"] = flight_date
                    metadata["flight_dates"].add(flight_date)
                
                # Update min/max coordinates for map bounds
                for point in coordinates:
                    if point["lat"] is not None and point["lon"] is not None:
                        metadata["min_lat"] = min(metadata["min_lat"], point["lat"])
                        metadata["max_lat"] = max(metadata["max_lat"], point["lat"])
                        metadata["min_lon"] = min(metadata["min_lon"], point["lon"])
                        metadata["max_lon"] = max(metadata["max_lon"], point["lon"])
                
                metadata["total_points"] += len(coordinates)
                flight_data.append(file_info)
                metadata["processed_files"] += 1
    
    except Exception as e:
        print(f"Error analyzing flight records: {e}")
        return flight_data, metadata, False
    
    # Convert set to list for JSON serialization
    metadata["flight_dates"] = list(metadata["flight_dates"])
    
    return flight_data, metadata, True

def generate_flight_report_html(flight_data, metadata, output_path):
    """Generate HTML report with flight path visualization."""
    if not flight_data:
        print("No flight data to generate report.")
        return False
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Calculate map center
    center_lat = (metadata["min_lat"] + metadata["max_lat"]) / 2
    center_lon = (metadata["min_lon"] + metadata["max_lon"]) / 2
    
    # Prepare flight data for JavaScript
    flight_paths_json = []
    for flight in flight_data:
        points = [{"lat": p["lat"], "lng": p["lon"], "alt": p["alt"], "timestamp": p["timestamp"]} 
                 for p in flight["points"] if p["lat"] is not None and p["lon"] is not None]
        
        if points:
            flight_paths_json.append({
                "name": flight["file_name"],
                "date": flight.get("flight_date", "Unknown"),
                "points": points
            })
    
    # Convert to JSON string for embedding in HTML
    flight_paths_js = json.dumps(flight_paths_json)
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DJI Flight Record Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #1a2b3c; --primary: #23374d; --primary-light: #345678;
            --accent: #00a8ff; --accent-light: #29b6f6; --text: #e0e6ed;
            --text-secondary: #a7b9cc; --background: #0a1622; --card-bg: #12202e;
            --border-color: rgba(0, 168, 255, 0.2); --success: #00e676;
            --warning: #ffab00; --danger: #ff1744; --grid-line: rgba(0, 168, 255, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Rajdhani', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(0, 168, 255, 0.05) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(0, 168, 255, 0.03) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.2;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 2rem; position: relative; }}

        .title {{
            font-family: 'Share Tech Mono', monospace; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 1rem; font-size: 1.1rem; }}

        .map-container {{
            height: 500px;
            margin: 1.5rem 0;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative;
        }}

        #map {{
            height: 100%;
            width: 100%;
        }}

        .dashboard {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: center;
        }}

        .stat-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
        }}

        .stat-card::before {{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .stat-value {{
            font-family: 'Share Tech Mono', monospace;
            font-size: 2.5rem;
            color: var(--accent);
            margin-bottom: 0.5rem;
        }}

        .stat-label {{
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 0.9rem;
        }}

        .flight-list {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 1.5rem;
            margin-top: 2rem;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }}

        .flight-list-title {{
            font-family: 'Share Tech Mono', monospace;
            font-size: 1.3rem;
            color: var(--accent-light);
            font-weight: 600;
            margin-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.5rem;
        }}

        .flight-item {{
            background-color: var(--card-bg);
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }}

        .flight-item:hover {{
            background-color: var(--primary-light);
        }}

        .flight-item-active {{
            border-left: 4px solid var(--accent);
            background-color: var(--primary-light);
        }}

        .flight-name {{
            font-family: 'Share Tech Mono', monospace;
            font-weight: 600;
        }}

        .flight-date {{
            color: var(--text-secondary);
            font-size: 0.9rem;
        }}

        .flight-points {{
            background-color: var(--accent);
            color: var(--text);
            padding: 0.2rem 0.5rem;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }}

        .footer {{
            text-align: center;
            margin-top: 3rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1.5rem;
        }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .map-container {{ height: 300px; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">DJI Flight Record Analysis</h1>
            <p class="subtitle">📅 Analysis Generated on {now}</p>
        </div>

        <!-- Map Container -->
        <div class="map-container">
            <div id="map"></div>
        </div>

        <!-- Stats Dashboard -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-value">{metadata["processed_files"]}</div>
                <div class="stat-label">Flight Records</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{len(metadata["flight_dates"])}</div>
                <div class="stat-label">Flight Days</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{metadata["total_points"]}</div>
                <div class="stat-label">GPS Points</div>
            </div>
        </div>

        <!-- Flight List -->
        <div class="flight-list">
            <div class="flight-list-title">Flight Records</div>
            <div id="flightItems">
                <!-- Flight items will be inserted here by JavaScript -->
            </div>
        </div>

        <div class="footer">
            <p>📁 Report path: <code id="reportPath">{output_path}</code></p>
            <p>DroneSage © 2025 - Flight Record Analyzer</p>
        </div>
    </div>

    <!-- Load Leaflet.js from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css" />

    <script>
        // Flight data from Python
        const flightPaths = {flight_paths_js};
        
        // Initialize the map
        const map = L.map('map').setView([{center_lat}, {center_lon}], 13);
        
        // Add OpenStreetMap tile layer
        L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }}).addTo(map);
        
        // Store all polylines for toggling visibility
        const polylines = [];
        const flightMarkers = [];
        
        // Colors for different flight paths
        const colors = [
            '#FF5252', '#FF4081', '#E040FB', '#7C4DFF', '#536DFE', 
            '#448AFF', '#40C4FF', '#18FFFF', '#64FFDA', '#69F0AE', 
            '#B2FF59', '#EEFF41', '#FFFF00', '#FFD740', '#FFAB40'
        ];
        
        // Create flight items list and add flight paths to map
        const flightItemsContainer = document.getElementById('flightItems');
        
        flightPaths.forEach((flight, index) => {{
            // Create flight item in the list
            const flightItem = document.createElement('div');
            flightItem.className = 'flight-item';
            flightItem.id = `flight-${{index}}`;
            flightItem.innerHTML = `
                <div>
                    <div class="flight-name">${{flight.name}}</div>
                    <div class="flight-date">${{flight.date}}</div>
                </div>
                <div class="flight-points">${{flight.points.length}} points</div>
            `;
            flightItemsContainer.appendChild(flightItem);
            
            // Create path coordinates for Leaflet
            const coordinates = flight.points.map(p => [p.lat, p.lng]);
            
            // Skip if no valid coordinates
            if (coordinates.length === 0) return;
            
            // Get color for this flight (cycle through colors array)
            const color = colors[index % colors.length];
            
            // Create polyline
            const polyline = L.polyline(coordinates, {{
                color: color,
                weight: 3,
                opacity: 0.8
            }}).addTo(map);
            
            // Add start and end markers
            const startMarker = L.marker(coordinates[0], {{
                title: `Start: ${{flight.name}}`,
                icon: L.divIcon({{
                    className: 'custom-div-icon',
                    html: `<div style="background-color: ${{color}}; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white;"></div>`,
                    iconSize: [12, 12],
                    iconAnchor: [6, 6]
                }})
            }}).addTo(map);
            
            const endMarker = L.marker(coordinates[coordinates.length - 1], {{
                title: `End: ${{flight.name}}`,
                icon: L.divIcon({{
                    className: 'custom-div-icon',
                    html: `<div style="background-color: black; width: 12px; height: 12px; border-radius: 50%; border: 2px solid ${{color}};"></div>`,
                    iconSize: [12, 12],
                    iconAnchor: [6, 6]
                }})
            }}).addTo(map);
            
            // Store references
            polylines.push(polyline);
            flightMarkers.push([startMarker, endMarker]);
            
            // Add click event to flight item
            flightItem.addEventListener('click', () => {{
                // Toggle active class
                document.querySelectorAll('.flight-item').forEach(item => {{
                    item.classList.remove('flight-item-active');
                }});
                flightItem.classList.add('flight-item-active');
                
                // Highlight this flight path
                polylines.forEach((p, i) => {{
                    if (i === index) {{
                        p.setStyle({{ weight: 5, opacity: 1.0 }});
                        p.bringToFront();
                    }}else {{
                        p.setStyle({{ weight: 2, opacity: 0.4 }});
                    }}
                }});
                
                // Zoom to bounds of this flight
                map.fitBounds(polyline.getBounds(), {{ padding: [50, 50] }});
            }});
        }});
        
        // Fit map to all flight paths
        if (polylines.length > 0) {{
            const bounds = L.featureGroup(polylines).getBounds();
            map.fitBounds(bounds, {{ padding: [50, 50] }});
        }}
        
        // Set absolute path for report
        document.getElementById('reportPath').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # Use relative paths for files to analyze
    base_path = Path.home() / "ForenSage"
    flight_records_path = base_path / "analyze/drone/sdcard/DJI/dji.go.v4/FlightRecord"
    
    # For output, use a results directory
    output_html = base_path / "results/drone_flight_records.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    print(f"Analyzing flight records in: {os.path.abspath(flight_records_path)}")
    print(f"Output will be saved to: {os.path.abspath(output_html)}")
    
    # Analyze flight records
    flight_data, metadata, success = analyze_flight_records(flight_records_path)
    
    # Generate HTML report
    if success and flight_data:
        generate_flight_report_html(flight_data, metadata, output_html)
    else:
        print("❌ No flight data found or error occurred during analysis.")

if __name__ == "__main__":
    main()