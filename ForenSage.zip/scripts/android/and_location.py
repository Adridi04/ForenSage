#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import os
from pathlib import Path
import datetime

def create_location_error_html(output_path):
    """Genera un informe HTML con mensaje de error de localización"""
    
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    #HTML
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error de Localización | Location Error</title>
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #e74c3c;
            --accent-light: #e95d4f;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --error-color: #e74c3c;
        }}
        
        body {{
            font-family: 'Arial', sans-serif;
            background-color: var(--background);
            color: var(--text);
            margin: 0;
            padding: 20px;
        }}
        
        .container {{
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }}
        
        h1 {{
            color: var(--error-color);
            text-align: center;
            margin-bottom: 30px;
        }}
        
        .timestamp {{
            text-align: center;
            color: var(--text-secondary);
            margin-bottom: 40px;
        }}
        
        .error-card {{
            background-color: var(--card-bg);
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
            border-left: 5px solid var(--error-color);
            margin-bottom: 30px;
        }}
        
        .error-icon {{
            font-size: 48px;
            text-align: center;
            margin-bottom: 20px;
            color: var(--error-color);
        }}
        
        .error-message {{
            font-size: 22px;
            text-align: center;
            margin-bottom: 15px;
            font-weight: bold;
        }}
        
        .error-message-secondary {{
            font-size: 18px;
            text-align: center;
            margin-bottom: 30px;
            color: var(--text-secondary);
        }}
        
        .solutions {{
            background-color: rgba(52, 152, 219, 0.1);
            border-radius: 8px;
            padding: 20px;
            margin-top: 30px;
        }}
        
        .solutions h2 {{
            color: var(--accent-light);
            margin-top: 0;
        }}
        
        .solution-item {{
            margin-bottom: 10px;
            padding-left: 20px;
            position: relative;
        }}
        
        .solution-item:before {{
            content: "•";
            position: absolute;
            left: 0;
            color: var(--accent-light);
        }}
        
        .footer {{
            text-align: center;
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
            color: var(--text-secondary);
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Informe de Localización | Location Report</h1>
        <div class="timestamp">Generado el: {timestamp}</div>
        
        <div class="error-card">
            <div class="error-icon">⚠️</div>
            
            <div class="error-message">Error al encontrar la localización del móvil</div>
            <div class="error-message-secondary">Error finding the mobile device location</div>
            
            <div class="solutions">
                <h2>Posibles Soluciones / Possible Solutions:</h2>
                <div class="solution-item">Verificar que los archivos de localización existan en el dispositivo / Verify that location files exist on the device</div>
                <div class="solution-item">Comprobar que los permisos de localización estén habilitados / Check that location permissions are enabled</div>
                <div class="solution-item">Verificar que la base de datos de localización no esté dañada / Verify that the location database is not corrupted</div>
                <div class="solution-item">Intentar extraer datos de localización desde otras fuentes / Try extracting location data from other sources</div>
            </div>
        </div>
        
        <div class="footer">
            <p>ForenSage © 2025 - Forensic Tool</p>
        </div>
    </div>
</body>
</html>"""
    
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"[✓] Informe HTML con mensaje de error de localización generado exitosamente: {output_path}")
        return True
    except Exception as e:
        print(f"[!] Error al guardar el informe HTML: {e}")
        return False

def main():
    # Configurar el parser de argumentos
    parser = argparse.ArgumentParser(description="Generador de informe de error de localización para ForenSage")
    parser.add_argument("--output", type=str, 
                      default=str(Path.home() / "ForenSage/results/location_error.html"),
                      help="Ruta del archivo HTML de salida")
    
    args = parser.parse_args()
    
    # Crear el informe HTML con mensaje de error
    create_location_error_html(args.output)

if __name__ == "__main__":
    main()