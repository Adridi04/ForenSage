#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
from pathlib import Path
import html
from datetime import datetime
import os
import sqlite3
import glob

# Configuración de rutas | Path configuration
BASE_DIR = Path(".")
XML_REL_PATH = "analyze/android/data/system/sync/accounts.xml"
DB_REL_PATH = "analyze/android/data/system_ce/0/accounts_ce.db"
DASHBOARD_XML_PATTERN = "" \
""
OUTPUT_DIR = BASE_DIR / "results"
OUTPUT_HTML = OUTPUT_DIR / "and_accounts_info.html"

def obtener_datos_cuentas_xml(xml_path):
    """Obtiene datos de cuentas sincronizadas del archivo XML
    Retrieves synced accounts data from the XML file"""
    if not xml_path.exists():
        print(f"Error: No se encontró el archivo XML en {xml_path}")
        return None

    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
        cuentas_data = []
        tipos_cuenta = {}
        
        for cuenta in root.findall(".//accounts/account"):
            cuenta_info = cuenta.attrib.copy()
            servicios = []
            
            for autoridad in cuenta.findall(".//authority"):
                servicios.append({
                    "nombre": autoridad.get("name", ""),
                    "id": autoridad.get("id", ""),
                    "sync_state": autoridad.get("syncState", ""),
                    "enabled": autoridad.get("enabled", ""),
                    "last_sync_time": autoridad.get("syncTime", "")
                })
            
            cuenta_info["servicios"] = servicios
            cuenta_info["fuente"] = "accounts.xml"
            cuentas_data.append(cuenta_info)
            
            tipo = cuenta_info.get("type", "Desconocido")
            tipos_cuenta[tipo] = tipos_cuenta.get(tipo, 0) + 1
        
        return {
            'data': cuentas_data,
            'stats': {
                'total': len(cuentas_data),
                'tipos': tipos_cuenta
            }
        }
        
    except ET.ParseError as e:
        print(f"Error al parsear XML: {e}")
        return None
    except Exception as e:
        print(f"Error general en XML: {e}")
        return None

def obtener_datos_db(db_path):
    """Obtiene datos de cuentas de la base de datos SQLite"""
    if not db_path.exists():
        print(f"Error: No se encontró la base de datos en {db_path}")
        return None
    
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Verificar si existen las tablas necesarias
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        print(f"Tablas encontradas: {tables}")
        
        cuentas_data = []
        tipos_cuenta = {}
        
        # Consulta adaptable según las tablas disponibles
        if 'accounts' in tables:
            cursor.execute("""
                SELECT * FROM accounts
            """)
            
            for row in cursor.fetchall():
                cuenta_info = dict(row)
                cuenta_info["fuente"] = "accounts_ce.db"
                
                # Añadir servicios si hay tablas relacionadas
                servicios = []
                if 'auth_tokens' in tables:
                    try:
                        cursor.execute("""
                            SELECT * FROM auth_tokens 
                            WHERE accounts_id = ?
                        """, (cuenta_info.get('_id', ''),))
                        
                        for auth in cursor.fetchall():
                            servicios.append({
                                "nombre": auth.get('service', ''),
                                "id": auth.get('_id', ''),
                                "type": auth.get('type', ''),
                                "token_hash": auth.get('token_hash', '')[:10] + '***',
                                "package_name": auth.get('package_name', '')
                            })
                    except sqlite3.Error as e:
                        print(f"Error consultando auth_tokens: {e}")
                
                cuenta_info["servicios"] = servicios
                cuentas_data.append(cuenta_info)
                
                tipo = cuenta_info.get('type', 'Desconocido')
                tipos_cuenta[tipo] = tipos_cuenta.get(tipo, 0) + 1
        
        return {
            'data': cuentas_data,
            'stats': {
                'total': len(cuentas_data),
                'tipos': tipos_cuenta
            }
        }
            
    except sqlite3.Error as e:
        print(f"Error de SQLite: {e}")
        return None
    except Exception as e:
        print(f"Error general en DB: {e}")
        return None
    finally:
        if 'conn' in locals() and conn:
            conn.close()

def obtener_dashboard_xml(pattern):
    """Obtiene datos del XML del dashboard de cuentas"""
    xml_files = glob.glob(str(BASE_DIR / pattern))
    
    if not xml_files:
        print(f"No se encontraron archivos XML para el patrón: {pattern}")
        return None
    
    dashboard_data = []
    
    try:
        for xml_file in xml_files:
            tree = ET.parse(xml_file)
            root = tree.getroot()
            
            # Extraer datos específicos del dashboard
            for elemento in root.findall(".//"):
                if 'account' in elemento.tag.lower():
                    item_data = elemento.attrib.copy()
                    item_data["fuente"] = "dashboard_xml"
                    dashboard_data.append(item_data)
                    
        return dashboard_data
        
    except ET.ParseError as e:
        print(f"Error al parsear XML Dashboard: {e}")
        return None
    except Exception as e:
        print(f"Error general en Dashboard XML: {e}")
        return None

def combinar_datos(datos_xml, datos_db, datos_dashboard):
    """Combina datos de diferentes fuentes"""
    combined_data = {
        'data': [],
        'stats': {
            'total': 0,
            'tipos': {}
        }
    }
    
    # Combinar datos primarios
    if datos_xml and 'data' in datos_xml:
        combined_data['data'].extend(datos_xml['data'])
    
    if datos_db and 'data' in datos_db:
        combined_data['data'].extend(datos_db['data'])
    
    # Añadir datos de dashboard como información adicional
    if datos_dashboard:
        for item in datos_dashboard:
            related_account = None
            for acc in combined_data['data']:
                if acc.get('name') == item.get('name'):
                    related_account = acc
                    break
                    
            if related_account:
                related_account.setdefault('dashboard_info', []).append(item)
            else:
                item["servicios"] = []
                combined_data['data'].append(item)
    
    # Recalcular estadísticas
    tipos = {}
    for cuenta in combined_data['data']:
        tipo = cuenta.get('type', 'Desconocido')
        tipos[tipo] = tipos.get(tipo, 0) + 1
    
    combined_data['stats'] = {
        'total': len(combined_data['data']),
        'tipos': tipos
    }
    
    return combined_data

def formatear_fecha(timestamp):
    """Formatea un timestamp a fecha legible"""
    if not timestamp or timestamp == "0":
        return "Nunca"
    try:
        timestamp = int(timestamp)
        if timestamp > 1000000000000:  # Si está en milisegundos
            timestamp = timestamp / 1000
        return datetime.fromtimestamp(timestamp).strftime('%d/%m/%Y %H:%M')
    except:
        return str(timestamp)

def generar_html_accounts(datos):
    """Genera un informe HTML con diseño creativo de tarjetas"""
    if not datos:
        return "<html><body><h1>No se encontraron datos</h1></body></html>"
    
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cuentas = datos['data']
    estadisticas = datos['stats']
    color_principal = "#3498db"  # Azul para este informe
    
    # Estilo CSS comprimido para reducir líneas
    css = """
:root{--bg-dark:#1a1a2e;--bg-card:#16213e;--text-light:#ecf0f1;--text-muted:#bdc3c7;--accent:#3498db;--card-border:#3498db}
body{font-family:'Poppins',sans-serif;background-color:var(--bg-dark);color:var(--text-light);margin:0;padding:20px;line-height:1.6}
.header{text-align:center;margin-bottom:40px;padding:30px 0;background:linear-gradient(135deg,#0c2461,#1e3799,#4a69bd);border-radius:15px;box-shadow:0 10px 20px rgba(0,0,0,0.3)}
.report-date{font-size:1rem;color:var(--text-muted);margin-top:15px;text-align:center}
h1{font-family:'Montserrat',sans-serif;font-weight:700;font-size:2.5rem;margin:0;background:linear-gradient(to right,#3498db,#2980b9);-webkit-background-clip:text;background-clip:text;color:transparent}
.subtitle{font-size:1.1rem;color:var(--text-muted);margin-top:10px}
.stats{display:flex;justify-content:center;flex-wrap:wrap;gap:20px;margin-bottom:40px}
.stat-card{background:rgba(255,255,255,0.1);border-radius:12px;padding:20px;min-width:150px;text-align:center;backdrop-filter:blur(5px);border:1px solid rgba(255,255,255,0.1);transition:transform 0.3s,box-shadow 0.3s}
.stat-card:hover{transform:translateY(-5px);box-shadow:0 15px 30px rgba(0,0,0,0.2)}
.stat-value{font-size:2.2rem;font-weight:700;margin:10px 0;background:linear-gradient(to right,#3498db,#2980b9);-webkit-background-clip:text;background-clip:text;color:transparent}
.stat-label{font-size:0.9rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:1px}
.accounts-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(450px,1fr));gap:25px;margin:0 auto;max-width:1400px}
.account-card{background:var(--bg-card);border-radius:15px;padding:25px;box-shadow:0 8px 20px rgba(0,0,0,0.2);transition:all 0.3s ease;position:relative;overflow:hidden;border-top:3px solid var(--card-border)}
.account-card:hover{transform:translateY(-10px);box-shadow:0 15px 30px rgba(0,0,0,0.3)}
.account-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,transparent,rgba(255,255,255,0.3),transparent)}
.account-title{font-family:'Montserrat',sans-serif;font-size:1.4rem;font-weight:600;margin:0 0 10px 0;color:white;display:flex;align-items:center;justify-content:space-between;}
.account-email{font-family:monospace;font-size:0.9rem;color:var(--accent);margin-bottom:15px;display:inline-block;background:rgba(52,152,219,0.1);padding:3px 8px;border-radius:4px}
.account-type-badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:0.8rem;margin-left:10px;background:rgba(52,152,219,0.2);color:#3498db}
.account-google{background:rgba(219,68,55,0.2);color:#db4437}.account-samsung{background:rgba(19,85,124,0.2);color:#13557c}
.account-details{margin-top:15px}.detail-item{display:flex;margin-bottom:8px;align-items:center}
.detail-icon{width:24px;height:24px;margin-right:10px;display:flex;align-items:center;justify-content:center;border-radius:50%;background:rgba(255,255,255,0.1)}
.detail-label{font-weight:500;min-width:100px;color:var(--text-muted)}.detail-value{font-weight:400}
.services-list{margin-top:20px;padding-top:15px;border-top:1px dashed rgba(255,255,255,0.1)}
.service-item{background:rgba(255,255,255,0.05);margin-bottom:8px;padding:10px;border-radius:8px;transition:all 0.2s ease}
.service-item:hover{background:rgba(255,255,255,0.1)}
.service-name{font-weight:500;font-size:0.9rem;margin-bottom:5px;color:var(--accent)}
.service-details{display:flex;font-size:0.8rem;justify-content:space-between;color:var(--text-muted)}
.sync-active{color:#2ecc71}.sync-disabled{color:#e74c3c}
.footer{text-align:center;margin-top:50px;padding:20px;color:var(--text-muted);font-size:0.9rem}
.bubble{position:absolute;border-radius:50%;background:rgba(255,255,255,0.05);z-index:-1}
.source-badge{font-size:0.7rem;color:var(--text-muted);background:rgba(52,152,219,0.15);padding:2px 6px;border-radius:4px;}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.account-card:hover{animation:float 3s ease-in-out infinite}
@media(max-width:768px){.accounts-grid{grid-template-columns:1fr}}
"""
    
    html_content = f"""
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Synchronized Accounts | Cuentas Sincronizadas</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Poppins:wght@300;500&display=swap" rel="stylesheet">
    <style>{css}</style>
</head>
<body>
    <div class="header">
        <h1>Synchronized Accounts | Cuentas Sincronizadas</h1>
        <div class="subtitle">Análisis forense de cuentas sincronizadas en Android</div>
        <div class="report-date">Generado el: {now}</div>
    </div>
    
    <div class="stats">
        <div class="stat-card">
            <div class="stat-value">{estadisticas['total']}</div>
            <div class="stat-label">Total Cuentas</div>
        </div>
"""

    # Generar tarjetas de estadísticas para cada tipo de cuenta
    for tipo, cantidad in estadisticas['tipos'].items():
        html_content += f"""
        <div class="stat-card">
            <div class="stat-value">{cantidad}</div>
            <div class="stat-label">Cuentas {tipo}</div>
        </div>"""

    html_content += """
    </div>
    
    <div class="accounts-grid">
"""

    # Generar tarjetas para cada cuenta
    for cuenta in cuentas:
        # Extraer información relevante
        nombre = html.escape(cuenta.get('name', 'Desconocido'))
        tipo = html.escape(cuenta.get('type', 'Desconocido'))
        fuente = cuenta.get('fuente', 'Desconocido')
        
        # Determinar clase CSS basada en el tipo de cuenta
        tipo_clase = ""
        if "google" in tipo.lower():
            tipo_clase = "account-google"
        elif "samsung" in tipo.lower():
            tipo_clase = "account-samsung"
        
        # Generar HTML de la tarjeta
        html_content += f"""
        <div class="account-card">
            <h2 class="account-title">
                {nombre}
                <span class="account-type-badge {tipo_clase}">{tipo}</span>
            </h2>
            <div class="account-email">{html.escape(cuenta.get('name', ''))} <span class="source-badge">Fuente: {fuente}</span></div>
            
            <div class="account-details">
                <div class="detail-item">
                    <span class="detail-icon">🔑</span>
                    <span class="detail-label">Tipo:</span>
                    <span class="detail-value">{tipo}</span>
                </div>
                
                <div class="detail-item">
                    <span class="detail-icon">🆔</span>
                    <span class="detail-label">ID:</span>
                    <span class="detail-value">{html.escape(str(cuenta.get('userId', cuenta.get('_id', ''))))}</span>
                </div>"""
        
        # Añadir información adicional de dashboard si está disponible
        if 'dashboard_info' in cuenta:
            html_content += """
                <div class="detail-item">
                    <span class="detail-icon">📊</span>
                    <span class="detail-label">Dashboard:</span>
                    <span class="detail-value">Información disponible</span>
                </div>"""
        
        html_content += """
            </div>
            
            <div class="services-list">
                <h3>Servicios Sincronizados ({len(cuenta.get('servicios', []))})</h3>
"""
        
        # Agregar los servicios de cada cuenta
        for servicio in cuenta.get('servicios', []):
            nombre_servicio = html.escape(servicio.get('nombre', 'Desconocido'))
            # Diferentes tipos de información según fuente
            if fuente == "accounts.xml":
                sincronizacion = "Activa" if servicio.get('enabled', '') == "true" else "Desactivada"
                clase_sync = "sync-active" if sincronizacion == "Activa" else "sync-disabled"
                ultima_sincronizacion = formatear_fecha(servicio.get('last_sync_time', ''))
                
                html_content += f"""
                <div class="service-item">
                    <div class="service-name">{nombre_servicio}</div>
                    <div class="service-details">
                        <span>Sincronización: <span class="{clase_sync}">{sincronizacion}</span></span>
                        <span>Última sincronización: {ultima_sincronizacion}</span>
                    </div>
                </div>"""
            else:
                # Para servicios desde la base de datos
                package = servicio.get('package_name', 'N/A')
                token = servicio.get('token_hash', 'N/A')
                
                html_content += f"""
                <div class="service-item">
                    <div class="service-name">{nombre_servicio}</div>
                    <div class="service-details">
                        <span>Paquete: {package}</span>
                        <span>Token: {token}</span>
                    </div>
                </div>"""
        
        # Si no hay servicios, mostrar mensaje
        if not cuenta.get('servicios', []):
            html_content += """
                <div class="service-item">
                    <div class="service-name">No hay servicios registrados</div>
                </div>"""
        
        # Cerrar la tarjeta de cuenta
        html_content += """
            </div>
            
            <!-- Burbujas decorativas | Decorative bubbles -->
            <div class="bubble" style="width: 80px; height: 80px; top: -30px; right: -30px; background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);"></div>
            <div class="bubble" style="width: 40px; height: 40px; bottom: 20px; left: -15px; background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);"></div>
        </div>
        """

    html_content += f"""
    </div>
    
    <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
    </footer>
    
    <script>
        // Agregar efecto de movimiento | Add movement effect
        document.querySelectorAll('.bubble').forEach((bubble, index) => {{
            const size = Math.random() * 50 + 30;
            const posX = Math.random() * 100;
            const posY = Math.random() * 100;
            
            bubble.style.width = `${{size}}px`;
            bubble.style.height = `${{size}}px`;
            bubble.style.left = `${{posX}}%`;
            bubble.style.top = `${{posY}}%`;
            bubble.style.animation = `float ${{Math.random() * 5 + 3}}s ease-in-out infinite ${{Math.random() * 2}}s`;
        }});
    </script>
</body>
</html>
"""
    
    return html_content

def main():
    # Crear directorio de resultados si no existe
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    # Rutas completas a los archivos
    xml_path = BASE_DIR / XML_REL_PATH
    db_path = BASE_DIR / DB_REL_PATH
    dashboard_pattern = DASHBOARD_XML_PATTERN
    
    # Obtener datos de cuentas sincronizadas de cada fuente
    datos_cuentas = obtener_datos_cuentas_xml(xml_path)
    datos_db = obtener_datos_db(db_path)
    datos_dashboard = obtener_dashboard_xml(dashboard_pattern)
    
    # Combinar todos los datos
    datos_combinados = combinar_datos(datos_cuentas, datos_db, datos_dashboard)
    
    if datos_combinados and datos_combinados['stats']['total'] > 0:
        print(f"Se encontraron {datos_combinados['stats']['total']} cuentas en total:")
        print(f"• {datos_cuentas['stats']['total'] if datos_cuentas else 0} desde accounts.xml")
        print(f"• {datos_db['stats']['total'] if datos_db else 0} desde accounts_ce.db")
        print(f"• {len(datos_dashboard) if datos_dashboard else 0} desde dashboard XML")
        
        # Generar HTML con diseño creativo
        html_content = generar_html_accounts(datos_combinados)
        
        # Guardar el informe
        with open(OUTPUT_HTML, 'w', encoding='utf-8') as f:
            f.write(html_content)
        print(f"Informe creativo generado en: {OUTPUT_HTML}")
    else:
        print("No se pudieron obtener datos de cuentas")

if __name__ == "__main__":
    main()