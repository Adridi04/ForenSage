import os
from pathlib import Path
import datetime
import xml.etree.ElementTree as ET

def analizar_settings(archivo_xml):
    """
    Analiza un archivo XML de configuración Android y extrae configuraciones clave-valor.
    / Parses an Android settings XML file and extracts key-value configurations.
    """
    configuraciones = []
    try:
        tree = ET.parse(archivo_xml)
        root = tree.getroot()

        for setting in root.findall('setting'):
            name = setting.get('name')
            value = setting.get('value')
            
            if name and value is not None:
                configuraciones.append({
                    'name': name,
                    'value': value.strip() if value else 'Vacío/Empty',
                    'source': archivo_xml.name
                })

        # Alternative analysis if nothing was found / Análisis alternativo si no se encontró nada
        if not configuraciones:
            for elem in root.iter():
                if elem.attrib:
                    for attr_name, attr_value in elem.attrib.items():
                        if 'name' in attr_name.lower() or 'key' in attr_name.lower():
                            configuraciones.append({
                                'name': attr_value,
                                'value': elem.text.strip() if elem.text else 'Vacío/Empty',
                                'source': archivo_xml.name
                            })

    except ET.ParseError as e:
        print(f"❌ Error de análisis XML ({archivo_xml.name}): {e} | XML parsing error: {e}")
    except Exception as e:
        print(f"❌ Error inesperado ({archivo_xml.name}): {e} | Unexpected error: {e}")
    
    return configuraciones

def generar_html(configuraciones, ruta_salida):
    """
    Genera un archivo HTML con el estilo proporcionado
    / Generates HTML report with the provided style
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception as e:
            print(f"❌ Error creando carpeta: {e} | Error creating folder: {e}")
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(ruta_salida.resolve())

    # Group settings by source file / Agrupar configuraciones por archivo de origen
    config_por_fuente = {}
    for config in configuraciones:
        fuente = config.get('source', 'Desconocido/Unknown')
        if fuente not in config_por_fuente:
            config_por_fuente[fuente] = []
        config_por_fuente[fuente].append(config)

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Android Report | Informe Android</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .report-card {{
            background-color: var(--card-bg);
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            margin-bottom: 2rem;
        }}

        .settings-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }}

        .settings-table th {{
            background-color: var(--primary);
            color: var(--text);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
        }}

        .settings-table td {{
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            vertical-align: top;
        }}

        .settings-table tr:nth-child(even) {{
            background-color: rgba(52, 152, 219, 0.05);
        }}

        .settings-table tr:hover {{
            background-color: var(--primary-light);
        }}

        .file-header {{
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }}

        .file-icon {{
            font-size: 1.5rem;
            margin-right: 1rem;
        }}

        .file-name {{
            font-weight: 600;
            color: var(--accent-light);
        }}

        .settings-count {{
            margin-left: auto;
            background-color: var(--primary);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.9rem;
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .lang-toggle {{
            background-color: var(--card-bg);
            color: var(--text);
            border: 1px solid var(--primary-light);
            border-radius: 20px;
            padding: 0.5rem 1rem;
            cursor: pointer;
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-left: 1rem;
        }}

        .lang-toggle:hover {{
            border-color: var(--accent);
            transform: translateY(-2px);
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">🔍 Android Settings | Informe de Configuración </h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
            <button class="lang-toggle" onclick="toggleLanguage()">EN/ES</button>
        </div>"""

    for fuente, configs in config_por_fuente.items():
        html += f"""
        <div class="report-card">
            <div class="file-header">
                <div class="file-icon">📄</div>
                <div class="file-name">{fuente}</div>
                <div class="settings-count">{len(configs)} configuraciones | settings</div>
            </div>
            <table class="settings-table">
                <thead>
                    <tr>
                        <th>🔑 Configuración | Setting</th>
                        <th>📍 Valor | Value</th>
                    </tr>
                </thead>
                <tbody>"""

        for config in configs:
            html += f"""
                    <tr>
                        <td>{config['name']}</td>
                        <td>{config['value']}</td>
                    </tr>"""

        html += """
                </tbody>
            </table>
        </div>"""

    html += f"""
        <div class="footer">
            <p>📁 Ruta del informe: <code>{ruta_str}</code></p>
            <p>📁 Report path: <code>{ruta_str}</code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        function toggleLanguage() {{
            document.querySelectorAll('[lang="es"]').forEach(el => {{
                el.style.display = el.style.display === 'none' ? 'block' : 'none';
            }});
            document.querySelectorAll('[lang="en"]').forEach(el => {{
                el.style.display = el.style.display === 'none' ? 'block' : 'none';
            }});
        }}
        
        // Initialize language display
        document.addEventListener('DOMContentLoaded', function() {{
            document.querySelectorAll('[lang="en"]').forEach(el => {{
                el.style.display = 'none';
            }});
        }});
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida} | Report generated at: {ruta_salida}")
    except Exception as e:
        print(f"❌ Error guardando HTML: {e} | Error saving HTML: {e}")

def main():
    base_path = Path.home() / "ForenSage" / "results"
    archivos_xml = [
        Path.home() / "ForenSage" / "analyze" / "android" / "data" / "system" / "users" / "0" / "settings_system.xml",
        Path.home() / "ForenSage" / "analyze" / "android" / "data" / "system" / "users" / "0" / "settings_global.xml"
    ]
    salida_html = base_path / "and_device_info.html"

    configuraciones_totales = []
    
    for archivo_xml in archivos_xml:
        if not archivo_xml.exists():
            print(f"❌ Archivo no encontrado: {archivo_xml} | File not found: {archivo_xml}")
            continue

        print(f"🔍 Analizando archivo: {archivo_xml} | Analyzing file: {archivo_xml}")
        configuraciones = analizar_settings(archivo_xml)
        
        if configuraciones:
            print(f"📊 Configuraciones encontradas en {archivo_xml.name}: {len(configuraciones)} | Settings found: {len(configuraciones)}")
            configuraciones_totales.extend(configuraciones)
        else:
            print(f"⚠️ No se encontraron configuraciones válidas en {archivo_xml.name} | No valid settings found")

    if configuraciones_totales:
        generar_html(configuraciones_totales, salida_html)
    else:
        print("⚠️ No se encontraron configuraciones válidas en ningún archivo | No valid settings found in any file")

if __name__ == "__main__":
    main()







