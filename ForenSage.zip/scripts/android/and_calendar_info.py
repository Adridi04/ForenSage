import os
from pathlib import Path
import datetime
import sqlite3
import json

def analizar_db_calendario(ruta_db):
    """Analiza la base de datos de Calendario Android y extrae información básica"""
    resultados = {'eventos': [], 'calendarios': [], 'recordatorios': []}
    try:
        # Verificar que el archivo existe
        db_path = Path(ruta_db)
        if not db_path.exists():
            print(f"❌ Base de datos no encontrada: {db_path}")
            return resultados
            
        # Conectar a la base de datos
        conn = sqlite3.connect(ruta_db)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = [tabla['name'] for tabla in cursor.fetchall()]
        print(f"📊 Tablas encontradas: {', '.join(tablas)}")
        
        # Analizar tabla de calendarios
        if 'Calendars' in tablas:
            try:
                cursor.execute("PRAGMA table_info(Calendars)")
                columnas = [info[1] for info in cursor.fetchall()]
                
                select_cols = []
                id_col = next((col for col in columnas if col.lower() == '_id' or col.lower() == 'id'), None)
                if id_col: select_cols.append(id_col)
                
                name_col = next((col for col in columnas if 'name' in col.lower() or 'displayname' in col.lower()), None)
                if name_col: select_cols.append(name_col)
                
                color_col = next((col for col in columnas if 'color' in col.lower()), None)
                if color_col: select_cols.append(color_col)
                
                account_col = next((col for col in columnas if 'account' in col.lower() or 'owner' in col.lower()), None)
                if account_col: select_cols.append(account_col)
                
                visible_col = next((col for col in columnas if 'visible' in col.lower()), None)
                if visible_col: select_cols.append(visible_col)
                
                sync_col = next((col for col in columnas if 'sync' in col.lower()), None)
                if sync_col: select_cols.append(sync_col)
                
                if select_cols:
                    cursor.execute(f"SELECT {', '.join(select_cols)} FROM Calendars")
                    for row in cursor.fetchall():
                        cal = {}
                        if id_col: cal['id'] = row[id_col]
                        if name_col: cal['nombre'] = row[name_col] or "Sin nombre"
                        if color_col: cal['color'] = f"#{row[color_col]:06x}" if isinstance(row[color_col], int) else str(row[color_col])
                        if account_col: cal['cuenta'] = row[account_col] or "Cuenta local"
                        if visible_col: cal['visible'] = bool(row[visible_col])
                        if sync_col: cal['sincronizado'] = bool(row[sync_col])
                        
                        resultados['calendarios'].append(cal)
            except Exception as e:
                print(f"⚠️ Error al analizar tabla Calendars: {e}")
        
        # Analizar tabla de eventos
        if 'Events' in tablas:
            try:
                cursor.execute("PRAGMA table_info(Events)")
                columnas = [info[1] for info in cursor.fetchall()]
                
                select_cols = []
                id_col = next((col for col in columnas if col.lower() == '_id' or col.lower() == 'id'), None)
                if id_col: select_cols.append(id_col)
                
                title_col = next((col for col in columnas if 'title' in col.lower()), None)
                if title_col: select_cols.append(title_col)
                
                desc_col = next((col for col in columnas if 'description' in col.lower()), None)
                if desc_col: select_cols.append(desc_col)
                
                location_col = next((col for col in columnas if 'location' in col.lower() or 'eventlocation' in col.lower()), None)
                if location_col: select_cols.append(location_col)
                
                start_col = next((col for col in columnas if 'dtstart' in col.lower() or 'startdate' in col.lower() or 'start' in col.lower()), None)
                if start_col: select_cols.append(start_col)
                
                end_col = next((col for col in columnas if 'dtend' in col.lower() or 'enddate' in col.lower() or 'end' in col.lower()), None)
                if end_col: select_cols.append(end_col)
                
                cal_id_col = next((col for col in columnas if 'calendar_id' in col.lower() or 'calendarid' in col.lower()), None)
                if cal_id_col: select_cols.append(cal_id_col)
                
                all_day_col = next((col for col in columnas if 'allday' in col.lower() or 'all_day' in col.lower()), None)
                if all_day_col: select_cols.append(all_day_col)
                
                rrule_col = next((col for col in columnas if 'rrule' in col.lower() or 'recurrence' in col.lower()), None)
                if rrule_col: select_cols.append(rrule_col)
                
                if select_cols:
                    query = f"SELECT {', '.join(select_cols)} FROM Events"
                    if start_col:
                        query += f" ORDER BY {start_col} DESC"
                    query += " LIMIT 500"
                    
                    cursor.execute(query)
                    for row in cursor.fetchall():
                        evento = {}
                        if id_col: evento['id'] = row[id_col]
                        if title_col: evento['titulo'] = row[title_col] or "Sin título"
                        if desc_col: evento['descripcion'] = row[desc_col] or ""
                        if location_col: evento['ubicacion'] = row[location_col] or ""
                        
                        if start_col:
                            try:
                                start_val = row[start_col]
                                if isinstance(start_val, int) and start_val > 0:
                                    evento['inicio'] = datetime.datetime.fromtimestamp(
                                        start_val/1000 if start_val > 1000000000000 else start_val
                                    ).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    evento['inicio'] = str(start_val)
                            except:
                                evento['inicio'] = 'Desconocido'
                        
                        if end_col:
                            try:
                                end_val = row[end_col]
                                if isinstance(end_val, int) and end_val > 0:
                                    evento['fin'] = datetime.datetime.fromtimestamp(
                                        end_val/1000 if end_val > 1000000000000 else end_val
                                    ).strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    evento['fin'] = str(end_val)
                            except:
                                evento['fin'] = 'Desconocido'
                        
                        if cal_id_col: evento['calendario_id'] = row[cal_id_col]
                        if all_day_col: evento['todo_el_dia'] = bool(row[all_day_col])
                        if rrule_col: evento['recurrencia'] = row[rrule_col] or "No recurrente"
                        
                        resultados['eventos'].append(evento)
            except Exception as e:
                print(f"⚠️ Error al analizar tabla Events: {e}")
        
        # Analizar tabla de recordatorios
        for tabla in tablas:
            if 'Reminders' in tabla or 'Alerts' in tabla or 'reminder' in tabla.lower() or 'alert' in tabla.lower():
                try:
                    cursor.execute(f"PRAGMA table_info({tabla})")
                    columnas = [info[1] for info in cursor.fetchall()]
                    
                    select_cols = []
                    id_col = next((col for col in columnas if col.lower() == '_id' or col.lower() == 'id'), None)
                    if id_col: select_cols.append(id_col)
                    
                    event_id_col = next((col for col in columnas if 'event_id' in col.lower() or 'eventid' in col.lower()), None)
                    if event_id_col: select_cols.append(event_id_col)
                    
                    time_col = next((col for col in columnas if 'time' in col.lower() or 'date' in col.lower() or 'when' in col.lower()), None)
                    if time_col: select_cols.append(time_col)
                    
                    minutes_col = next((col for col in columnas if 'minutes' in col.lower() or 'before' in col.lower()), None)
                    if minutes_col: select_cols.append(minutes_col)
                    
                    method_col = next((col for col in columnas if 'method' in col.lower() or 'type' in col.lower()), None)
                    if method_col: select_cols.append(method_col)
                    
                    if select_cols:
                        cursor.execute(f"SELECT {', '.join(select_cols)} FROM {tabla} LIMIT 500")
                        for row in cursor.fetchall():
                            recordatorio = {}
                            if id_col: recordatorio['id'] = row[id_col]
                            if event_id_col: recordatorio['evento_id'] = row[event_id_col]
                            
                            if time_col:
                                try:
                                    time_val = row[time_col]
                                    if isinstance(time_val, int) and time_val > 0:
                                        recordatorio['hora'] = datetime.datetime.fromtimestamp(
                                            time_val/1000 if time_val > 1000000000000 else time_val
                                        ).strftime('%Y-%m-%d %H:%M:%S')
                                    else:
                                        recordatorio['hora'] = str(time_val)
                                except:
                                    recordatorio['hora'] = 'Desconocido'
                            
                            if minutes_col: recordatorio['minutos_antes'] = row[minutes_col]
                            if method_col: 
                                metodo = row[method_col]
                                if isinstance(metodo, int):
                                    # Códigos comunes de métodos de alerta
                                    metodos = {0: "Desconocido", 1: "Notificación", 2: "Email", 3: "SMS", 4: "Alarma"}
                                    recordatorio['metodo'] = metodos.get(metodo, f"Método {metodo}")
                                else:
                                    recordatorio['metodo'] = str(metodo)
                            
                            resultados['recordatorios'].append(recordatorio)
                except Exception as e:
                    print(f"⚠️ Error al analizar tabla {tabla}: {e}")
        
        conn.close()
        
    except sqlite3.Error as e:
        print(f"❌ Error de SQLite: {e}")
    except Exception as e:
        print(f"❌ Error inesperado: {e}")
    
    return resultados

def generar_html_calendario(resultados, ruta_salida):
    """Genera un archivo HTML con el análisis del Calendario"""
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception as e:
            print(f"❌ Error creando carpeta: {e}")
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())

    # Generar cabecera HTML con estilos
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">|
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar Report | Informe Calendario</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #1565C0;
            --primary: #2196F3;
            --primary-light: #64B5F6;
            --accent: #FFC107;
            --accent-light: #FFECB3;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #121212;
            --card-bg: #1e1e1e;
            --border-color: rgba(255, 255, 255, 0.1);
        }}
        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}
        .container {{max-width: 1200px; margin: 2rem auto; padding: 2rem; animation: fadeIn 0.7s;}}
        .header {{text-align: center; margin-bottom: 3rem;}}
        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}
        .subtitle {{color: var(--text-secondary); margin-bottom: 2rem;}}
        .report-card {{
            background-color: var(--card-bg);
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            margin-bottom: 2rem;
        }}
        .tabs {{display: flex; margin-bottom: 1rem; overflow-x: auto; scrollbar-width: thin;}}
        .tab {{
            padding: 0.8rem 1.5rem;
            cursor: pointer;
            border-radius: 8px 8px 0 0;
            background-color: var(--primary-dark);
            margin-right: 0.5rem;
            transition: all 0.3s ease;
            white-space: nowrap;
        }}
        .tab.active {{background-color: var(--primary);}}
        .tab:hover {{background-color: var(--primary-light);}}
        .tab-content {{display: none; animation: fadeIn 0.5s;}}
        .tab-content.active {{display: block;}}
        .data-table {{width: 100%; border-collapse: collapse; margin-top: 1rem;}}
        .data-table th {{
            background-color: var(--primary);
            color: var(--text);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
        }}
        .data-table td {{padding: 1rem; border-bottom: 1px solid var(--border-color); vertical-align: top;}}
        .data-table tr:nth-child(even) {{background-color: rgba(33, 150, 243, 0.05);}}
        .data-table tr:hover {{background-color: var(--primary-light); color: var(--background);}}
        .section-header {{display: flex; align-items: center; margin-bottom: 1rem;}}
        .section-icon {{font-size: 1.5rem; margin-right: 1rem;}}
        .section-title {{font-weight: 600; color: var(--accent-light);}}
        .item-count {{
            margin-left: auto;
            background-color: var(--primary);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.9rem;
        }}
        .event {{
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
            background-color: var(--primary-dark);
            position: relative;
        }}
        .event-header {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            color: var(--accent-light);
            font-weight: 600;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.5rem;
        }}
        .event-content {{word-break: break-word;}}
        .event-location {{color: var(--accent); font-style: italic; margin-top: 0.5rem;}}
        .event-time {{font-size: 0.9rem; color: var(--text-secondary); margin-top: 0.5rem;}}
        .footer {{text-align: center; margin-top: 2rem; color: var(--text-secondary); font-size: 0.9rem;}}
        .search-box {{
            width: 100%;
            padding: 0.8rem;
            margin-bottom: 1rem;
            border-radius: 8px;
            border: 1px solid var(--primary-light);
            background-color: var(--card-bg);
            color: var(--text);
        }}
        .calendar-color-dot {{
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
        }}
        @keyframes fadeIn {{from {{opacity: 0; transform: translateY(20px);}} to {{opacity: 1; transform: translateY(0);}}
        @media (max-width: 768px) {{
            .container {{padding: 1rem;}}
            .title {{font-size: 2rem;}}
            .event-header {{flex-direction: column;}}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Calendar Report | Informe Calendario</h1>
            <p class="subtitle">🕒 Generado el {ahora} | Generated on {ahora}</p>
        </div>
        
        <div class="report-card">
            <div class="tabs">
                <div class="tab active" onclick="openTab('eventos')">📆 Eventos ({len(resultados['eventos'])})</div>
                <div class="tab" onclick="openTab('calendarios')">📚 Calendarios ({len(resultados['calendarios'])})</div>
                <div class="tab" onclick="openTab('recordatorios')">⏰ Recordatorios ({len(resultados['recordatorios'])})</div>
            </div>
    """
    html += f"""
            <div id="eventos" class="tab-content active">
                <div class="section-header">
                    <div class="section-icon">📆</div>
                    <div class="section-title">Eventos | Events</div>
                    <div class="item-count">{len(resultados['eventos'])} encontrados</div>
                </div>
                
                <input type="text" class="search-box" id="search-events" placeholder="Buscar eventos..." 
                       onkeyup="searchItems('search-events', 'event')">
                
                <div class="events-container">
    """

    if resultados['eventos']:
        for i, evento in enumerate(resultados['eventos'][:50]):
            html += f"""
                    <div class="event">
                        <div class="event-header">
                            <span>{evento.get('titulo', 'Sin título')}</span>
                            <span>Cal ID: {evento.get('calendario_id', 'Desconocido')}</span>
                        </div>
                        <div class="event-content">{evento.get('descripcion', '(Sin descripción)')}</div>
                        """
            if evento.get('ubicacion'):
                html += f"""<div class="event-location">📍 {evento.get('ubicacion')}</div>"""
            
            # Mostrar fechas de inicio y fin
            inicio = evento.get('inicio', 'Desconocido')
            fin = evento.get('fin', 'Desconocido')
            todo_dia = evento.get('todo_el_dia', False)
            recurrencia = evento.get('recurrencia', 'No recurrente')
            
            html += f"""
                        <div class="event-time">
                            {'🔄 Evento recurrente - ' if recurrencia != 'No recurrente' else ''}
                            {'📌 Todo el día - ' if todo_dia else ''}
                            🗓️ Del {inicio} al {fin}
                        </div>
                    </div>"""
    else:
        html += """<div style="text-align: center; padding: 2rem;">❌ No se encontraron eventos</div>"""
    
    html += """
                </div>
            </div>
    """

    html += f"""
            <div id="calendarios" class="tab-content">
                <div class="section-header">
                    <div class="section-icon">📚</div>
                    <div class="section-title">Calendarios | Calendars</div>
                    <div class="item-count">{len(resultados['calendarios'])} encontrados</div>
                </div>
                
                <input type="text" class="search-box" id="search-calendars" placeholder="Buscar calendarios..." 
                       onkeyup="searchTable('search-calendars', 'calendars-table')">
                
                <table id="calendars-table" class="data-table">
                    <thead>
                        <tr>
                            <th>🆔 ID</th>
                            <th>📅 Nombre</th>
                            <th>🎨 Color</th>
                            <th>👤 Cuenta</th>
                            <th>👁️ Visible</th>
                            <th>🔄 Sincronizado</th>
                        </tr>
                    </thead>
                    <tbody>
    """

    if resultados['calendarios']:
        for calendario in resultados['calendarios']:
            color = calendario.get('color', '#cccccc')
            html += f"""
                        <tr>
                            <td>{calendario.get('id', 'Desconocido')}</td>
                            <td>
                                <span class="calendar-color-dot" style="background-color: {color};"></span>
                                {calendario.get('nombre', 'Desconocido')}
                            </td>
                            <td>{color}</td>
                            <td>{calendario.get('cuenta', 'Desconocido')}</td>
                            <td>{'✅' if calendario.get('visible', False) else '❌'}</td>
                            <td>{'✅' if calendario.get('sincronizado', False) else '❌'}</td>
                        </tr>"""
    else:
        html += """
                        <tr>
                            <td colspan="6" style="text-align: center;">❌ No se encontraron calendarios</td>
                        </tr>"""
    
    html += """
                    </tbody>
                </table>
            </div>
    """

    html += f"""
            <div id="recordatorios" class="tab-content">
                <div class="section-header">
                    <div class="section-icon">⏰</div>
                    <div class="section-title">Recordatorios | Reminders</div>
                    <div class="item-count">{len(resultados['recordatorios'])} encontrados</div>
                </div>
                
                <input type="text" class="search-box" id="search-reminders" placeholder="Buscar recordatorios..." 
                       onkeyup="searchTable('search-reminders', 'reminders-table')">
                
                <table id="reminders-table" class="data-table">
                    <thead>
                        <tr>
                            <th>🆔 ID</th>
                            <th>📆 Evento ID</th>
                            <th>⏰ Hora</th>
                            <th>⏱️ Minutos antes</th>
                            <th>📣 Método</th>
                        </tr>
                    </thead>
                    <tbody>
    """

    if resultados['recordatorios']:
        for recordatorio in resultados['recordatorios']:
            html += f"""
                        <tr>
                            <td>{recordatorio.get('id', 'Desconocido')}</td>
                            <td>{recordatorio.get('evento_id', 'Desconocido')}</td>
                            <td>{recordatorio.get('hora', 'Desconocido')}</td>
                            <td>{recordatorio.get('minutos_antes', 'Desconocido')}</td>
                            <td>{recordatorio.get('metodo', 'Desconocido')}</td>
                        </tr>"""
    else:
        html += """
                        <tr>
                            <td colspan="5" style="text-align: center;">❌ No se encontraron recordatorios</td>
                        </tr>"""
    
    html += f"""
                    </tbody>
                </table>
            </div>
        </div>

        <div class="footer">
            <p>📁 Ruta del informe: <code>{ruta_str}</code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        // Función para cambiar de pestaña
        function openTab(tabName) {{
            var i, tabContent, tabLinks;
            
            // Ocultar contenidos
            tabContent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabContent.length; i++) {{
                tabContent[i].className = tabContent[i].className.replace(" active", "");
            }}
            
            // Desactivar botones
            tabLinks = document.getElementsByClassName("tab");
            for (i = 0; i < tabLinks.length; i++) {{
                tabLinks[i].className = tabLinks[i].className.replace(" active", "");
            }}
            
            // Activar seleccionado
            document.getElementById(tabName).className += " active";
            for (i = 0; i < tabLinks.length; i++) {{
                if (tabLinks[i].textContent.includes(tabName.charAt(0).toUpperCase() + tabName.slice(1))) {{
                    tabLinks[i].className += " active";
                }}
            }}
        }}
        
        // Buscar en eventos
        function searchItems(inputId, itemClass) {{
            var input = document.getElementById(inputId);
            var filter = input.value.toUpperCase();
            var items = document.getElementsByClassName(itemClass);
            
            for (var i = 0; i < items.length; i++) {{
                var content = items[i].textContent || items[i].innerText;
                if (content.toUpperCase().indexOf(filter) > -1) {{
                    items[i].style.display = "";
                }} else {{
                    items[i].style.display = "none";
                }}
            }}
        }}
        
        // Buscar en tablas
        function searchTable(inputId, tableId) {{
            var input = document.getElementById(inputId);
            var filter = input.value.toUpperCase();
            var table = document.getElementById(tableId);
            var tr = table.getElementsByTagName("tr");
            
            for (var i = 1; i < tr.length; i++) {{
                var found = false;
                var td = tr[i].getElementsByTagName("td");
                
                for (var j = 0; j < td.length; j++) {{
                    var cell = td[j];
                    if (cell) {{
                        var content = cell.textContent || cell.innerText;
                        if (content.toUpperCase().indexOf(filter) > -1) {{
                            found = true;
                            break;
                        }}
                    }}
                }}
                
                if (found) {{
                    tr[i].style.display = "";
                }} else {{
                    tr[i].style.display = "none";
                }}
            }}
        }}
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
    except Exception as e:
        print(f"❌ Error guardando HTML: {e}")

def main():
    base_path = Path.home() / "ForenSage" / "results"
    db_path = Path.home() / "ForenSage" / "analyze" / "android" / "data" / "data" / "com.android.providers.calendar" / "databases" / "calendar.db"
    output_html = Path.home() / "ForenSage/results/and_calendar_info.html"
    
    print(f"🔍 Analizando base de datos de Calendario: {db_path}")
    if not db_path.exists():
        print(f"❌ Base de datos no encontrada: {db_path}")
        return
        
    resultados = analizar_db_calendario(db_path)
    
    # Resumen de resultados
    print(f"📆 Eventos encontrados: {len(resultados['eventos'])}")
    print(f"📚 Calendarios encontrados: {len(resultados['calendarios'])}")
    print(f"⏰ Recordatorios encontrados: {len(resultados['recordatorios'])}")
    
    generar_html_calendario(resultados, output_html)

if __name__ == "__main__":
    main()