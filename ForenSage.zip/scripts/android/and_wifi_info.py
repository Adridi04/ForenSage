import os
import datetime
from pathlib import Path

def leer_xml_archivo(ruta_archivo):
    """
    Lee y devuelve el contenido bruto del archivo XML
    / Reads and returns the raw content of the XML file
    """
    contenido = ""
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        return contenido, file_exists
            
    try:
        with open(ruta_archivo, 'r', encoding='utf-8', errors='ignore') as file:
            contenido = file.read()
    except Exception as e:
        contenido = f"Error al leer el archivo: {str(e)}"
    
    return contenido, file_exists

def generar_html_xml_viewer(archivos_contenido, archivos_info, ruta_salida):
    """
    Genera un archivo HTML que muestra el contenido bruto de los archivos XML
    / Generates an HTML file showing the raw content of XML files
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception:
            return False

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XML Viewer | Visor de XML</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --warning: #e74c3c;
            --success: #27ae60;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .sources-container {{
            margin-top: 2rem;
            margin-bottom: 2rem;
        }}

        .source-card {{
            background-color: var(--primary);
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}

        .source-path {{
            font-family: monospace;
            color: var(--text);
        }}

        .source-status {{
            font-size: 0.9rem;
            padding: 0.3rem 0.8rem;
            border-radius: 12px;
        }}

        .source-found {{
            background-color: var(--success);
            color: var(--text);
        }}

        .source-not-found {{
            background-color: var(--warning);
            color: var(--text);
        }}

        .xml-container {{
            background-color: var(--card-bg);
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .xml-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid var(--border-color);
        }}

        .xml-title {{
            color: var(--accent-light);
            font-size: 1.2rem;
            font-weight: 600;
        }}

        .xml-content {{
            font-family: monospace;
            white-space: pre-wrap;
            max-height: 500px;
            overflow-y: auto;
            background-color: rgba(0, 0, 0, 0.2);
            padding: 1rem;
            border-radius: 5px;
            font-size: 0.9rem;
            line-height: 1.5;
        }}

        .xml-content .tag {{
            color: #569cd6;
        }}

        .xml-content .attribute {{
            color: #9cdcfe;
        }}

        .xml-content .value {{
            color: #ce9178;
        }}

        .xml-content .comment {{
            color: #6a9955;
        }}

        .xml-empty {{
            color: var(--text-secondary);
            font-style: italic;
            text-align: center;
            padding: 2rem;
        }}

        .formatted-toggle {{
            background-color: var(--primary-dark);
            color: var(--text);
            border: none;
            border-radius: 4px;
            padding: 0.5rem 1rem;
            cursor: pointer;
            font-family: 'Montserrat', sans-serif;
            transition: background-color 0.2s;
        }}

        .formatted-toggle:hover {{
            background-color: var(--primary-light);
        }}

        .copy-btn {{
            background-color: var(--primary-light);
            color: var(--text);
            border: none;
            border-radius: 4px;
            padding: 0.5rem 1rem;
            cursor: pointer;
            font-family: 'Montserrat', sans-serif;
            transition: background-color 0.2s;
            margin-left: 0.5rem;
        }}

        .copy-btn:hover {{
            background-color: var(--accent);
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .lang-toggle {{
            background-color: var(--card-bg);
            color: var(--text);
            border: 1px solid var(--primary-light);
            border-radius: 20px;
            padding: 0.5rem 1rem;
            cursor: pointer;
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-left: 1rem;
        }}

        .lang-toggle:hover {{
            border-color: var(--accent);
            transform: translateY(-2px);
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">XML Viewer | Visor de XML</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
            <button class="lang-toggle" onclick="toggleLanguage()">EN/ES</button>
        </div>
        
        <div class="sources-container">
            <h2>Archivos analizados | Analyzed files</h2>"""

    # Agregar información de los archivos analizados
    for archivo, existe in archivos_info:
        status_class = "source-found" if existe else "source-not-found"
        status_text = "Encontrado | Found" if existe else "No encontrado | Not found"
        html += f"""
            <div class="source-card">
                <div class="source-path">{archivo}</div>
                <div class="source-status {status_class}">{status_text}</div>
            </div>"""

    html += """
        </div>
    """

    # Agregar contenido de los archivos XML
    count_found = 0
    for i, (contenido, (archivo, existe)) in enumerate(zip(archivos_contenido, archivos_info)):
        if existe and contenido:
            count_found += 1
            file_id = f"file{i}"
            html += f"""
        <div class="xml-container">
            <div class="xml-header">
                <div class="xml-title">{os.path.basename(archivo)}</div>
                <div>
                    <button class="formatted-toggle" onclick="toggleFormat('{file_id}')">Formatear | Format</button>
                    <button class="copy-btn" onclick="copyToClipboard('{file_id}')">Copiar | Copy</button>
                </div>
            </div>
            <pre id="{file_id}" class="xml-content">{contenido.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')}</pre>
        </div>"""
    
    if count_found == 0:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron archivos XML | No XML files found</div>
            <p>No se han encontrado archivos XML válidos en las rutas especificadas. | No valid XML files were found in the specified paths.</p>
        </div>"""

    html += """
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
        
        function toggleLanguage() {
            document.querySelectorAll('[lang="es"]').forEach(el => {
                el.style.display = el.style.display === 'none' ? 'block' : 'none';
            });
            document.querySelectorAll('[lang="en"]').forEach(el => {
                el.style.display = el.style.display === 'none' ? 'block' : 'none';
            });
        }
        
        function toggleFormat(id) {
            const element = document.getElementById(id);
            const content = element.textContent;
            
            if (element.classList.contains('formatted')) {
                // Return to raw format
                element.textContent = content;
                element.classList.remove('formatted');
            } else {
                // Apply formatting
                try {
                    const parser = new DOMParser();
                    const xmlDoc = parser.parseFromString(content, "text/xml");
                    
                    if (xmlDoc.getElementsByTagName("parsererror").length > 0) {
                        // If parsing error, try to format manually
                        element.innerHTML = formatXML(content);
                    } else {
                        // Use formatted XML
                        const formatted = formatXMLWithDOM(xmlDoc);
                        element.innerHTML = formatted;
                    }
                    element.classList.add('formatted');
                } catch (e) {
                    // In case of error, try manual formatting
                    element.innerHTML = formatXML(content);
                    element.classList.add('formatted');
                }
            }
        }
        
        function formatXML(xml) {
            // Simple XML syntax highlighting
            let formatted = xml;
            formatted = formatted.replace(/&/g, '&amp;')
                                .replace(/</g, '&lt;')
                                .replace(/>/g, '&gt;');
            
            // Highlight tags
            formatted = formatted.replace(/&lt;\\/?([^\\s&gt;]+)([^&gt;]*)&gt;/g, 
                                        '<span class="tag">&lt;$1</span>$2<span class="tag">&gt;</span>');
            
            // Highlight attributes
            formatted = formatted.replace(/([\\w\\-:]+)=(&quot;|')(.*?)\\2/g, 
                                        '<span class="attribute">$1</span>=<span class="value">"$3"</span>');
            
            // Highlight comments
            formatted = formatted.replace(/&lt;!--([\\s\\S]*?)--&gt;/g, 
                                        '<span class="comment">&lt;!--$1--&gt;</span>');
            
            return formatted;
        }
        
        function formatXMLWithDOM(xmlDoc) {
            const serializer = new XMLSerializer();
            const xmlText = serializer.serializeToString(xmlDoc);
            
            // Add indentation
            let formatted = '';
            let indent = '';
            const tab = '    ';
            
            xmlText.split(/>[\\s]*</g).forEach(function(node) {
                if (node.match(/^\\/\\w/)) {
                    indent = indent.substring(tab.length);
                }
                
                formatted += indent + '<' + node + '>\\n';
                
                if (node.match(/^<[\\w][^\\/>]*$/)) {
                    indent += tab;
                }
            });
            
            return formatXML(formatted.substring(1, formatted.length - 2));
        }
        
        function copyToClipboard(id) {
            const element = document.getElementById(id);
            const content = element.textContent;
            
            navigator.clipboard.writeText(content).then(() => {
                alert('Contenido copiado al portapapeles! | Content copied to clipboard!');
            }).catch(err => {
                console.error('Error al copiar: ', err);
            });
        }
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {str(e)}")
        return False

def main():
    # Rutas de archivos a analizar
    rutas_a_analizar = [
        "/home/adrian/ForenSage/analyze/android/data/misc/wifi/WifiConfigStore.xml",
        "/home/adrian/ForenSage/analyze/android/data/misc_ce/0/wifi/WifiConfigStore.xml"
    ]
    
    # Para la salida, crear ruta relativa
    base_path = Path.home() / "ForenSage" / "results"
    salida_html = base_path / "and_wifi_info.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Leer contenido de archivos XML
    archivos_contenido = []
    archivos_info = []
    
    for ruta in rutas_a_analizar:
        contenido, existe = leer_xml_archivo(ruta)
        archivos_contenido.append(contenido)
        archivos_info.append((ruta, existe))
    
    # Generar el informe HTML
    generar_html_xml_viewer(archivos_contenido, archivos_info, salida_html)

if __name__ == "__main__":
    main()