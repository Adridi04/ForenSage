import os
import datetime
import shutil
from pathlib import Path
import mimetypes
import glob
import re

def es_archivo_imagen(ruta_archivo):
    """
    Determina si un archivo es una imagen basándose en su extensión o tipo MIME.
    """
    extensiones_imagen = ['.jpg', '.jpeg', '.png', '.heic', '.gif', '.bmp', '.tiff', '.webp']
    extension = os.path.splitext(ruta_archivo)[1].lower()
    
    if extension in extensiones_imagen:
        return True
    
    # Intentar determinar el tipo MIME
    tipo_mime, _ = mimetypes.guess_type(ruta_archivo)
    return tipo_mime and tipo_mime.startswith('image/')

def obtener_metadatos_basicos(ruta_archivo):
    """
    Obtiene metadatos básicos de un archivo.
    """
    try:
        stat = os.stat(ruta_archivo)
        return {
            'tamaño': stat.st_size,
            'modificado': datetime.datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
            'creado': datetime.datetime.fromtimestamp(stat.st_ctime).strftime('%Y-%m-%d %H:%M:%S'),
            'nombre': os.path.basename(ruta_archivo)
        }
    except Exception as e:
        print(f"Error obteniendo metadatos de {ruta_archivo}: {e}")
        return {
            'tamaño': 0,
            'modificado': 'Desconocido',
            'creado': 'Desconocido',
            'nombre': os.path.basename(ruta_archivo)
        }

def extraer_imagenes(rutas_origen, directorio_destino):
    """
    Extrae imágenes de las rutas especificadas y las copia al directorio de destino.
    Devuelve información sobre las imágenes extraídas.
    """
    imagenes_info = []
    contador = 0
    
    # Asegurar que el directorio de destino existe
    os.makedirs(directorio_destino, exist_ok=True)
    
    for ruta_base in rutas_origen:
        print(f"Analizando: {ruta_base}")
        
        if not os.path.exists(ruta_base):
            print(f"La ruta {ruta_base} no existe.")
            continue
        
        # Si es la ruta de miniaturas, necesitamos buscar en subdirectorios
        if "Thumbnails/V2" in ruta_base:
            # Usar glob para encontrar todas las carpetas
            for carpeta in glob.glob(os.path.join(ruta_base, "*")):
                if os.path.isdir(carpeta):
                    print(f"Analizando subcarpeta: {carpeta}")
                    for ruta, _, archivos in os.walk(carpeta):
                        for archivo in archivos:
                            ruta_completa = os.path.join(ruta, archivo)
                            if es_archivo_imagen(ruta_completa):
                                info_imagen = procesar_imagen(ruta_completa, directorio_destino, contador)
                                if info_imagen:
                                    imagenes_info.append(info_imagen)
                                    contador += 1
        else:
            # Para rutas normales, buscar imágenes directamente
            for ruta, _, archivos in os.walk(ruta_base):
                for archivo in archivos:
                    ruta_completa = os.path.join(ruta, archivo)
                    if es_archivo_imagen(ruta_completa):
                        info_imagen = procesar_imagen(ruta_completa, directorio_destino, contador)
                        if info_imagen:
                            imagenes_info.append(info_imagen)
                            contador += 1
    
    return imagenes_info

def procesar_imagen(ruta_completa, directorio_destino, contador):
    """
    Procesa una imagen individual, la copia al destino y devuelve su información.
    """
    try:
        # Obtener metadatos
        metadatos = obtener_metadatos_basicos(ruta_completa)
        
        # Generar un nombre único para evitar colisiones
        extension = os.path.splitext(ruta_completa)[1].lower()
        nombre_destino = f"imagen_{contador}{extension}"
        ruta_destino = os.path.join(directorio_destino, nombre_destino)
        
        # Copiar el archivo
        shutil.copy2(ruta_completa, ruta_destino)
        
        # Crear la información de la imagen
        return {
            'ruta_original': ruta_completa,
            'ruta_destino': ruta_destino,
            'ruta_relativa': os.path.join('images', nombre_destino),
            'nombre': metadatos['nombre'],
            'tamaño': metadatos['tamaño'],
            'modificado': metadatos['modificado'],
            'creado': metadatos['creado']
        }
    except Exception as e:
        print(f"Error procesando imagen {ruta_completa}: {e}")
        return None

def generar_html_imagenes(imagenes_info, ruta_salida):
    """
    Genera un único archivo HTML con todas las imágenes extraídas.
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception as e:
            print(f"Error creando directorio: {e}")
            return False

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Crear el HTML principal
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iOS Extracted Images | Imágenes extraídas de iOS</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .summary {{
            background-color: var(--card-bg);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            animation: fadeIn 0.8s ease-in-out;
        }}

        .summary h2 {{
            color: var(--accent-light);
            margin-bottom: 1rem;
        }}

        .summary-data {{
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 1rem;
        }}

        .summary-item {{
            flex: 1;
            min-width: 200px;
            text-align: center;
            padding: 1rem;
            background-color: var(--primary);
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .summary-item:hover {{
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
        }}

        .summary-value {{
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent-light);
        }}

        .summary-label {{
            font-size: 0.9rem;
            color: var(--text-secondary);
        }}

        .gallery {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
            animation: fadeIn 0.9s ease-in-out;
        }}

        .image-card {{
            background-color: var(--card-bg);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }}

        .image-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.4);
        }}

        .img-container {{
            height: 200px;
            overflow: hidden;
            position: relative;
        }}

        .img-container img {{
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }}

        .image-card:hover .img-container img {{
            transform: scale(1.05);
        }}

        .image-info {{
            padding: 1rem;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }}

        .image-name {{
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
            color: var(--accent-light);
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}

        .image-meta {{
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-bottom: 0.3rem;
        }}

        .modal {{
            display: none;
            position: fixed;
            z-index: 100;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.9);
            animation: fadeIn 0.3s;
        }}

        .modal-content {{
            margin: auto;
            display: block;
            max-width: 90%;
            max-height: 90%;
            animation: zoomIn 0.3s;
        }}

        .modal-info {{
            margin: 15px auto;
            display: block;
            width: 80%;
            max-width: 700px;
            text-align: center;
            color: var(--text);
            background-color: var(--card-bg);
            padding: 15px;
            border-radius: 8px;
        }}

        .modal-close {{
            position: absolute;
            top: 15px;
            right: 35px;
            color: var(--text);
            font-size: 40px;
            font-weight: bold;
            transition: 0.3s;
            cursor: pointer;
        }}

        .modal-close:hover,
        .modal-close:focus {{
            color: var(--accent);
        }}

        .view-btn {{
            margin-top: auto;
            background-color: var(--primary);
            color: var(--text);
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s ease;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }}

        .view-btn:hover {{
            background-color: var(--primary-light);
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            animation: fadeIn 0.7s ease-in-out;
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .top-btn {{
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: var(--primary);
            color: var(--text);
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            text-align: center;
            line-height: 50px;
            font-size: 20px;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            display: none;
            z-index: 99;
            transition: background-color 0.3s ease;
        }}

        .top-btn:hover {{
            background-color: var(--primary-light);
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @keyframes zoomIn {{
            from {{ transform: scale(0); }}
            to {{ transform: scale(1); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .gallery {{
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }}
            .modal-content {{
                width: 100%;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">iOS Extracted Images | Imágenes extraídas de iOS</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
        </div>"""

    if not imagenes_info:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron imágenes | No images found</div>
            <p>No se han encontrado imágenes en las rutas especificadas. | No images were found in the specified paths.</p>
        </div>"""
    else:
        # Agregar resumen
        html += f"""
        <div class="summary">
            <h2>Resumen | Summary</h2>
            <div class="summary-data">
                <div class="summary-item">
                    <div class="summary-value">{len(imagenes_info)}</div>
                    <div class="summary-label">Imágenes extraídas | Extracted images</div>
                </div>
            </div>
        </div>
        
        <div class="gallery">"""
        
        # Agregar cada imagen a la galería
        for i, imagen in enumerate(imagenes_info):
            nombre = imagen['nombre']
            ruta_relativa = imagen['ruta_relativa']
            tamaño = round(imagen['tamaño'] / 1024, 2)  # Convertir a KB
            fecha_mod = imagen['modificado']
            ruta_original = imagen['ruta_original']
            
            html += f"""
            <div class="image-card">
                <div class="img-container">
                    <img src="{ruta_relativa}" alt="{nombre}" loading="lazy" onclick="openModal('{ruta_relativa}', '{nombre}', '{tamaño}', '{fecha_mod}', '{ruta_original}')">
                </div>
                <div class="image-info">
                    <div class="image-name">{nombre}</div>
                    <div class="image-meta">Tamaño: {tamaño} KB</div>
                    <div class="image-meta">Modificado: {fecha_mod}</div>
                    <button class="view-btn" onclick="openModal('{ruta_relativa}', '{nombre}', '{tamaño}', '{fecha_mod}', '{ruta_original}')">Ver imagen completa</button>
                </div>
            </div>"""
        
        html += """
        </div>"""

    # Agregar modal para ver imágenes
    html += """
    <div id="imageModal" class="modal">
        <span class="modal-close" onclick="closeModal()">&times;</span>
        <img class="modal-content" id="modalImage">
        <div class="modal-info" id="modalInfo"></div>
    </div>
    
    <button id="topBtn" class="top-btn" onclick="scrollToTop()">↑</button>"""

    html += f"""
        <div class="footer">
            <p>📁 Ruta del informe: <code>{ruta_salida}</code></p>
            <p>📁 Report path: <code>{ruta_salida}</code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        // Función para abrir el modal
        function openModal(src, name, size, date, originalPath) {{
            const modal = document.getElementById("imageModal");
            const modalImg = document.getElementById("modalImage");
            const modalInfo = document.getElementById("modalInfo");
            
            modal.style.display = "block";
            modalImg.src = src;
            
          modalInfo.innerHTML = '<div><strong>Nombre | Name:</strong> ' + name + '</div>' +
                '<div><strong>Tamaño | Size:</strong> ' + size + ' KB</div>' +
                '<div><strong>Modificado | Modified:</strong> ' + date + '</div>' +
                '<div><strong>Ruta original | Original path:</strong> ' + originalPath + '</div>';
        
        }}
        
        // Función para cerrar el modal
        function closeModal() {{
            document.getElementById("imageModal").style.display = "none";
        }}
        
        // Cerrar modal al hacer clic fuera de la imagen
        window.onclick = function(event) {{
            const modal = document.getElementById("imageModal");
            if (event.target == modal) {{
                modal.style.display = "none";
            }}
        }};
        
        // Mostrar/ocultar botón para volver arriba
        window.onscroll = function() {{
            const topBtn = document.getElementById("topBtn");
            if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {{
                topBtn.style.display = "block";
            }} else {{
                topBtn.style.display = "none";
            }}
        }};
        
        // Función para volver arriba
        function scrollToTop() {{
            document.body.scrollTop = 0; // Para Safari
            document.documentElement.scrollTop = 0; // Para Chrome, Firefox, IE y Opera
        }}
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Rutas a analizar
    rutas_a_analizar = [
        "/home/adrian/ForenSage/analyze/ios/private/var/mobile/Media/DCIM/100APPLE/",
        "/home/adrian/ForenSage/analyze/ios/private/var/mobile/Media/PhotoData/Metadata/DCIM/100APPLE/",
        "/home/adrian/ForenSage/analyze/ios/private/var/mobile/Media/PhotoData/Thumbnails/V2/DCIM/100APPLE/"
    ]
    
    # Configurar rutas de salida
    base_path = Path.home() / "ForenSage"
    directorio_imagenes = base_path / "results/images"
    ruta_html = base_path / "results/IOS_images_report.html"
    
    # Asegurar que el directorio de resultados existe
    os.makedirs(directorio_imagenes, exist_ok=True)
    
    # Extraer imágenes
    print("Iniciando extracción de imágenes...")
    imagenes_info = extraer_imagenes(rutas_a_analizar, directorio_imagenes)
    
    # Generar informe HTML único con todas las imágenes
    print(f"Generando informe con {len(imagenes_info)} imágenes...")
    generar_html_imagenes(imagenes_info, str(ruta_html))
    
    print(f"Proceso completado. Se extrajeron {len(imagenes_info)} imágenes.")
    

if __name__ == "__main__":
    main()