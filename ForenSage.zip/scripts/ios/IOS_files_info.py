import os
import datetime
import hashlib
import mimetypes
from pathlib import Path

def analyze_downloads_folder(folder_path):
    """
    Analyzes the iOS Downloads folder and extracts information about all files.
    / Analiza la carpeta de Descargas de iOS y extrae información sobre todos los archivos.
    """
    results = []
    file_extensions = {}
    total_size = 0
    
    if not os.path.exists(folder_path):
        return results, file_extensions, total_size, False
    
    try:
        # Walk through the folder and extract file information
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                file_info = {}
                
                # Basic file information
                file_info["Name"] = file
                file_info["Path"] = os.path.relpath(file_path, folder_path)
                
                # File size
                try:
                    file_size = os.path.getsize(file_path)
                    file_info["Size"] = file_size
                    total_size += file_size
                    file_info["SizeReadable"] = get_readable_size(file_size)
                except Exception:
                    file_info["Size"] = 0
                    file_info["SizeReadable"] = "0 B"
                
                # File type and extension
                file_ext = os.path.splitext(file)[1].lower()
                file_info["Extension"] = file_ext if file_ext else "No extension"
                
                # Count extensions
                if file_ext in file_extensions:
                    file_extensions[file_ext] += 1
                else:
                    file_extensions[file_ext] = 1
                
                # MIME type
                mime_type, _ = mimetypes.guess_type(file_path)
                file_info["MIME"] = mime_type if mime_type else "unknown/unknown"
                
                # Creation and modification times
                try:
                    mod_time = os.path.getmtime(file_path)
                    create_time = os.path.getctime(file_path)
                    
                    file_info["Modified"] = datetime.datetime.fromtimestamp(mod_time).strftime("%Y-%m-%d %H:%M:%S")
                    file_info["Created"] = datetime.datetime.fromtimestamp(create_time).strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    file_info["Modified"] = "Unknown"
                    file_info["Created"] = "Unknown"
                
                # Calculate MD5 hash for smaller files (less than 10MB)
                try:
                    if file_size < 10 * 1024 * 1024:  # 10MB
                        file_info["MD5"] = calculate_md5(file_path)
                    else:
                        file_info["MD5"] = "File too large to hash (>10MB)"
                except Exception:
                    file_info["MD5"] = "Could not calculate"
                
                # Determine file category
                file_info["Category"] = determine_file_category(file_info["MIME"], file_ext)
                
                results.append(file_info)
    
    except Exception as e:
        print(f"Error analyzing folder {folder_path}: {e}")
    
    # Sort results by modification time (newest first)
    results.sort(key=lambda x: x.get("Modified", ""), reverse=True)
    
    return results, file_extensions, total_size, True

def calculate_md5(file_path):
    """Calculate MD5 hash of a file"""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def get_readable_size(size_bytes):
    """Convert bytes to a human-readable format"""
    if size_bytes == 0:
        return "0 B"
    size_names = ("B", "KB", "MB", "GB", "TB")
    i = 0
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024
        i += 1
    return f"{size_bytes:.2f} {size_names[i]}"

def determine_file_category(mime_type, extension):
    """
    Determine a file's category based on its MIME type and extension
    / Determina la categoría de un archivo basándose en su tipo MIME y extensión
    """
    if not mime_type:
        mime_type = "unknown/unknown"
    
    mime_category = mime_type.split('/')[0]
    
    # Common file types categorization
    if mime_category == "image":
        return "Image" 
    elif mime_category == "video":
        return "Video"
    elif mime_category == "audio":
        return "Audio"
    elif mime_category == "text":
        return "Text"
    elif mime_category == "application":
        # Further categorize application types
        if mime_type == "application/pdf":
            return "PDF"
        elif mime_type in ["application/zip", "application/x-rar-compressed", "application/x-tar"]:
            return "Archive"
        elif "document" in mime_type:
            return "Document"
        elif "spreadsheet" in mime_type or "excel" in mime_type:
            return "Spreadsheet"
        elif "presentation" in mime_type or "powerpoint" in mime_type:
            return "Presentation"
        else:
            return "Application"
    
    # Check common extensions
    document_exts = [".pdf", ".doc", ".docx", ".txt", ".rtf"]
    archive_exts = [".zip", ".rar", ".tar", ".gz", ".7z"]
    image_exts = [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg"]
    
    if extension in document_exts:
        return "Document"
    elif extension in archive_exts:
        return "Archive"
    elif extension in image_exts:
        return "Image"
    
    return "Other"

def generate_html_files(file_data, extensions_data, total_size, folder_info, output_path):
    """
    Generate an HTML report with results from the Downloads folder analysis
    / Genera un informe HTML con los resultados del análisis de la carpeta de Descargas
    """
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception:
            return False

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    folder_path, folder_exists = folder_info
    
    # Prepare extension statistics
    top_extensions = sorted(extensions_data.items(), key=lambda x: x[1], reverse=True)[:8]
    
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iOS Downloads Folder | Análisis de Carpeta de Descargas de iOS</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .source-container {{
            margin-top: 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }}

        .source-card {{
            background-color: var(--primary);
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }}

        .source-path {{
            font-family: monospace;
            color: var(--text);
        }}

        .source-status {{
            font-size: 0.9rem;
            padding: 0.3rem 0.8rem;
            border-radius: 12px;
        }}

        .source-found {{
            background-color: var(--success);
            color: var(--text);
        }}

        .source-not-found {{
            background-color: var(--danger);
            color: var(--text);
        }}

        .summary-container {{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 2rem;
            margin: 3rem 0;
        }}

        .summary-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 1.5rem;
            width: 300px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            text-align: center;
            transition: all 0.3s ease;
        }}

        .summary-card:hover {{
            transform: translateY(-10px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.6);
        }}

        .summary-value {{
            font-size: 2.5rem;
            font-weight: 700;
            margin: 1rem 0;
            color: var(--accent-light);
        }}

        .summary-label {{
            font-size: 1rem;
            color: var(--text-secondary);
        }}

        .file-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            margin: 3rem 0;
        }}

        .file-card {{
            background-color: var(--card-bg);
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
            position: relative;
            overflow: hidden;
        }}

        .file-card::after {{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .file-name {{
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--accent-light);
            word-break: break-word;
        }}

        .file-detail {{
            margin-bottom: 0.5rem;
            display: flex;
            align-items: flex-start;
        }}

        .detail-label {{
            width: 90px;
            font-size: 0.8rem;
            color: var(--text-secondary);
            flex-shrink: 0;
        }}

        .detail-value {{
            font-size: 0.9rem;
            word-break: break-word;
        }}

        .file-category {{
            position: absolute;
            top: 1rem;
            right: 1rem;
            font-size: 0.8rem;
            padding: 0.3rem 0.8rem;
            border-radius: 12px;
            background-color: var(--primary-light);
        }}

        .category-Image {{ background-color: var(--success); }}
        .category-Video {{ background-color: var(--accent); }}
        .category-Audio{{ background-color: var(--warning); }}
        .category-Document {{ background-color: var(--primary-light); }}
        .category-Archive {{ background-color: var(--danger); }}

        .extensions-container {{
            background-color: var(--card-bg);
            border-radius: 12px;
            padding: 2rem;
            margin: 3rem 0;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
        }}

        .extensions-heading {{
            font-size: 1.5rem;
            margin-bottom: 2rem;
            text-align: center;
            color: var(--accent-light);
        }}

        .extension-bars {{
            max-width: 800px;
            margin: 0 auto;
        }}

        .extension-bar {{
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }}

        .extension-name {{
            width: 100px;
            text-align: right;
            padding-right: 1rem;
            font-family: monospace;
        }}

        .extension-count {{
            width: 50px;
            text-align: center;
        }}

        .bar {{
            flex-grow: 1;
            height: 20px;
            background: linear-gradient(90deg, var(--accent), var(--accent-light));
            border-radius: 10px;
            margin: 0 1rem;
        }}

        .search-container {{
            max-width: 800px;
            margin: 2rem auto;
            position: relative;
        }}

        #fileSearch {{
            width: 100%;
            padding: 1rem;
            border-radius: 8px;
            border: none;
            background-color: var(--card-bg);
            color: var(--text);
            font-family: 'Montserrat', sans-serif;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .file-grid {{
                grid-template-columns: 1fr;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">iOS Downloads Folder | Análisis de Carpeta de Descargas</h1>
            <p class="subtitle">📅 Generado el {timestamp} | Generated on {timestamp}</p>
        </div>"""

    # Show folder information
    status_text = "Encontrada | Found" if folder_exists else "No encontrada | Not found"
    status_class = "source-found" if folder_exists else "source-not-found"
    
    html += f"""
        <div class="source-container">
            <div class="source-card">
                <div class="source-path">{folder_path}</div>
                <div class="source-status {status_class}">{status_text}</div>
            </div>
        </div>"""

    if not file_data:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron archivos | No files found</div>
            <p>No se han encontrado archivos en la carpeta de descargas. | No files found in the downloads folder.</p>
        </div>"""
    else:
        # Summary statistics
        html += f"""
        <div class="summary-container">
            <div class="summary-card">
                <div class="summary-label">Archivos | Files</div>
                <div class="summary-value">{len(file_data)}</div>
            </div>
            
            <div class="summary-card">
                <div class="summary-label">Tamaño Total | Total Size</div>
                <div class="summary-value">{get_readable_size(total_size)}</div>
            </div>
            
            <div class="summary-card">
                <div class="summary-label">Extensiones | Extensions</div>
                <div class="summary-value">{len(extensions_data)}</div>
            </div>
        </div>
        
        <!-- Search Bar -->
        <div class="search-container">
            <input type="text" id="fileSearch" placeholder="Buscar archivos... | Search files...">
        </div>
        
        <!-- File Type Extensions Chart -->
        <div class="extensions-container">
            <h2 class="extensions-heading">Extensiones de Archivo | File Extensions</h2>
            <div class="extension-bars">"""
            
        # Generate bars for top extensions
        max_count = top_extensions[0][1] if top_extensions else 0
        
        for ext, count in top_extensions:
            if ext == "":
                ext_name = "(sin ext)"
            else:
                ext_name = ext
                
            percentage = (count / max_count) * 100
            
            html += f"""
                <div class="extension-bar">
                    <div class="extension-name">{ext_name}</div>
                    <div class="bar" style="width: {percentage}%"></div>
                    <div class="extension-count">{count}</div>
                </div>"""
        
        html += """
            </div>
        </div>
        
        <!-- File Grid -->
        <h2 class="extensions-heading">Archivos Encontrados | Files Found</h2>
        <div class="file-grid" id="fileGrid">"""
        
        # Generate a card for each file (limit to first 50 files)
        for file in file_data[:50]:
            category_class = f"category-{file['Category']}" if file['Category'] in ["Image", "Video", "Audio", "Document", "Archive"] else ""
            
            html += f"""
            <div class="file-card file-item">
                <div class="file-category {category_class}">{file['Category']}</div>
                <div class="file-name">{file['Name']}</div>
                
                <div class="file-detail">
                    <div class="detail-label">Path:</div>
                    <div class="detail-value">{file['Path']}</div>
                </div>
                
                <div class="file-detail">
                    <div class="detail-label">Size:</div>
                    <div class="detail-value">{file['SizeReadable']}</div>
                </div>
                
                <div class="file-detail">
                    <div class="detail-label">Type:</div>
                    <div class="detail-value">{file['MIME'] or 'Unknown'}</div>
                </div>
                
                <div class="file-detail">
                    <div class="detail-label">Modified:</div>
                    <div class="detail-value">{file['Modified']}</div>
                </div>
                
                <div class="file-detail">
                    <div class="detail-label">MD5:</div>
                    <div class="detail-value" style="font-family: monospace; font-size: 0.8rem;">{file['MD5'].split()[0]}</div>
                </div>
            </div>"""
        
        if len(file_data) > 50:
            html += f"""
            <div class="warning-card">
                <div class="warning-title">ℹ️ Más archivos disponibles | More files available</div>
                <p>Se muestran los primeros 50 archivos de un total de {len(file_data)}. | Showing first 50 files out of {len(file_data)}.</p>
            </div>"""
            
        html += """
        </div>"""

    # Add footer
    html += f"""
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
            <p>📁 Carpeta analizada | Analyzed folder: <code>{folder_path}</code> ({status_text})</p>
        </div>
        <footer class="footer">
            <p>ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
        
        // Search functionality
        const searchInput = document.getElementById('fileSearch');
        const fileItems = document.querySelectorAll('.file-item');
        
        searchInput.addEventListener('input', function() {{
            const searchTerm = this.value.toLowerCase();
            
            fileItems.forEach(item => {{
                const fileName = item.querySelector('.file-name').textContent.toLowerCase();
                const filePath = item.querySelector('.detail-value').textContent.toLowerCase();
                
                if (fileName.includes(searchTerm) || filePath.includes(searchTerm)) {{
                    item.style.display = '';
                }} else {{
                    item.style.display = 'none';
                }}
            }});
        }});
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Base paths
    base_path = Path.home() / "ForenSage"
    
    # Path to analyze - the iOS Downloads folder
    downloads_path = base_path / "analyze/ios/private/var/mobile/Library/Mobile Documents/com~apple~CloudDocs/Downloads/"
    
    # Output path for the report
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = base_path / "results" / "IOS_file_info.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # Analyze the folder
    print(f"📂 Analizando carpeta de descargas: {downloads_path}")
    file_data, extensions_data, total_size, folder_exists = analyze_downloads_folder(str(downloads_path))
    
    # Generate the HTML report
    print(f"🔍 Generando informe con {len(file_data)} archivos encontrados...")
    generate_html_files(
        file_data, 
        extensions_data, 
        total_size, 
        (str(downloads_path), folder_exists), 
        str(output_path)
    )
    
    print(f"✅ Análisis completado. Informe guardado en: {output_path}")

if __name__ == "__main__":
    main()