import os
import datetime
import plistlib
from pathlib import Path

def analizar_iconstate_plist(rutas_posibles):
    """
    Analiza un archivo IconState.plist de iOS y extrae la información sobre
    la disposición de los iconos en la pantalla de inicio. Intenta con varias rutas posibles.
    """
    resultados = {
        "pantallas": [],
        "dock": [],
        "aplicaciones": [],
        "estadisticas": {
            "total_apps": 0,
            "total_pantallas": 0,
            "apps_system": 0,
            "apps_third_party": 0,
            "apps_por_pantalla": {},
            "apps_en_dock": 0
        },
        "metadata": {}
    }
    
    archivo_encontrado = False
    ruta_usada = None
    
    # Intentar con cada ruta posible
    for ruta_archivo in rutas_posibles:
        if os.path.exists(ruta_archivo):
            archivo_encontrado = True
            ruta_usada = ruta_archivo
            try:
                # Leer el archivo plist
                with open(ruta_archivo, 'rb') as f:
                    plist_data = plistlib.load(f)
                
                # Guardar estructura básica en metadata
                resultados["metadata"]["estructura"] = list(plist_data.keys())
                
                # Analizar las páginas de iconos
                if 'iconLists' in plist_data:
                    iconLists = plist_data['iconLists']
                    resultados["estadisticas"]["total_pantallas"] = len(iconLists)
                    
                    # Procesar cada pantalla
                    for idx, pantalla in enumerate(iconLists):
                        apps_pantalla = []
                        
                        # Procesar cada fila en la pantalla
                        for fila in pantalla:
                            # Procesar cada aplicación en la fila
                            for app_info in fila:
                                if isinstance(app_info, dict):
                                    app_data = procesar_app_info(app_info)
                                    if app_data:
                                        apps_pantalla.append(app_data)
                                        resultados["aplicaciones"].append(app_data)
                        
                        # Guardar datos de esta pantalla
                        resultados["pantallas"].append({
                            "numero": idx + 1,
                            "apps": apps_pantalla
                        })
                        
                        # Actualizar estadísticas
                        resultados["estadisticas"]["apps_por_pantalla"][f"pantalla_{idx+1}"] = len(apps_pantalla)
                
                # Analizar el dock
                if 'buttonBar' in plist_data:
                    dock_apps = []
                    for app_info in plist_data['buttonBar']:
                        if isinstance(app_info, dict):
                            app_data = procesar_app_info(app_info)
                            if app_data:
                                dock_apps.append(app_data)
                                resultados["aplicaciones"].append(app_data)
                    
                    resultados["dock"] = dock_apps
                    resultados["estadisticas"]["apps_en_dock"] = len(dock_apps)
                
                # Actualizar estadísticas generales
                resultados["estadisticas"]["total_apps"] = len(resultados["aplicaciones"])
                
                # Contar apps del sistema vs. third-party
                system_apps = sum(1 for app in resultados["aplicaciones"] if app.get("es_sistema", False))
                resultados["estadisticas"]["apps_system"] = system_apps
                resultados["estadisticas"]["apps_third_party"] = resultados["estadisticas"]["total_apps"] - system_apps
                
                # Si encontramos y procesamos un archivo válido, salimos del bucle
                break
                
            except Exception as e:
                resultados["metadata"]["error"] = f"Error analizando {ruta_archivo}: {str(e)}"
    
    return resultados, archivo_encontrado, ruta_usada

def procesar_app_info(app_info):
    """
    Procesa la información de una aplicación y extrae los datos relevantes.
    """
    if not isinstance(app_info, dict):
        return None
        
    app_data = {}
    
    # Extraer información básica
    if 'bundleIdentifier' in app_info:
        app_data["bundle_id"] = app_info['bundleIdentifier']
    
    if 'displayName' in app_info:
        app_data["nombre"] = app_info['displayName']
    elif 'displayIdentifier' in app_info:
        app_data["nombre"] = app_info['displayIdentifier'].split('.')[-1]
    
    # Determinar si es app del sistema o de terceros
    if 'bundleIdentifier' in app_info:
        bundle_id = app_info['bundleIdentifier']
        app_data["es_sistema"] = bundle_id.startswith('com.apple')
    
    return app_data if app_data else None

def generar_html_simplificado(datos, ruta_archivo, ruta_salida):
    """
    Genera un archivo HTML simplificado con los resultados del análisis
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception as e:
            print(f"Error al crear directorio de salida: {e}")
            return False

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # HTML Básico
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de Pantalla de Inicio iOS</title>
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            animation: fadeIn 0.5s ease-out;
        }}
        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .card {{
            background-color: var(--card-bg);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }}
        h2 {{
            color: var(--primary);
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 10px;
        }}
        .stat-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }}
        .stat-card {{
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }}
        .stat-value {{
            font-size: 24px;
            font-weight: bold;
            color: var(--accent);
        }}
        .app-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            gap: 10px;
            margin-top: 15px;
        }}
        .app-item {{
            background-color: #f8f9fa;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
        }}
        .app-icon {{
            width: 50px;
            height: 50px;
            border-radius: 10px;
            margin: 0 auto 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: white;
        }}
        .system-app {{
            background-color: var(--system-app);
        }}
        .third-party-app {{
            background-color: var(--third-party);
        }}
        .app-name {{
            font-size: 12px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .tab-container {{
            margin: 20px 0;
        }}
        .tabs {{
            display: flex;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 15px;
        }}
        .tab {{
            padding: 8px 15px;
            cursor: pointer;
            background-color: #f0f0f0;
            border: 1px solid var(--border-color);
            border-bottom: none;
            border-radius: 5px 5px 0 0;
            margin-right: 5px;
        }}
        .tab.active {{
            background-color: white;
            border-bottom: 1px solid white;
            position: relative;
            bottom: -1px;
        }}
        .tab-content {{
            display: none;
        }}
        .tab-content.active {{
            display: block;
        }}
        .warning {{
            background-color: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }}
        .footer {{
            text-align: center;
            margin-top: 30px;
            color: #777;
            font-size: 14px;
            border-top: 1px solid var(--border-color);
            padding-top: 15px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Análisis de Pantalla de Inicio iOS</h1>
            <p>Generado el {ahora}</p>
            <p>Archivo analizado: {ruta_archivo}</p>
        </div>
"""

    # Verificar si hay datos
    if not datos or not datos.get("pantallas"):
        html += """
        <div class="warning">
            <strong>⚠️ No se encontraron datos</strong>
            <p>No se ha podido extraer información del archivo IconState.plist.</p>
        </div>"""
        
        # Si hay metadatos con errores, mostrarlos
        if datos and "metadata" in datos and "error" in datos["metadata"]:
            html += f"""
        <div class="warning">
            <strong>⚠️ Error de análisis</strong>
            <p>{datos["metadata"]["error"]}</p>
        </div>"""
    else:
        # Obtener estadísticas
        estadisticas = datos.get("estadisticas", {})
        total_apps = estadisticas.get("total_apps", 0)
        apps_system = estadisticas.get("apps_system", 0)
        apps_third_party = estadisticas.get("apps_third_party", 0)
        total_pantallas = estadisticas.get("total_pantallas", 0)
        apps_en_dock = estadisticas.get("apps_en_dock", 0)
        
        # Mostrar resumen general
        html += f"""
        <div class="card">
            <h2>Resumen General</h2>
            <div class="stat-grid">
                <div class="stat-card">
                    <div class="stat-value">{total_apps}</div>
                    <div>Total Apps</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{apps_system}</div>
                    <div>Apps del Sistema</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{apps_third_party}</div>
                    <div>Apps de Terceros</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{total_pantallas}</div>
                    <div>Pantallas</div>
                </div>
            </div>
        </div>"""
        
        # Pestañas para mostrar Dock y Pantallas
        html += """
        <div class="tab-container">
            <div class="tabs">
                <div class="tab active" onclick="openTab(event, 'dock-tab')">Dock</div>
                <div class="tab" onclick="openTab(event, 'screens-tab')">Pantallas</div>
                <div class="tab" onclick="openTab(event, 'all-apps-tab')">Todas las Apps</div>
            </div>
            
            <div id="dock-tab" class="tab-content active">
                <div class="card">
                    <h2>Dock</h2>"""
        
        # Mostrar Dock
        if datos.get("dock"):
            html += """
                    <div class="app-grid">"""
            
            for app in datos.get("dock", []):
                app_name = app.get("nombre", "Unknown")
                bundle_id = app.get("bundle_id", "N/A")
                es_sistema = app.get("es_sistema", False)
                icon_class = "system-app" if es_sistema else "third-party-app"
                
                html += f"""
                        <div class="app-item">
                            <div class="app-icon {icon_class}">{app_name[0].upper()}</div>
                            <div class="app-name">{app_name}</div>
                        </div>"""
            
            html += """
                    </div>"""
        else:
            html += """
                    <div class="warning">
                        <p>No se encontraron apps en el Dock</p>
                    </div>"""
        
        html += """
                </div>
            </div>
            
            <div id="screens-tab" class="tab-content">"""
        
        # Mostrar Pantallas
        if datos.get("pantallas"):
            for idx, pantalla in enumerate(datos.get("pantallas", [])):
                apps_en_pantalla = pantalla.get("apps", [])
                
                html += f"""
                <div class="card">
                    <h2>Pantalla {pantalla.get("numero", idx+1)}</h2>
                    <div class="app-grid">"""
                
                for app in apps_en_pantalla:
                    app_name = app.get("nombre", "Unknown")
                    bundle_id = app.get("bundle_id", "N/A")
                    es_sistema = app.get("es_sistema", False)
                    icon_class = "system-app" if es_sistema else "third-party-app"
                    
                    html += f"""
                        <div class="app-item">
                            <div class="app-icon {icon_class}">{app_name[0].upper()}</div>
                            <div class="app-name">{app_name}</div>
                        </div>"""
                
                html += """
                    </div>
                </div>"""
        else:
            html += """
                <div class="warning">
                    <p>No se encontraron pantallas con aplicaciones</p>
                </div>"""
        
        html += """
            </div>
            
            <div id="all-apps-tab" class="tab-content">
                <div class="card">
                    <h2>Todas las Aplicaciones</h2>
                    <div class="app-grid">"""
        
        # Mostrar todas las apps
        for app in datos.get("aplicaciones", []):
            app_name = app.get("nombre", "Unknown")
            bundle_id = app.get("bundle_id", "N/A")
            es_sistema = app.get("es_sistema", False)
            icon_class = "system-app" if es_sistema else "third-party-app"
            
            html += f"""
                        <div class="app-item">
                            <div class="app-icon {icon_class}">{app_name[0].upper()}</div>
                            <div class="app-name">{app_name}</div>
                        </div>"""
        
        html += """
                    </div>
                </div>
            </div>
        </div>"""

    # Pie de página
    html += """
        <div class="footer">
            <p>ForenSage © 2025 - Forensic Tool</p>
        </div>
    </div>

    <script>
        function openTab(evt, tabName) {
            var i, tabcontent, tablinks;
            
            // Ocultar todos los contenidos de pestaña
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            
            // Desactivar todos los botones de pestaña
            tablinks = document.getElementsByClassName("tab");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            
            // Mostrar la pestaña actual y marcar el botón como activo
            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active");
        }
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Definir múltiples rutas posibles para el archivo IconState.plist
    base_path = Path.home() / "ForenSage"
    rutas_posibles = [
        base_path / "analyze/ios/private/var/mobile/Library/SpringBoard/IconState.plist",
        base_path / "extract/ios/private/var/mobile/Library/SpringBoard/IconState.plist",
        base_path / "data/ios/private/var/mobile/Library/SpringBoard/IconState.plist",
        base_path / "ios/private/var/mobile/Library/SpringBoard/IconState.plist",
        base_path / "private/var/mobile/Library/SpringBoard/IconState.plist",
        "IconState.plist"  # Buscar en el directorio actual
    ]
    
    # Convertir Path a string para compatibilidad
    rutas_str = [str(ruta) for ruta in rutas_posibles]
    
    # Ruta para el informe HTML
    salida_html = base_path / "results/iOS_HomeScreen_Analysis.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar archivo
    datos, archivo_encontrado, ruta_usada = analizar_iconstate_plist(rutas_str)
    
    if archivo_encontrado:
        print(f"✅ Archivo encontrado en: {ruta_usada}")
    else:
        print("❌ No se encontró el archivo. Rutas probadas:")
        for ruta in rutas_str:
            print(f"  - {ruta}")
    
    # Generar el informe HTML
    generar_html_simplificado(datos, ruta_usada if archivo_encontrado else "Archivo no encontrado", str(salida_html))

if __name__ == "__main__":
    main()