import os
import sqlite3
import datetime
from pathlib import Path

def connect_to_db(db_path):
    """Connect to SQLite database"""
    if not os.path.exists(db_path):
        print(f"❌ Database file not found: {db_path}")
        return None
    
    try:
        # Intenta conexión normal primero (el modo de solo lectura puede fallar en algunos sistemas)
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row  # Permite acceso a columnas por nombre
        return conn
    except sqlite3.Error as e:
        print(f"❌ Error connecting to database: {e}")
        return None

def check_for_zwamessage_table(conn):
    """Verifica si la tabla ZWAMESSAGE existe en la base de datos"""
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ZWAMESSAGE';")
        return cursor.fetchone() is not None
    except sqlite3.Error as e:
        print(f"❌ Error checking for ZWAMESSAGE table: {e}")
        return False

def get_table_columns(conn, table_name):
    """Obtiene los nombres de las columnas de una tabla"""
    try:
        cursor = conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name});")
        return [row["name"] for row in cursor.fetchall()]
    except sqlite3.Error as e:
        print(f"❌ Error getting columns for table {table_name}: {e}")
        return []

def extract_messages_from_zwamessage(conn, limit=1000):
    """Extrae mensajes directamente de la tabla ZWAMESSAGE, con énfasis en la columna ZTEXT"""
    messages = []
    try:
        cursor = conn.cursor()
        
        # Verifica si la tabla existe
        if not check_for_zwamessage_table(conn):
            print("❌ Tabla ZWAMESSAGE no encontrada en la base de datos")
            
            # Intenta listar todas las tablas para diagnóstico
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = [row[0] for row in cursor.fetchall()]
            print(f"📋 Tablas disponibles: {', '.join(tables)}")
            return messages
        
        # Obtiene las columnas de la tabla
        columns = get_table_columns(conn, "ZWAMESSAGE")
        print(f"📊 Columnas en ZWAMESSAGE: {', '.join(columns)}")
        
        # Verifica si ZTEXT está presente
        if "ZTEXT" not in columns:
            print("❌ La columna ZTEXT no existe en la tabla ZWAMESSAGE")
            return messages
        
        # Columnas importantes a buscar
        important_columns = [
            "Z_PK",           # ID principal
            "ZTEXT",          # Contenido del mensaje
            "ZSENTDATE",      # Fecha de envío
            "ZMESSAGEDATE",   # Fecha alternativa
            "ZISFROMME",      # Si el mensaje es enviado por mí
            "ZPUSHNAME",      # Nombre del remitente
            "ZSTANZAID"       # ID del mensaje
        ]
        
        # Filtra columnas que existen en la tabla
        select_columns = [col for col in important_columns if col in columns]
        
        # Si no hay columnas importantes, selecciona todas
        if not select_columns:
            print("⚠️ No se encontraron columnas esperadas, seleccionando todas las columnas")
            column_list = "*"
        else:
            column_list = ", ".join(select_columns)
        
        # Determina la columna de fecha para ordenar
        date_column = "ZSENTDATE" if "ZSENTDATE" in columns else "ZMESSAGEDATE" if "ZMESSAGEDATE" in columns else None
        
        # Construye la consulta
        if date_column:
            query = f"SELECT {column_list} FROM ZWAMESSAGE ORDER BY {date_column} DESC LIMIT ?"
        else:
            query = f"SELECT {column_list} FROM ZWAMESSAGE LIMIT ?"
        
        print(f"🔍 Ejecutando consulta: {query}")
        cursor.execute(query, (limit,))
        
        rows = cursor.fetchall()
        print(f"✅ Se encontraron {len(rows)} mensajes")
        
        for row in cursor.fetchall():
            message_data = {}
            for column in row.keys():
                message_data[column] = row[column]
            
            # Conversión de fecha si existe
            if "ZSENTDATE" in message_data and message_data["ZSENTDATE"]:
                try:
                    # Referencia de fecha de Apple Core Data: 2001-01-01
                    mac_epoch = datetime.datetime(2001, 1, 1)
                    # Convierte segundos a datetime
                    date = mac_epoch + datetime.timedelta(seconds=message_data["ZSENTDATE"])
                    message_data["formatted_date"] = date.strftime("%Y-%m-%d %H:%M:%S")
                except Exception as e:
                    message_data["formatted_date"] = "Error en conversión de fecha"
            
            messages.append(message_data)
        
        return messages
    except sqlite3.Error as e:
        print(f"❌ Error al extraer mensajes de ZWAMESSAGE: {e}")
        return []

def generate_html_report(messages, output_path):
    """Genera un reporte HTML sencillo con los mensajes extraídos"""
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensajes de WhatsApp</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            background-color: #ECE5DD;
            margin: 0;
            padding: 20px;
        }}
        .container {{
            max-width: 1000px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #075E54;
            text-align: center;
        }}
        .message {{
            margin-bottom: 15px;
            padding: 10px 15px;
            border-radius: 7px;
            position: relative;
            max-width: 80%;
            clear: both;
        }}
        .message.from-me {{
            background-color: #DCF8C6;
            float: right;
        }}
        .message.from-other {{
            background-color: white;
            float: left;
            border: 1px solid #E2E2E2;
        }}
        .message-text {{
            margin-bottom: 5px;
            word-wrap: break-word;
        }}
        .message-info {{
            font-size: 0.7em;
            color: #888;
            text-align: right;
        }}
        .clear {{
            clear: both;
        }}
        .no-messages {{
            text-align: center;
            padding: 20px;
            color: #888;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Mensajes de WhatsApp Extraídos</h1>
        <p style="text-align: center;">Informe generado el {now}</p>
        
        <div style="margin-top: 30px;">
"""
    
    if not messages:
        html += """
            <div class="no-messages">
                <p>No se encontraron mensajes en la base de datos.</p>
            </div>
"""
    else:
        html += f"""
            <p style="text-align: center;">Se encontraron {len(messages)} mensajes</p>
"""
        
        # Añade cada mensaje al HTML
        for message in messages:
            text = message.get("ZTEXT", "[Sin contenido de texto]")
            is_from_me = message.get("ZISFROMME", 0) == 1
            date = message.get("formatted_date", "Fecha desconocida")
            
            # Formato para el mensaje
            message_class = "from-me" if is_from_me else "from-other"
            sender = "Tú" if is_from_me else "Contacto"
            
            html += f"""
            <div class="message {message_class}">
                <div class="message-text">{text}</div>
                <div class="message-info">{sender} • {date}</div>
            </div>
            <div class="clear"></div>
"""
    
    # Cierra el documento HTML
    html += """
        </div>
    </div>
</body>
</html>"""

    try:
        # Asegura que el directorio de salida existe
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado correctamente: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def get_file_size(file_path):
    """Obtiene el tamaño del archivo en formato legible"""
    try:
        size_bytes = os.path.getsize(file_path)
        units = ['B', 'KB', 'MB', 'GB', 'TB']
        unit_index = 0
        while size_bytes >= 1024 and unit_index < len(units) - 1:
            size_bytes /= 1024
            unit_index += 1
        return f"{size_bytes:.2f} {units[unit_index]}"
    except Exception:
        return "Desconocido"

def list_all_tables_and_columns(conn):
    """Lista todas las tablas y sus columnas para diagnóstico"""
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in cursor.fetchall()]
        
        table_info = {}
        for table in tables:
            cursor.execute(f"PRAGMA table_info({table});")
            columns = [row["name"] for row in cursor.fetchall()]
            
            # Cuenta filas
            cursor.execute(f"SELECT COUNT(*) as count FROM {table};")
            row_count = cursor.fetchone()["count"]
            
            table_info[table] = {
                "columns": columns,
                "row_count": row_count
            }
        
        return table_info
    except sqlite3.Error as e:
        print(f"❌ Error al listar tablas y columnas: {e}")
        return {}

def check_table_for_text(conn, table_name, limit=5):
    """Revisa una tabla buscando columnas que puedan contener mensajes de texto"""
    try:
        cursor = conn.cursor()
        
        # Obtiene columnas
        cursor.execute(f"PRAGMA table_info({table_name});")
        columns = [row["name"] for row in cursor.fetchall()]
        
        text_like_columns = []
        
        # Busca columnas con nombres que sugieran texto
        text_keywords = ["TEXT", "CONTENT", "MESSAGE", "BODY", "DATA"]
        for column in columns:
            for keyword in text_keywords:
                if keyword in column.upper():
                    text_like_columns.append(column)
                    break
        
        if not text_like_columns:
            # Si no encuentra columnas con nombres sugestivos, busca columnas tipo TEXT
            cursor.execute(f"PRAGMA table_info({table_name});")
            for row in cursor.fetchall():
                if "TEXT" in row["type"].upper():
                    text_like_columns.append(row["name"])
        
        results = {}
        
        # Intenta obtener ejemplos de cada columna potencial
        for column in text_like_columns:
            try:
                cursor.execute(f"SELECT {column} FROM {table_name} WHERE {column} IS NOT NULL LIMIT ?", (limit,))
                examples = [row[0] for row in cursor.fetchall() if row[0]]
                if examples:
                    results[column] = examples
            except sqlite3.Error:
                pass  # Ignora errores por columnas incompatibles
        
        return results
    except sqlite3.Error as e:
        print(f"❌ Error al revisar tabla {table_name}: {e}")
        return {}

def find_message_tables(conn):
    """Busca todas las tablas que podrían contener mensajes"""
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in cursor.fetchall()]
        
        message_tables = {}
        
        for table in tables:
            # Busca tablas con nombres sugestivos primero
            keywords = ["MESSAGE", "CHAT", "TEXT", "CONVERSATION"]
            if any(keyword in table.upper() for keyword in keywords):
                results = check_table_for_text(conn, table)
                if results:
                    message_tables[table] = results
        
        # Si no encuentra nada, revisa todas las tablas
        if not message_tables:
            for table in tables:
                if table.startswith("sqlite_"):
                    continue  # Salta tablas del sistema
                results = check_table_for_text(conn, table)
                if results:
                    message_tables[table] = results
        
        return message_tables
    except sqlite3.Error as e:
        print(f"❌ Error al buscar tablas de mensajes: {e}")
        return {}

def export_messages_to_text(messages, output_path):
    """Exporta los mensajes a un archivo de texto simple"""
    try:
        with open(output_path, "w", encoding="utf-8") as f:
            for message in messages:
                text = message.get("ZTEXT", "[Sin contenido de texto]") 
                is_from_me = message.get("ZISFROMME", 0) == 1
                date = message.get("formatted_date", "Fecha desconocida")
                
                sender = "Tú" if is_from_me else "Contacto"
                f.write(f"[{date}] {sender}: {text}\n\n")
                
        print(f"✅ Mensajes exportados a texto: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error al exportar mensajes a texto: {e}")
        return False

def main():
    # Define las rutas
    script_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.dirname(script_dir)  # Directorio padre
    
    # Ruta de entrada con la ruta correcta especificada
    db_path = os.path.join(base_dir, "analyze/ios/private/var/mobile/Containers/Shared/AppGroup/BAF442BF-69A8-4336-86BC-37604B5C9A7C/ChatStorage.sqlite")
    
    # Rutas alternativas como respaldo
    possible_paths = [
        # Ruta principal corregida
        db_path,
        # Otras ubicaciones comunes
        os.path.join(base_dir, "ChatStorage.sqlite"),
        "./ChatStorage.sqlite",
        "./chat.db",
        "./msgstore.db"
    ]
    
    # Intenta con cada posible ruta
    found_db_path = None
    for path in possible_paths:
        if '*' in path:  # Si hay un patrón glob
            matching_files = list(Path(os.path.dirname(path.split('*')[0])).glob('**/ChatStorage.sqlite'))
            if matching_files:
                found_db_path = str(matching_files[0])
                break
        elif os.path.exists(path):
            found_db_path = path
            break
    
    # Permite especificar la ruta mediante argumento de línea de comandos
    import sys
    if len(sys.argv) > 1:
        custom_path = sys.argv[1]
        if os.path.exists(custom_path):
            found_db_path = custom_path
    
    if not found_db_path:
        print("❌ No se pudo encontrar la base de datos. Por favor especifica la ruta correcta.")
        print("   Uso: python script.py [ruta-a-la-base-de-datos]")
        return
    
    # Ruta de salida
    output_dir = os.path.join(base_dir, "results")
    os.makedirs(output_dir, exist_ok=True)
    output_html = os.path.join(output_dir, "IOS_whatsapp.html")
    output_txt = os.path.join(output_dir, "WhatsApp_Messages.txt")
    
    print(f"🔍 Analizando base de datos: {found_db_path}")
    print(f"   Tamaño: {get_file_size(found_db_path)}")
    
    # Conecta a la base de datos
    conn = connect_to_db(found_db_path)
    if not conn:
        print("❌ No se pudo conectar a la base de datos.")
        return
    
    # Modo diagnóstico: obtiene información sobre todas las tablas
    print("📊 Ejecutando diagnóstico de la base de datos...")
    table_info = list_all_tables_and_columns(conn)
    
    print(f"📋 Tablas encontradas: {len(table_info)}")
    for table, info in table_info.items():
        print(f"  • {table}: {info['row_count']} filas, {len(info['columns'])} columnas")
    
    # Busca tablas que puedan contener mensajes
    print("🔍 Buscando tablas con mensajes...")
    message_tables = find_message_tables(conn)
    
    if message_tables:
        print("✅ Tablas potenciales con mensajes encontradas:")
        for table, columns in message_tables.items():
            print(f"  • {table}")
            for column, examples in columns.items():
                print(f"    - {column}: {len(examples)} ejemplos encontrados")
                for i, example in enumerate(examples[:2]):  # Muestra solo dos ejemplos
                    if example and len(str(example)) > 5:  # Solo muestra textos razonables
                        print(f"      • Ejemplo {i+1}: {example[:50]}...")
    
    # Intenta extraer de ZWAMESSAGE
    print("\n🔍 Intentando extraer mensajes de la tabla ZWAMESSAGE...")
    messages = extract_messages_from_zwamessage(conn)
    
    # Si no hay mensajes, intenta buscar en otras tablas
    if not messages and message_tables:
        print("⚠️ No se encontraron mensajes en ZWAMESSAGE, intentando con otras tablas...")
        for table, columns in message_tables.items():
            for column in columns:
                print(f"  • Intentando extraer de {table}.{column}...")
                try:
                    cursor = conn.cursor()
                    cursor.execute(f"SELECT * FROM {table} WHERE {column} IS NOT NULL LIMIT 1000")
                    rows = cursor.fetchall()
                    
                    if rows:
                        print(f"    ✅ Se encontraron {len(rows)} filas con texto")
                        extracted_messages = []
                        for row in rows:
                            message_data = {}
                            for key in row.keys():
                                message_data[key] = row[key]
                            message_data["ZTEXT"] = row[column]  # Mapear a ZTEXT para compatibilidad
                            extracted_messages.append(message_data)
                        
                        messages = extracted_messages
                        break
                except sqlite3.Error:
                    pass
            
            if messages:
                break
    
    # Cierra la conexión
    conn.close()
    
    if messages:
        print(f"✅ Se encontraron {len(messages)} mensajes!")
        
        # Genera el informe HTML
        generate_html_report(messages, output_html)
        
        # Exporta mensajes a texto
        export_messages_to_text(messages, output_txt)
        
        print(f"\n✅ Análisis completo!")
        print(f"   • Informe HTML: {output_html}")
        print(f"   • Archivo de texto: {output_txt}")
    else:
        print("❌ No se encontraron mensajes en ninguna tabla.")

if __name__ == "__main__":
    main()