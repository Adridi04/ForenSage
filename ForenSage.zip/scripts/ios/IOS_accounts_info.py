import os
import plistlib
import datetime
import json
from pathlib import Path

def analizar_accounts_plist(ruta_archivo):
    """
    Analiza el archivo com.apple.accountsd.plist de iOS y extrae toda la información disponible.
    / Analyzes iOS com.apple.accountsd.plist file and extracts all available information.
    """
    datos = {}
    estructura = {}
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        return datos, estructura, file_exists
            
    try:
        # Leer el archivo plist / Read plist file
        with open(ruta_archivo, 'rb') as fp:
            pl = plistlib.load(fp)
        
        # Extraer toda la información disponible en el primer nivel
        # Extract all available information at the first level
        datos = pl
        
        # Crear una representación simplificada de la estructura para mostrar en el informe
        # Create a simplified representation of the structure to show in the report
        estructura = analizar_estructura(pl)
                
    except Exception as e:
        print(f"Error analizando {ruta_archivo}: {e}")
    
    return datos, estructura, file_exists

def analizar_estructura(data, nivel=0, max_nivel=3):
    """
    Analiza la estructura de los datos para mostrar en el informe
    / Analyzes data structure to show in the report
    """
    if nivel >= max_nivel:
        if isinstance(data, dict) and data:
            return {"tipo": "diccionario", "campos": len(data), "ejemplo": list(data.keys())[:5]}
        elif isinstance(data, list) and data:
            return {"tipo": "lista", "elementos": len(data), "ejemplo": data[:min(5, len(data))]}
        else:
            return {"tipo": type(data).__name__, "valor": str(data)[:100] if isinstance(data, str) else str(data)}
    
    if isinstance(data, dict):
        resultado = {}
        for key, value in data.items():
            resultado[key] = analizar_estructura(value, nivel + 1, max_nivel)
        return resultado
    elif isinstance(data, list):
        if not data:
            return {"tipo": "lista_vacia"}
        # Para listas, analizar el primer elemento como ejemplo
        if len(data) > 0:
            primer_elemento = analizar_estructura(data[0], nivel + 1, max_nivel)
            return {"tipo": "lista", "elementos": len(data), "ejemplo": primer_elemento}
        return {"tipo": "lista", "elementos": 0}
    else:
        return {"tipo": type(data).__name__, "valor": str(data)[:100] if isinstance(data, str) else str(data)}

def formatear_valor(valor, nivel=0):
    """
    Formatea un valor para su visualización en HTML
    / Formats a value for HTML display
    """
    if isinstance(valor, dict):
        resultado = "<div class='dict-value'>"
        for k, v in valor.items():
            resultado += f"<div class='dict-item' style='margin-left: {nivel * 20}px'>"
            resultado += f"<span class='dict-key'>{k}:</span> {formatear_valor(v, nivel + 1)}"
            resultado += "</div>"
        resultado += "</div>"
        return resultado
    elif isinstance(valor, list):
        if not valor:
            return "<span class='empty-list'>[Lista vacía / Empty list]</span>"
        resultado = "<div class='list-value'>"
        for i, item in enumerate(valor[:10]):  # Limitar a 10 elementos
            resultado += f"<div class='list-item' style='margin-left: {nivel * 20}px'>"
            resultado += f"<span class='list-index'>[{i}]</span> {formatear_valor(item, nivel + 1)}"
            resultado += "</div>"
        if len(valor) > 10:
            resultado += f"<div class='list-more' style='margin-left: {nivel * 20}px'>... ({len(valor) - 10} más / more)</div>"
        resultado += "</div>"
        return resultado
    elif isinstance(valor, (bool, int, float)):
        return f"<span class='primitive-value'>{str(valor)}</span>"
    elif valor is None:
        return "<span class='null-value'>None</span>"
    else:
        # Escapar HTML para valores de texto
        valor_str = str(valor)
        valor_str = valor_str.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return f"<span class='string-value'>\"{valor_str}\"</span>"

def generar_cards_recursivas(datos, nivel=0, max_nivel=3, prefijo=""):
    """
    Genera tarjetas HTML para mostrar los datos de forma recursiva
    / Generates HTML cards to display data recursively
    """
    html = ""
    
    if nivel >= max_nivel:
        return f"<div class='max-level-reached'>Nivel máximo alcanzado / Maximum level reached ({max_nivel})</div>"
    
    if isinstance(datos, dict):
        for key, value in datos.items():
            ruta_actual = f"{prefijo}.{key}" if prefijo else key
            
            if isinstance(value, dict) and value:
                html += f"""
                <div class="data-card dict-card">
                    <div class="card-header">
                        <h3 class="card-title">{key}</h3>
                        <div class="card-path">{ruta_actual}</div>
                    </div>
                    <div class="card-body">
                        {generar_cards_recursivas(value, nivel + 1, max_nivel, ruta_actual)}
                    </div>
                </div>"""
            elif isinstance(value, list) and value:
                html += f"""
                <div class="data-card list-card">
                    <div class="card-header">
                        <h3 class="card-title">{key} ({len(value)} elementos/items)</h3>
                        <div class="card-path">{ruta_actual}</div>
                    </div>
                    <div class="card-body">"""
                
                # Para listas, mostrar solo los primeros 5 elementos
                for i, item in enumerate(value[:5]):
                    if isinstance(item, dict):
                        html += f"""
                        <div class="list-item-container">
                            <div class="list-item-header">Elemento/Item #{i+1}</div>
                            <div class="list-item-content">
                                {generar_cards_recursivas(item, nivel + 1, max_nivel, f"{ruta_actual}[{i}]")}
                            </div>
                        </div>"""
                    else:
                        html += f"""
                        <div class="list-item-container">
                            <div class="list-item-header">Elemento/Item #{i+1}</div>
                            <div class="list-item-content">
                                <div class="simple-value">{formatear_valor(item)}</div>
                            </div>
                        </div>"""
                
                if len(value) > 5:
                    html += f"<div class='list-more-items'>... ({len(value) - 5} más / more)</div>"
                
                html += """
                    </div>
                </div>"""
            else:
                html += f"""
                <div class="data-card value-card">
                    <div class="card-header">
                        <h3 class="card-title">{key}</h3>
                        <div class="card-path">{ruta_actual}</div>
                    </div>
                    <div class="card-body">
                        <div class="simple-value">{formatear_valor(value)}</div>
                    </div>
                </div>"""
    
    return html

def generar_html_AccountsInfo(datos, estructura, archivo_info, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis del com.apple.accountsd.plist
    / Generates HTML report with com.apple.accountsd.plist analysis results
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception:
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())
    archivo_ruta, archivo_existe = archivo_info

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iOS Accounts | Cuentas iOS</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .info-section {{
            margin: 2rem 0;
        }}

        .section-title {{
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--accent);
        }}

        .data-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 12px;
            padding: 0;
            margin-bottom: 1.5rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            overflow: hidden;
        }}

        .data-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5);
        }}

        .card-header {{
            background-color: var(--primary-dark);
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}

        .card-title {{
            margin: 0;
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--accent-light);
        }}

        .card-path {{
            font-family: monospace;
            font-size: 0.8rem;
            color: var(--text-secondary);
        }}

        .card-body {{
            padding: 1.5rem;
        }}

        .dict-value, .list-value {{
            margin: 0.5rem 0;
        }}

        .dict-item, .list-item {{
            margin: 0.3rem 0;
        }}

        .dict-key {{
            color: var(--accent);
            font-weight: 600;
        }}

        .list-index {{
            color: var(--accent);
            font-weight: 600;
        }}

        .primitive-value {{
            color: var(--success);
        }}

        .string-value {{
            color: var(--warning);
        }}

        .null-value {{
            color: var(--danger);
        }}

        .empty-list {{
            color: var(--text-secondary);
            font-style: italic;
        }}

        .list-more, .list-more-items {{
            color: var(--text-secondary);
            font-style: italic;
            margin-top: 0.5rem;
        }}

        .max-level-reached {{
            color: var(--text-secondary);
            font-style: italic;
            padding: 0.5rem;
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 4px;
        }}

        .list-item-container {{
            background-color: var(--card-bg);
            border-radius: 8px;
            margin-bottom: 1rem;
            overflow: hidden;
        }}

        .list-item-header {{
            background-color: var(--primary-dark);
            padding: 0.5rem 1rem;
            font-weight: 600;
            color: var(--accent);
        }}

        .list-item-content {{
            padding: 1rem;
        }}

        .simple-value {{
            font-family: monospace;
            white-space: pre-wrap;
            word-break: break-word;
        }}

        .summary-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 2rem;
            margin: 2rem auto;
            max-width: 800px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }}

        .summary-title {{
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: var(--accent-light);
            text-align: center;
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .toggle-button {{
            background-color: var(--accent);
            color: var(--text);
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 0.5rem;
            transition: all 0.3s ease;
        }}

        .toggle-button:hover {{
            background-color: var(--accent-light);
        }}

        .raw-data {{
            display: none;
            background-color: var(--card-bg);
            padding: 1rem;
            border-radius: 8px;
            margin-top: 1rem;
            max-height: 500px;
            overflow: auto;
            font-family: monospace;
            white-space: pre-wrap;
            word-break: break-word;
        }}

        .source-container {{
            margin-top: 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }}

        .source-card {{
            background-color: var(--primary);
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }}

        .source-path {{
            font-family: monospace;
            color: var(--text);
        }}

        .source-status {{
            font-size: 0.9rem;
            padding: 0.3rem 0.8rem;
            border-radius: 12px;
        }}

        .source-found {{
            background-color: var(--success);
            color: var(--text);
        }}

        .source-not-found {{
            background-color: var(--danger);
            color: var(--text);
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .card-header {{
                flex-direction: column;
                align-items: flex-start;
            }}
            .card-path {{
                margin-top: 0.5rem;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">iOS Accounts | Cuentas iOS</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
        </div>"""

    # Información del archivo fuente
    status_class = "source-found" if archivo_existe else "source-not-found"
    status_text = "Encontrado | Found" if archivo_existe else "No encontrado | Not found"
    
    html += f"""
        <div class="source-container">
            <div class="source-card">
                <div class="source-path">{archivo_ruta}</div>
                <div class="source-status {status_class}">{status_text}</div>
            </div>
        </div>"""

    if not datos:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron datos | No data found</div>
            <p>No se ha podido extraer información del archivo com.apple.accountsd.plist. | Could not extract information from com.apple.accountsd.plist file.</p>
        </div>"""
    else:
        # Resumen de la estructura
        html += """
        <div class="summary-card">
            <div class="summary-title">Estructura de Datos | Data Structure</div>"""
        
        # Botón para mostrar datos crudos
        html += """
            <div style="text-align: center; margin-top: 1rem;">
                <button id="toggleRawData" class="toggle-button">Mostrar datos crudos | Show raw data</button>
            </div>
            <div id="rawData" class="raw-data"></div>
        """
        
        html += """
        </div>

        <div class="info-section">
            <h2 class="section-title">Contenido del Archivo | File Content</h2>"""
        
        # Generar tarjetas para cada elemento de nivel superior
        html += generar_cards_recursivas(datos)
        
        html += """
        </div>"""

    # Añadir footer
    html += f"""
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
        
        // Para mostrar/ocultar datos crudos
        const toggleButton = document.getElementById('toggleRawData');
        const rawData = document.getElementById('rawData');
        
        if (toggleButton && rawData) {{
            var isVisible = false;
            
            toggleButton.addEventListener('click', function() {{
                if (isVisible) {{
                    rawData.style.display = 'none';
                    toggleButton.textContent = 'Mostrar datos crudos | Show raw data';
                }} else {{
                    rawData.style.display = 'block';
                    toggleButton.textContent = 'Ocultar datos crudos | Hide raw data';
                }}
                isVisible = !isVisible;
            }});
            
            // Insertar datos crudos en formato texto
            rawData.textContent = '{{json_data_placeholder}}';
        }}
    </script>
</body>
</html>"""

    # Reemplazar el placeholder de los datos JSON
    json_data_str = json.dumps(datos, default=str, indent=2)
    json_data_str = json_data_str.replace("'", "\\'").replace('"', '\\"')
    html = html.replace("{json_data_placeholder}", json_data_str)

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Ruta del archivo a analizar (ruta relativa desde el directorio del script)
    base_path = Path.home() / "ForenSage"
    ruta_a_analizar = base_path / "analyze/ios/private/var/mobile/Library/Preferences/com.apple.accountsd.plist"
    
    # Para la salida, crear ruta relativa
    salida_html = base_path / "results/IOS_accounts_info.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar archivo
    datos, estructura, existe = analizar_accounts_plist(str(ruta_a_analizar))
    
    # Generar el informe HTML
    generar_html_AccountsInfo(datos, estructura, (str(ruta_a_analizar), existe), str(salida_html))

if __name__ == "__main__":
    main()