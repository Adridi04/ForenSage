import os
import sqlite3
import datetime
import json
from pathlib import Path

def analyze_addressbook_db(ruta_archivo):
    """
    Analiza un archivo de base de datos de contactos y extrae la información relevante.
    """
    resultados = {
        "contactos": [],
        "estadisticas": {
            "total_contactos": 0,
            "contactos_con_telefono": 0,
            "contactos_con_email": 0,
            "contactos_con_direccion": 0,
            "grupos": []
        },
        "metadata": {}
    }
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        return resultados, file_exists
            
    try:
        # Conectar a la base de datos
        conn = sqlite3.connect(ruta_archivo)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Obtener la lista de tablas
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = [row['name'] for row in cursor.fetchall()]
        resultados["metadata"]["tablas"] = tablas
        
        # Verificar si encontramos las tablas esperadas
        tablas_esperadas = ["ABPerson", "ABMultiValue", "ABGroup"]
        tablas_encontradas = [tabla for tabla in tablas_esperadas if tabla in tablas]
        
        if not tablas_encontradas:
            resultados["metadata"]["error"] = "No se encontraron tablas de contactos en la base de datos"
            return resultados, file_exists
        
        # Obtener estructura de las tablas
        estructura_tablas = {}
        for tabla in tablas_encontradas:
            cursor.execute(f"PRAGMA table_info({tabla});")
            estructura_tablas[tabla] = [row['name'] for row in cursor.fetchall()]
        
        resultados["metadata"]["estructura_tablas"] = estructura_tablas
        
        # Obtener grupos de contactos si la tabla existe
        grupos = {}
        if "ABGroup" in tablas:
            cursor.execute("SELECT ROWID, Name FROM ABGroup")
            for row in cursor.fetchall():
                grupos[row['ROWID']] = row['Name']
                resultados["estadisticas"]["grupos"].append({
                    "id": row['ROWID'],
                    "nombre": row['Name']
                })
        
        # Obtener la relación entre contactos y grupos
        contactos_grupos = {}
        if "ABGroupMembers" in tablas:
            cursor.execute("SELECT member_id, group_id FROM ABGroupMembers")
            for row in cursor.fetchall():
                if row['member_id'] not in contactos_grupos:
                    contactos_grupos[row['member_id']] = []
                if row['group_id'] in grupos:
                    contactos_grupos[row['member_id']].append(grupos[row['group_id']])
        
        # Procesar contactos
        if "ABPerson" in tablas:
            # Determinar qué columnas están disponibles
            columnas_persona = estructura_tablas.get("ABPerson", [])
            
            # Preparar la consulta SQL para obtener contactos
            select_cols = []
            if "ROWID" in columnas_persona:
                select_cols.append("ROWID")
            if "First" in columnas_persona:
                select_cols.append("First")
            if "Last" in columnas_persona:
                select_cols.append("Last")
            if "Organization" in columnas_persona:
                select_cols.append("Organization")
            if "Department" in columnas_persona:
                select_cols.append("Department")
            if "Note" in columnas_persona:
                select_cols.append("Note")
            if "Birthday" in columnas_persona:
                select_cols.append("Birthday")
            if "CreationDate" in columnas_persona:
                select_cols.append("CreationDate")
            if "ModificationDate" in columnas_persona:
                select_cols.append("ModificationDate")
            
            if not select_cols:
                resultados["metadata"]["error"] = "No se encontraron columnas relevantes en la tabla ABPerson"
                return resultados, file_exists
            
            # Ejecutar consulta para obtener contactos
            select_sql = f"SELECT {', '.join(select_cols)} FROM ABPerson"
            cursor.execute(select_sql)
            personas = cursor.fetchall()
            
            # Procesar MultiValue (teléfonos, emails, direcciones)
            multivalue_data = {}
            if "ABMultiValue" in tablas:
                cursor.execute("SELECT record_id, property, label, value FROM ABMultiValue")
                for row in cursor.fetchall():
                    if row['record_id'] not in multivalue_data:
                        multivalue_data[row['record_id']] = {
                            "phones": [],
                            "emails": [],
                            "addresses": []
                        }
                    
                    # Clasificar según el tipo de propiedad
                    if row['property'] == 3:  # Teléfono
                        multivalue_data[row['record_id']]["phones"].append({
                            "label": row['label'],
                            "value": row['value']
                        })
                    elif row['property'] == 4:  # Email
                        multivalue_data[row['record_id']]["emails"].append({
                            "label": row['label'],
                            "value": row['value']
                        })
                    elif row['property'] == 5:  # Dirección
                        multivalue_data[row['record_id']]["addresses"].append({
                            "label": row['label'],
                            "value": row['value']
                        })
            
            # Construir la lista de contactos
            for persona in personas:
                contacto = {}
                
                # ID del contacto
                if "ROWID" in persona.keys():
                    contacto["id"] = persona['ROWID']
                
                # Información básica
                if "First" in persona.keys():
                    contacto["nombre"] = persona['First'] or ""
                if "Last" in persona.keys():
                    contacto["apellido"] = persona['Last'] or ""
                if "Organization" in persona.keys():
                    contacto["organizacion"] = persona['Organization'] or ""
                if "Department" in persona.keys():
                    contacto["departamento"] = persona['Department'] or ""
                if "Note" in persona.keys():
                    contacto["nota"] = persona['Note'] or ""
                
                # Fechas
                if "Birthday" in persona.keys() and persona['Birthday']:
                    try:
                        fecha = datetime.datetime.fromtimestamp(persona['Birthday'] + 978307200)  # iOS timestamp
                        contacto["cumpleanos"] = fecha.strftime("%Y-%m-%d")
                    except:
                        contacto["cumpleanos"] = str(persona['Birthday'])
                
                if "CreationDate" in persona.keys() and persona['CreationDate']:
                    try:
                        fecha = datetime.datetime.fromtimestamp(persona['CreationDate'] + 978307200)
                        contacto["fecha_creacion"] = fecha.strftime("%Y-%m-%d %H:%M:%S")
                    except:
                        contacto["fecha_creacion"] = str(persona['CreationDate'])
                
                if "ModificationDate" in persona.keys() and persona['ModificationDate']:
                    try:
                        fecha = datetime.datetime.fromtimestamp(persona['ModificationDate'] + 978307200)
                        contacto["fecha_modificacion"] = fecha.strftime("%Y-%m-%d %H:%M:%S")
                    except:
                        contacto["fecha_modificacion"] = str(persona['ModificationDate'])
                
                # Información de MultiValue
                if "ROWID" in persona.keys() and persona['ROWID'] in multivalue_data:
                    mv_data = multivalue_data[persona['ROWID']]
                    
                    if mv_data["phones"]:
                        contacto["telefonos"] = mv_data["phones"]
                    
                    if mv_data["emails"]:
                        contacto["emails"] = mv_data["emails"]
                    
                    if mv_data["addresses"]:
                        contacto["direcciones"] = mv_data["addresses"]
                
                # Añadir grupos
                if "ROWID" in persona.keys() and persona['ROWID'] in contactos_grupos:
                    contacto["grupos"] = contactos_grupos[persona['ROWID']]
                
                # Añadir a la lista
                resultados["contactos"].append(contacto)
        
        # Actualizar estadísticas
        resultados["estadisticas"]["total_contactos"] = len(resultados["contactos"])
        resultados["estadisticas"]["contactos_con_telefono"] = sum(1 for c in resultados["contactos"] if "telefonos" in c)
        resultados["estadisticas"]["contactos_con_email"] = sum(1 for c in resultados["contactos"] if "emails" in c)
        resultados["estadisticas"]["contactos_con_direccion"] = sum(1 for c in resultados["contactos"] if "direcciones" in c)
        
        conn.close()
                
    except Exception as e:
        resultados["metadata"]["error"] = f"Error analizando {ruta_archivo}: {str(e)}"
    
    return resultados, file_exists

def generate_html_AddressBookAnalysis(datos, archivo_info, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis de la base de datos de contactos
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception:
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())
    archivo_ruta, archivo_existe = archivo_info

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de Contactos iOS | iOS Contacts Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .source-path {{
            font-family: monospace;
            color: var(--text);
        }}

        .source-status {{
            font-size: 0.9rem;
            padding: 0.3rem 0.8rem;
            border-radius: 12px;
        }}

        .source-found {{
            background-color: var(--success);
            color: var(--text);
        }}

        .source-not-found {{
            background-color: var(--danger);
            color: var(--text);
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        /* Estilos específicos para contactos */
        .contacts-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }}

        .contact-card {{
            background-color: var(--card-bg);
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .contact-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
        }}

        .contact-name {{
            font-size: 1.4rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--accent);
        }}

        .contact-organization {{
            font-size: 1rem;
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }}

        .contact-info-section {{
            margin-top: 1rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .contact-info-title {{
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--accent-light);
            margin-bottom: 0.5rem;
        }}

        .contact-info-item {{
            padding: 0.5rem;
            background-color: rgba(255, 255, 255, 0.05);
            border-radius: 5px;
            margin-bottom: 0.5rem;
            font-family: 'Open Sans', sans-serif;
        }}

        .contact-info-label {{
            font-size: 0.8rem;
            color: var(--text-secondary);
        }}

        .contact-info-value {{
            font-weight: 600;
        }}

        .date-info {{
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-top: 1rem;
        }}

        .stats-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
        }}

        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 1rem;
            margin-top: 1.5rem;
        }}

        .stat-item {{
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1rem;
        }}

        .stat-value {{
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent);
        }}

        .stat-label {{
            font-size: 0.8rem;
            color: var(--text-secondary);
        }}

        .group-badge {{
            display: inline-block;
            background-color: rgba(52, 152, 219, 0.2);
            border-radius: 15px;
            padding: 0.3rem 0.8rem;
            margin: 0.2rem;
            font-size: 0.8rem;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .contacts-grid {{
                grid-template-columns: 1fr;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Análisis de Contactos iOS | iOS Contacts Analysis</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
            <p class="subtitle">📁 Ruta del archivo: <code>{archivo_ruta}</code> - <span class="source-status {'source-found' if archivo_existe else 'source-not-found'}">{("Encontrado | Found" if archivo_existe else "No encontrado | Not found")}</span></p>
        </div>"""

    if not datos or not datos.get("contactos"):
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron contactos | No contacts found</div>
            <p>No se ha podido extraer información de la base de datos de contactos. | Could not extract information from the contacts database file.</p>
        </div>"""
        
        # Si hay metadatos con errores, mostrarlos
        if datos and "metadata" in datos and "error" in datos["metadata"]:
            html += f"""
            <div class="warning-card">
                <div class="warning-title">⚠️ Error de análisis | Analysis Error</div>
                <p>{datos["metadata"]["error"]}</p>
            </div>"""
    else:
        # Mostrar información de resumen
        estadisticas = datos.get("estadisticas", {})
        html += f"""
        <div class="stats-card">
            <h2>Resumen de Contactos | Contacts Summary</h2>
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-value">{estadisticas.get("total_contactos", 0)}</div>
                    <div class="stat-label">Total Contactos</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">{estadisticas.get("contactos_con_telefono", 0)}</div>
                    <div class="stat-label">Con Teléfono</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">{estadisticas.get("contactos_con_email", 0)}</div>
                    <div class="stat-label">Con Email</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">{estadisticas.get("contactos_con_direccion", 0)}</div>
                    <div class="stat-label">Con Dirección</div>
                </div>
            </div>
        </div>"""

        # Mostrar grupos si existen
        if estadisticas.get("grupos"):
            html += """
        <div class="stats-card">
            <h2>Grupos de Contactos | Contact Groups</h2>"""
            
            for grupo in estadisticas.get("grupos", []):
                html += f"""
            <span class="group-badge">{grupo.get("nombre", "Sin nombre")}</span>"""
            
            html += """
        </div>"""

        # Mostrar los contactos
        html += """
        <h2 style="text-align: center; margin-top: 3rem;">Contactos Recuperados | Recovered Contacts</h2>
        <div class="contacts-grid">"""
        
        for contacto in datos["contactos"]:
            nombre = contacto.get("nombre", "")
            apellido = contacto.get("apellido", "")
            nombre_completo = f"{nombre} {apellido}".strip()
            if not nombre_completo:
                nombre_completo = "Sin nombre"
            
            organizacion = contacto.get("organizacion", "")
            departamento = contacto.get("departamento", "")
            org_dept = ""
            if organizacion:
                org_dept = organizacion
                if departamento:
                    org_dept += f", {departamento}"
            
            # Fecha de creación y modificación
            fecha_creacion = contacto.get("fecha_creacion", "")
            fecha_modificacion = contacto.get("fecha_modificacion", "")
            
            # Grupos
            grupos_html = ""
            if "grupos" in contacto and contacto["grupos"]:
                grupos_html += """
                <div class="contact-info-section">
                    <div class="contact-info-title">Grupos</div>"""
                for grupo in contacto["grupos"]:
                    grupos_html += f"""
                    <span class="group-badge">{grupo}</span>"""
                grupos_html += """
                </div>"""
            
            # Teléfonos
            telefonos_html = ""
            if "telefonos" in contacto and contacto["telefonos"]:
                telefonos_html += """
                <div class="contact-info-section">
                    <div class="contact-info-title">Teléfonos</div>"""
                for telefono in contacto["telefonos"]:
                    label = telefono.get("label", "")
                    value = telefono.get("value", "")
                    telefonos_html += f"""
                    <div class="contact-info-item">
                        <div class="contact-info-label">{label}</div>
                        <div class="contact-info-value">{value}</div>
                    </div>"""
                telefonos_html += """
                </div>"""
            
            # Emails
            emails_html = ""
            if "emails" in contacto and contacto["emails"]:
                emails_html += """
                <div class="contact-info-section">
                    <div class="contact-info-title">Emails</div>"""
                for email in contacto["emails"]:
                    label = email.get("label", "")
                    value = email.get("value", "")
                    emails_html += f"""
                    <div class="contact-info-item">
                        <div class="contact-info-label">{label}</div>
                        <div class="contact-info-value">{value}</div>
                    </div>"""
                emails_html += """
                </div>"""
            
            # Direcciones
            direcciones_html = ""
            if "direcciones" in contacto and contacto["direcciones"]:
                direcciones_html += """
                <div class="contact-info-section">
                    <div class="contact-info-title">Direcciones</div>"""
                for direccion in contacto["direcciones"]:
                    label = direccion.get("label", "")
                    value = direccion.get("value", "")
                    direcciones_html += f"""
                    <div class="contact-info-item">
                        <div class="contact-info-label">{label}</div>
                        <div class="contact-info-value">{value}</div>
                    </div>"""
                direcciones_html += """
                </div>"""
            
            # Notas
            notas_html = ""
            if "nota" in contacto and contacto["nota"]:
                notas_html += f"""
                <div class="contact-info-section">
                    <div class="contact-info-title">Notas</div>
                    <div class="contact-info-item">
                        <div class="contact-info-value">{contacto["nota"]}</div>
                    </div>
                </div>"""
            
            # Fecha de cumpleaños
            cumpleanos_html = ""
            if "cumpleanos" in contacto and contacto["cumpleanos"]:
                cumpleanos_html += f"""
                <div class="contact-info-section">
                    <div class="contact-info-title">Cumpleaños</div>
                    <div class="contact-info-item">
                        <div class="contact-info-value">{contacto["cumpleanos"]}</div>
                    </div>
                </div>"""
            
            html += f"""
            <div class="contact-card">
                <div class="contact-name">{nombre_completo}</div>
                <div class="contact-organization">{org_dept}</div>
                {grupos_html}
                {telefonos_html}
                {emails_html}
                {direcciones_html}
                {cumpleanos_html}
                {notas_html}
                <div class="date-info">
                    {f"Creado: {fecha_creacion}" if fecha_creacion else ""}
                    {f"<br>Modificado: {fecha_modificacion}" if fecha_modificacion else ""}
                </div>
            </div>"""
        
        html += """
        </div>"""

    # Pie de página
    html += """
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Ruta del archivo a analizar (según el path proporcionado)
    ruta_a_analizar = "~/ForenSage/analyze/ios/private/var/mobile/Library/AddressBook/AddressBook.sqlitedb"
    # Expandir el home directory (~)
    ruta_a_analizar = os.path.expanduser(ruta_a_analizar)
    
    # Para la salida, crear ruta relativa
    base_path = Path.home() / "ForenSage"
    salida_html = base_path / "results/IOS_contactas_info.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar archivo
    datos, existe = analyze_addressbook_db(ruta_a_analizar)
    
    # Generar el informe HTML
    generate_html_AddressBookAnalysis(datos, (ruta_a_analizar, existe), str(salida_html))

if __name__ == "__main__":
    main()