#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sqlite3
from pathlib import Path
import html
from datetime import datetime
import os
import math

# Configuración de rutas | Path configuration
BASE_DIR = Path(".")
DB_REL_PATH = "analyze/android/data/data/com.android.providers.contacts/databases/calllog.db"
OUTPUT_DIR = BASE_DIR / "results"
OUTPUT_HTML = OUTPUT_DIR / "and_calllog_info.html"  

def obtener_datos_llamadas(db_path):
    """Obtiene datos de registros de llamadas de la base de datos
    Retrieves call logs data from the database"""
    if not db_path.exists():
        print(f"Error: No se encontró la base de datos en {db_path}")
        return None

    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Detectar tabla principal de registros de llamadas
        # Detect main call logs table
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = [tabla[0] for tabla in cursor.fetchall()]
        
        # Posibles nombres de tabla para registros de llamadas
        # Possible table names for call logs
        posibles_tablas = ['calls', 'call_log', 'calllog', 'logs', 'callhistory']
        tabla_llamadas = None
        
        for tabla in tablas:
            if tabla.lower() in posibles_tablas or 'call' in tabla.lower():
                tabla_llamadas = tabla
                break
        
        if not tabla_llamadas:
            tabla_llamadas = tablas[0]  # Tomar la primera tabla si no se encuentra una específica
        
        cursor.execute(f"PRAGMA table_info({tabla_llamadas});")
        columnas = [col[1] for col in cursor.fetchall()]
        
        campos = {
            'number': next((c for c in columnas if 'number' in c.lower() or 'phone' in c.lower()), None),
            'name': next((c for c in columnas if 'name' in c.lower() or 'contact' in c.lower()), None),
            'date': next((c for c in columnas if 'date' in c.lower() or 'time' in c.lower()), None),
            'duration': next((c for c in columnas if 'duration' in c.lower()), None),
            'type': next((c for c in columnas if 'type' in c.lower()), None),
            'new': next((c for c in columnas if 'new' in c.lower() or 'read' in c.lower()), None),
            'geocoded_location': next((c for c in columnas if 'geo' in c.lower() or 'location' in c.lower()), None)
        }
        
        # Construir consulta con los campos encontrados
        # Build query with the found fields
        campos_seleccionados = [v for v in campos.values() if v]
        
        if not campos_seleccionados:
            # Si no se detectó ningún campo específico, seleccionar todos
            # If no specific field was detected, select all
            query = f"SELECT * FROM {tabla_llamadas}"
            cursor.execute(query)
            # Usar nombres de columnas como están
            campos_seleccionados = [description[0] for description in cursor.description]

            for i, campo in enumerate(campos_seleccionados):
                campo_lower = campo.lower()
                if 'number' in campo_lower or 'phone' in campo_lower:
                    campos['number'] = campo
                elif 'name' in campo_lower or 'contact' in campo_lower:
                    campos['name'] = campo
                elif 'date' in campo_lower or 'time' in campo_lower:
                    campos['date'] = campo
                elif 'duration' in campo_lower:
                    campos['duration'] = campo
                elif 'type' in campo_lower:
                    campos['type'] = campo
                elif 'new' in campo_lower or 'read' in campo_lower:
                    campos['new'] = campo
                elif 'geo' in campo_lower or 'location' in campo_lower:
                    campos['geocoded_location'] = campo
        else:
            query = f"SELECT {', '.join(campos_seleccionados)} FROM {tabla_llamadas}"
            cursor.execute(query)
        
        llamadas_data = cursor.fetchall()
        
        cursor.execute(f"SELECT COUNT(*) FROM {tabla_llamadas}")
        total_llamadas = cursor.fetchone()[0]
        
        tipo_llamadas = {'entrantes': 0, 'salientes': 0, 'perdidas': 0}
        if campos['type']:

            try:
                cursor.execute(f"SELECT COUNT(*) FROM {tabla_llamadas} WHERE {campos['type']} IN (1, 2)")
                tipo_llamadas['entrantes'] = cursor.fetchone()[0]
                
                cursor.execute(f"SELECT COUNT(*) FROM {tabla_llamadas} WHERE {campos['type']} = 3")
                tipo_llamadas['salientes'] = cursor.fetchone()[0]
                
                cursor.execute(f"SELECT COUNT(*) FROM {tabla_llamadas} WHERE {campos['type']} IN (5)")
                tipo_llamadas['perdidas'] = cursor.fetchone()[0]
            except:
                pass
        
        return {
            'fields': campos_seleccionados,
            'data': llamadas_data,
            'mapping': campos,
            'table': tabla_llamadas,
            'stats': {
                'total': total_llamadas,
                'tipos': tipo_llamadas
            }
        }
        
    except sqlite3.Error as e:
        print(f"Error SQLite: {e}")
        return None
    finally:
        if 'conn' in locals():
            conn.close()

def generar_html_calllog(datos):
    """Genera un informe HTML con diseño creativo de tarjetas
    Generates an HTML report with creative card design"""
    if not datos:
        return "<html><body><h1>No se encontraron datos</h1></body></html>"
    
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    llamadas = datos['data']
    campos = datos['fields']
    mapeo = datos['mapping']
    estadisticas = datos['stats']
    
    color_principal = "#9b59b6"  
    
    html_content = f"""
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Call Logs | Registros de Llamadas</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Poppins:wght@300;500&display=swap" rel="stylesheet">
    <style>
        :root {{
            --bg-dark: #1a1a2e;
            --bg-card: #16213e;
            --text-light: #ecf0f1;
            --text-muted: #bdc3c7;
            --accent: {color_principal};
            --card-border: {color_principal};
        }}
        
        body {{
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-light);
            margin: 0;
            padding: 20px;
            line-height: 1.6;
        }}
        
        .header {{
            text-align: center;
            margin-bottom: 40px;
            padding: 30px 0;
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.3);
        }}
        
        .report-date {{
            font-size: 1rem;
            color: var(--text-muted);
            margin-top: 15px;
            text-align: center;
        }}
        
        h1 {{
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 2.5rem;
            margin: 0;
            background: linear-gradient(to right, {color_principal}, #8e44ad);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}
        
        .subtitle {{
            font-size: 1.1rem;
            color: var(--text-muted);
            margin-top: 10px;
        }}
        
        .stats {{
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 40px;
        }}
        
        .stat-card {{
            background: rgba(255,255,255,0.1);
            border-radius: 12px;
            padding: 20px;
            min-width: 150px;
            text-align: center;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255,255,255,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }}
        
        .stat-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
        }}
        
        .stat-value {{
            font-size: 2.2rem;
            font-weight: 700;
            margin: 10px 0;
            background: linear-gradient(to right, {color_principal}, #8e44ad);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}
        
        .stat-label {{
            font-size: 0.9rem;
            color: var(--text-muted);
            text-transform: |uppercase;
            letter-spacing: 1px;
        }}
        
        .calls-grid {{
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
            margin: 0 auto;
            max-width: 1400px;
        }}
        
        .call-card {{
            background: var(--bg-card);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            border-top: 3px solid var(--card-border);
        }}
        
        .call-card:hover {{
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.3);
        }}
        
        .call-card::before {{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        }}
        
        .call-title {{
            font-family: 'Montserrat', sans-serif;
            font-size: 1.4rem;
            font-weight: 600;
            margin: 0 0 10px 0;
            color: white;
            display: flex;
            align-items: center;
        }}
        
        .call-number {{
            font-family: monospace;
            font-size: 0.9rem;
            color: var(--accent);
            margin-bottom: 15px;
            display: inline-block;
            background: rgba(155, 89, 182, 0.1);
            padding: 3px 8px;
            border-radius: 4px;
        }}
        
        .call-details {{
            margin-top: 15px;
        }}
        
        .detail-item {{
            display: flex;
            margin-bottom: 8px;
            align-items: center;
        }}
        
        .detail-icon {{
            width: 24px;
            height: 24px;
            margin-right: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
        }}
        
        .detail-label {{
            font-weight: 500;
            min-width: 100px;
            color: var(--text-muted);
        }}
        
        .detail-value {{
            font-weight: 400;
        }}
        
        .call-type-badge {{
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            margin-left: 10px;
            background: rgba(155, 89, 182, 0.2);
            color: #9b59b6;
        }}
        
        .call-type-incoming {{
            background: rgba(46, 204, 113, 0.2);
            color: #2ecc71;
        }}
        
        .call-type-outgoing {{
            background: rgba(52, 152, 219, 0.2);
            color: #3498db;
        }}
        
        .call-type-missed {{
            background: rgba(231, 76, 60, 0.2);
            color: #e74c3c;
        }}
        
        .footer {{
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            color: var(--text-muted);
            font-size: 0.9rem;
        }}
        
        /* Efecto de burbujas flotantes | Floating bubbles effect */
        .bubble {{
            position: absolute;
            border-radius: 50%;
            background: rgba(255,255,255,0.05);
            z-index: -1;
        }}
        
        /* Animaciones | Animations */
        @keyframes float {{
            0%, 100% {{ transform: translateY(0); }}
            50% {{ transform: translateY(-10px); }}
        }}
        
        .call-card:hover {{
            animation: float 3s ease-in-out infinite;
        }}
        
        /* Media queries para dispositivos móviles | Media queries for mobile devices */
        @media (max-width: 768px) {{
            .calls-grid {{
                grid-template-columns: 1fr;
            }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Call Logs | Registros de Llamadas</h1>
        <div class="subtitle">Análisis forense de registros de llamadas de Android</div>
        <div class="report-date">Generado el: {now}</div>
    </div>
    
    <div class="stats">
        <div class="stat-card">
            <div class="stat-value">{estadisticas['total']}</div>
            <div class="stat-label">Total Llamadas</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">{estadisticas['tipos']['entrantes']}</div>
            <div class="stat-label">Entrantes</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">{estadisticas['tipos']['salientes']}</div>
            <div class="stat-label">Salientes</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">{estadisticas['tipos']['perdidas']}</div>
            <div class="stat-label">Perdidas</div>
        </div>
    </div>
    
    <div class="calls-grid">
"""

    # Generar tarjetas para cada llamada | Generate cards for each call
    for i, llamada in enumerate(llamadas):
        # Obtener valores de cada campo | Get values for each field
        call_data = {}
        for field in campos:
            idx = campos.index(field)
            call_data[field] = llamada[idx] if idx < len(llamada) else None
        
        # Formatear valores especiales | Format special values
        call_date = ""
        if mapeo['date'] and mapeo['date'] in campos and call_data.get(mapeo['date']):
            try:
                # Convertir timestamp a fecha | Convert timestamp to date
                ts = int(call_data[mapeo['date']])/1000
                call_date = datetime.fromtimestamp(ts).strftime('%d/%m/%Y %H:%M')
            except:
                call_date = str(call_data[mapeo['date']])
        
        call_duration = ""
        if mapeo['duration'] and mapeo['duration'] in campos and call_data.get(mapeo['duration']):
            try:
                duration_sec = int(call_data[mapeo['duration']])
                minutos = duration_sec // 60
                segundos = duration_sec % 60
                call_duration = f"{minutos}:{segundos:02d}"
            except:
                call_duration = str(call_data[mapeo['duration']])
        
        call_type = ""
        call_type_class = ""
        if mapeo['type'] and mapeo['type'] in campos and call_data.get(mapeo['type']) is not None:
            tipo_num = int(call_data[mapeo['type']])
            if tipo_num in [1, 2]:  #llamadas entrantes
                call_type = "Entrante"
                call_type_class = "call-type-incoming"
            elif tipo_num == 3:  #llamadas salientes
                call_type = "Saliente"
                call_type_class = "call-type-outgoing"
            elif tipo_num == 5:  #llamadas perdidas
                call_type = "Perdida"
                call_type_class = "call-type-missed"
            else:
                call_type = f"Tipo {tipo_num}"
        
        # Valores para la plantilla | Values for the template
        call_name = html.escape(str(call_data.get(mapeo['name'], 'Desconocido') if mapeo['name'] in campos else 'Desconocido'))
        call_number = html.escape(str(call_data.get(mapeo['number'], 'Sin número') if mapeo['number'] in campos else 'Sin número'))
        call_location = html.escape(str(call_data.get(mapeo['geocoded_location'], '') if mapeo['geocoded_location'] in campos else ''))
        
        # Generar HTML de la tarjeta | Generate HTML for the card
        html_content += f"""
        <div class="call-card">
            <h2 class="call-title">
                {call_name}
                {f'<span class="call-type-badge {call_type_class}">{call_type}</span>' if call_type else ''}
            </h2>
            <div class="call-number">{call_number}</div>
            
            <div class="call-details">
                {f'<div class="detail-item"><span class="detail-icon">📅</span><span class="detail-label">Fecha:</span> <span class="detail-value">{call_date}</span></div>' if call_date else ''}
                
                {f'<div class="detail-item"><span class="detail-icon">⏱️</span><span class="detail-label">Duración:</span> <span class="detail-value">{call_duration}</span></div>' if call_duration else ''}
                
                {f'<div class="detail-item"><span class="detail-icon">📍</span><span class="detail-label">Ubicación:</span> <span class="detail-value">{call_location}</span></div>' if call_location else ''}
            </div>
            
            <!-- Burbujas decorativas | Decorative bubbles -->
            <div class="bubble" style="width: 80px; height: 80px; top: -30px; right: -30px; background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);"></div>
            <div class="bubble" style="width: 40px; height: 40px; bottom: 20px; left: -15px; background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);"></div>
        </div>
        """

    html_content += f"""
    </div>
    
    <footer class="footer">
        <p> ForenSage © 2025 - Forensic Tool</p>
    </footer>
    
    <script>
        // Agregar efecto de movimiento a las burbujas | Add movement effect to bubbles
        document.querySelectorAll('.bubble').forEach((bubble, index) => {{
            // Posiciones y tamaños aleatorios | Random positions and sizes
            const size = Math.random() * 50 + 30;
            const posX = Math.random() * 100;
            const posY = Math.random() * 100;
            
            bubble.style.width = `${{size}}px`;
            bubble.style.height = `${{size}}px`;
            bubble.style.left = `${{posX}}%`;
            bubble.style.top = `${{posY}}%`;
            
            // Animación única para cada burbuja | Unique animation for each bubble
            bubble.style.animation = `float ${{Math.random() * 5 + 3}}s ease-in-out infinite ${{Math.random() * 2}}s`;
        }});
    </script>
</body>
</html>
"""
    
    return html_content

def main():

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    db_path = BASE_DIR / DB_REL_PATH
    
    # Obtener datos de registros de llamadas
    # Get call logs data
    datos_llamadas = obtener_datos_llamadas(db_path)
    
    if datos_llamadas:
        print(f"Se encontraron {len(datos_llamadas['data'])} registros de llamadas")
        html_content = generar_html_calllog(datos_llamadas)
        
        # Guardar el informe
        # Save the report
        with open(OUTPUT_HTML, 'w', encoding='utf-8') as f:
            f.write(html_content)
        print(f"Informe creativo generado en: {OUTPUT_HTML}")
    else:
        print("No se pudieron obtener datos de registros de llamadas")

if __name__ == "__main__":
    main()