import os
import sqlite3
import datetime
from pathlib import Path

def analizar_historial_chrome(ruta_archivo):
    """
    Analiza el archivo de historial de Chrome (SQLite) y extrae las visitas web.
    / Analyzes Chrome history file (SQLite) and extracts web visits.
    """
    resultados = []
    
    try:
        # Verificar si el archivo existe
        if not os.path.exists(ruta_archivo):
            print(f"❌ Archivo no encontrado: {ruta_archivo} | File not found: {ruta_archivo}")
            return resultados
            
        # Conectar a la base de datos SQLite
        conexion = sqlite3.connect(f"file:{ruta_archivo}?mode=ro", uri=True)
        cursor = conexion.cursor()
        
        # Consulta para obtener el historial de navegación
        cursor.execute("""
            SELECT
                urls.url,
                urls.title,
                urls.visit_count,
                datetime(urls.last_visit_time/1000000-11644473600, 'unixepoch', 'localtime') as last_visit,
                datetime(visits.visit_time/1000000-11644473600, 'unixepoch', 'localtime') as visit_time,
                CASE visits.transition & 0xFF
                    WHEN 0 THEN 'Enlace'
                    WHEN 1 THEN 'Escrito'
                    WHEN 2 THEN 'Auto Subframe'
                    WHEN 3 THEN 'Manual Subframe'
                    WHEN 4 THEN 'Generado'
                    WHEN 5 THEN 'Auto Marcador'
                    WHEN 6 THEN 'Manual Marcador'
                    WHEN 7 THEN 'Descarga'
                    WHEN 8 THEN 'Recarga'  
                    WHEN 9 THEN 'Prefijo'
                    ELSE 'Desconocido'
                END as transition_type
            FROM urls
            LEFT JOIN visits ON urls.id = visits.url
            ORDER BY visits.visit_time DESC
            LIMIT 1000
        """)
        
        # Procesar los resultados
        for fila in cursor.fetchall():
            url, titulo, visitas, ultima_visita, tiempo_visita, tipo_transicion = fila
            
            resultados.append({
                'url': url or 'No disponible',
                'titulo': titulo or 'Sin título',
                'visitas': visitas or 0,
                'ultima_visita': ultima_visita or 'Desconocido',
                'tiempo_visita': tiempo_visita or 'Desconocido',
                'tipo_transicion': tipo_transicion or 'Desconocido'
            })
            
        conexion.close()
        
    except sqlite3.Error as e:
        print(f"❌ Error de base de datos SQLite: {e} | SQLite database error: {e}")
    except Exception as e:
        print(f"❌ Error inesperado: {e} | Unexpected error: {e}")
    
    return resultados

def generar_html_browserhistory(resultados, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis del historial en estilo buscador
    / Generates HTML report with Chrome history analysis results in search engine style
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception as e:
            print(f"❌ Error creando carpeta: {e} | Error creating folder: {e}")
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chrome History Report | Informe Historial Chrome</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .stats-container {{
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 2rem;
        }}

        .stat-card {{
            background-color: var(--primary);
            border-radius: 8px;
            padding: 1rem;
            flex: 1 1 200px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }}

        .stat-title {{
            font-size: 0.9rem;
            color: var(--text-secondary);
        }}

        .stat-value {{
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0.5rem 0;
            color: var(--accent-light);
        }}

        .search-container {{
            margin-bottom: 2rem;
        }}

        .search-box {{
            width: 100%;
            padding: 1rem;
            border: 1px solid var(--primary-light);
            border-radius: 8px;
            background-color: var(--card-bg);
            color: var(--text);
            font-family: 'Montserrat', sans-serif;
            font-size: 1rem;
        }}

        .results-container {{
            margin-top: 2rem;
        }}

        .result-card {{
            background-color: var(--card-bg);
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            transition: transform 0.2s ease;
        }}

        .result-card:hover {{
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.4);
        }}

        .result-title {{
            color: var(--accent-light);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }}

        .result-url {{
            color: var(--text-secondary);
            font-size: 0.9rem;
            margin-bottom: 1rem;
            word-break: break-all;
            font-family: monospace;
            padding: 0.5rem;
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 4px;
        }}

        .result-meta {{
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            font-size: 0.85rem;
        }}

        .result-meta-item {{
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }}

        .pagination {{
            display: flex;
            justify-content: center;
            margin-top: 2rem;
            gap: 0.5rem;
        }}

        .page-btn {{
            background-color: var(--primary);
            color: var(--text);
            border: none;
            border-radius: 4px;
            padding: 0.5rem 1rem;
            cursor: pointer;
            transition: background-color 0.2s;
        }}

        .page-btn:hover, .page-btn.active {{
            background-color: var(--accent);
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .lang-toggle {{
            background-color: var(--card-bg);
            color: var(--text);
            border: 1px solid var(--primary-light);
            border-radius: 20px;
            padding: 0.5rem 1rem;
            cursor: pointer;
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-left: 1rem;
        }}

        .lang-toggle:hover {{
            border-color: var(--accent);
            transform: translateY(-2px);
        }}

        .hidden {{
            display: none;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Chrome History Report | Informe Historial Chrome</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
            <button class="lang-toggle" onclick="toggleLanguage()">EN/ES</button>
        </div>
        
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-title">Total Entradas | Total Entries</div>
                <div class="stat-value">{len(resultados)}</div>
            </div>
            <div class="stat-card">
                <div class="stat-title">Última Actividad | Last Activity</div>
                <div class="stat-value">{resultados[0]['ultima_visita'].split()[0] if resultados else 'N/A'}</div>
            </div>
        </div>
        
        <div class="search-container">
            <input type="text" id="searchInput" class="search-box" placeholder="🔍 Buscar en el historial... | Search history...">
        </div>
        
        <div class="results-container" id="resultsContainer">"""

    for item in resultados:
        html += f"""
            <div class="result-card">
                <div class="result-title">{item['titulo']}</div>
                <div class="result-url">{item['url']}</div>
                <div class="result-meta">
                    <div class="result-meta-item">
                        <span>🕒</span> {item['tiempo_visita']}
                    </div>
                    <div class="result-meta-item">
                        <span>👁️</span> {item['visitas']} visitas
                    </div>
                    <div class="result-meta-item">
                        <span>⚙️</span> {item['tipo_transicion']}
                    </div>
                </div>
            </div>"""

    html += """
        </div>
        
        <div class="pagination" id="pagination">
            <!-- Pagination will be generated by JavaScript -->
        </div>
        
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
        
        // Setup pagination
        const resultsPerPage = 10;
        const results = document.querySelectorAll('.result-card');
        const paginationContainer = document.getElementById('pagination');
        const totalPages = Math.ceil(results.length / resultsPerPage);
        
        function showPage(pageNum) {
            const start = (pageNum - 1) * resultsPerPage;
            const end = start + resultsPerPage;
            
            results.forEach((result, index) => {
                if (index >= start && index < end) {
                    result.classList.remove('hidden');
                } else {
                    result.classList.add('hidden');
                }
            });
            
            // Update active page button
            document.querySelectorAll('.page-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            document.querySelector(`.page-btn[data-page="${pageNum}"]`)?.classList.add('active');
        }
        
        function setupPagination() {
            paginationContainer.innerHTML = '';
            
            for (let i = 1; i <= totalPages; i++) {
                const btn = document.createElement('button');
                btn.classList.add('page-btn');
                btn.setAttribute('data-page', i);
                btn.textContent = i;
                btn.addEventListener('click', () => showPage(i));
                paginationContainer.appendChild(btn);
            }
        }
        
        function filterResults() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            let visibleCount = 0;
            
            results.forEach(result => {
                const title = result.querySelector('.result-title').textContent.toLowerCase();
                const url = result.querySelector('.result-url').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || url.includes(searchTerm)) {
                    result.classList.remove('hidden');
                    visibleCount++;
                } else {
                    result.classList.add('hidden');
                }
            });
            
            // Hide pagination when filtering
            if (searchTerm) {
                paginationContainer.classList.add('hidden');
            } else {
                paginationContainer.classList.remove('hidden');
                setupPagination();
                showPage(1);
            }
        }
        
        // Real-time search
        document.getElementById('searchInput').addEventListener('keyup', filterResults);
        
        // Initialize
        setupPagination();
        showPage(1);
        
        function toggleLanguage() {
            document.querySelectorAll('[lang="es"]').forEach(el => {
                el.style.display = el.style.display === 'none' ? 'block' : 'none';
            });
            document.querySelectorAll('[lang="en"]').forEach(el => {
                el.style.display = el.style.display === 'none' ? 'block' : 'none';
            });
        }
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida} | Report generated at: {ruta_salida}")
    except Exception as e:
        print(f"❌ Error guardando HTML: {e} | Error saving HTML: {e}")

def main():
    # Definir rutas
    BASE_DIR = Path(".")
    ruta_historial = "analyze/android/data/data/com.android.chrome/app_chrome/Default/History"
    base_path = Path.home() / "ForenSage" / "results"
    salida_html = base_path / "and_browserhistoy_info.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar el historial
    print(f"🔍 Analizando historial Chrome: {ruta_historial} | Analyzing Chrome history: {ruta_historial}")
    resultados = analizar_historial_chrome(ruta_historial)
    
    if resultados:
        print(f"📊 Entradas encontradas: {len(resultados)} | Entries found: {len(resultados)}")
        generar_html_browserhistory(resultados, salida_html)
    else:
        print("⚠️ No se encontraron entradas de historial | No history entries found")

if __name__ == "__main__":
    main()