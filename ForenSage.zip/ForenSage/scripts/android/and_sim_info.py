#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import sqlite3
import os
from pathlib import Path
import datetime

def extract_sim_info(db_path):
    """Extrae información de la SIM desde la base de datos telephony.db"""
    if not os.path.exists(db_path):
        print(f"[!] Base de datos no encontrada: {db_path}")
        return [], []
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='siminfo';")
        if not cursor.fetchone():
            print("[!] La tabla 'siminfo' no existe en la base de datos")
            conn.close()
            return [], []
        
        # Get the available columns in the table/ Obtener las columnas disponibles en la tabla
        cursor.execute("PRAGMA table_info(siminfo);")
        columns_info = cursor.fetchall()
        available_columns = [col[1] for col in columns_info]
        
        target_columns = ["icc_id", "card_id", "carrier_id", "country_iso", "mcc", "mnc", 
                          "display_name", "carrier_name", "number", "sim_id"]
        
        # Filter only the columns that exist in the table / Filtrar solo las columnas que existen en la tabla
        columns_to_query = [col for col in target_columns if col in available_columns]
        
        if not columns_to_query:
            print("[!] No se encontraron columnas relevantes en la tabla siminfo")
            conn.close()
            return [], []
        
        query = f"SELECT {', '.join(columns_to_query)} FROM siminfo;"
        cursor.execute(query)
        rows = cursor.fetchall()
    
        conn.close()
        
        print(f"[✓] Encontradas {len(rows)} filas de información SIM")
        return columns_to_query, rows
        
    except sqlite3.Error as e:
        print(f"[!] Error SQLite: {e}")
        return [], []
    except Exception as e:
        print(f"[!] Error inesperado: {e}")
        return [], []

def create_visual_sim_html(columns, rows, output_path):
    
    if not rows:
        print("[!] No hay datos para generar el informe HTML")
        return False
    
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    #HTML
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> SIM Card Report | Informe de Tarjeta SIM</title>
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --sim-gold: #d4af37;
        }}
        
        body {{
            font-family: 'Arial', sans-serif;
            background-color: var(--background);
            color: var(--text);
            margin: 0;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }}
        
        h1 {{
            color: var(--accent);
            text-align: center;
            margin-bottom: 30px;
        }}
        
        .timestamp {{
            text-align: center;
            color: var(--text-secondary);
            margin-bottom: 40px;
        }}
        
        .sim-cards-container {{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
        }}
        
        .sim-card {{
            position: relative;
            width: 300px;
            height: 480px;
            background: linear-gradient(145deg, var(--sim-gold), #c19932);
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
            padding: 20px;
            display: flex;
            flex-direction: column;
            margin-bottom: 30px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}
        
        .sim-card:hover {{
            transform: translateY(-5px) rotate(1deg);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.4);
        }}
        
        
        .sim-logo {{
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 18px;
            font-weight: bold;
            color: #222;
        }}
        
        .sim-info {{
            margin-top: 120px;
            color: #222;
        }}
        
        .sim-field {{
            margin-bottom: 12px;
            border-bottom: 1px dashed rgba(0, 0, 0, 0.2);
            padding-bottom: 5px;
        }}
        
        .sim-label {{
            font-size: 12px;
            text-transform: uppercase;
            opacity: 0.7;
        }}
        
        .sim-value {{
            font-size: 16px;
            font-weight: bold;
            word-break: break-word;
        }}
        
        .carrier-highlight {{
            font-size: 20px;
            margin-top: 15px;
            text-align: center;
            background: rgba(0, 0, 0, 0.1);
            padding: 8px;
            border-radius: 5px;
            margin-bottom: 15px;
        }}
        
        
        .data-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 40px;
            background-color: var(--card-bg);
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }}
        
        .data-table th {{
            background-color: var(--primary);
            color: var(--text);
            text-align: left;
            padding: 12px 15px;
        }}
        
        .data-table td {{
            padding: 10px 15px;
            border-bottom: 1px solid var(--border-color);
        }}
        
        .data-table tr:nth-child(even) {{
            background-color: rgba(52, 152, 219, 0.05);
        }}
        
        .data-table tr:hover {{
            background-color: var(--primary-light);
        }}
        
        .footer {{
            text-align: center;
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
            color: var(--text-secondary);
        }}
        
        @media (max-width: 768px) {{
            .sim-card {{
                width: 280px;
                height: 450px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 SIM Card(s) Report / Informe de Tarjeta(s) SIM</h1>
        <div class="timestamp">Generado el: {timestamp}</div>
        
        <div class="sim-cards-container">"""
    
    # Create a visual representation for each SIM
    for row_index, row in enumerate(rows):
        # Crear un diccionario de los valores para acceder más fácilmente
        sim_data = dict(zip(columns, row))
        
        # Obtener valores específicos con defaults por si no existen
        carrier = sim_data.get('carrier_name', sim_data.get('display_name', 'Operador Desconocido'))
        icc_id = sim_data.get('icc_id', 'N/A')
        sim_id = sim_data.get('sim_id', sim_data.get('card_id', f'SIM-{row_index+1}'))
        country = sim_data.get('country_iso', 'N/A')
        mcc = sim_data.get('mcc', 'N/A')
        mnc = sim_data.get('mnc', 'N/A')
        
        html += f"""
            <div class="sim-card">
                
                <div class="sim-logo">SIM CARD</div>
                
                <div class="sim-info">
                    <div class="carrier-highlight">{carrier}</div>
                    
                    <div class="sim-field">
                        <div class="sim-label">ICC ID</div>
                        <div class="sim-value">{icc_id}</div>
                    </div>
                    
                    <div class="sim-field">
                        <div class="sim-label">SIM ID</div>
                        <div class="sim-value">{sim_id}</div>
                    </div>
                    
                    <div class="sim-field">
                        <div class="sim-label">País</div>
                        <div class="sim-value">{country}</div>
                    </div>
                    
                    <div class="sim-field">
                        <div class="sim-label">MCC-MNC</div>
                        <div class="sim-value">{mcc}-{mnc}</div>
                    </div>"""
        
        # Añadir campos adicionales que no son parte del diseño principal
        for col, val in sim_data.items():
            if col not in ['icc_id', 'sim_id', 'card_id', 'carrier_name', 'display_name', 'country_iso', 'mcc', 'mnc']:
                html += f"""
                    <div class="sim-field">
                        <div class="sim-label">{col}</div>
                        <div class="sim-value">{'N/A' if val is None else val}</div>
                    </div>"""
        
        html += """
                </div>
            </div>"""
    
    # Añadir tabla de datos completa
    html += """
        </div>
        
        <h2>Datos completos</h2>
        <table class="data-table">
            <thead>
                <tr>"""
    
    for col in columns:
        html += f"""
                    <th>{col}</th>"""
    
    html += """
                </tr>
            </thead>
            <tbody>"""
    
    for row in rows:
        html += """
                <tr>"""
        for val in row:
            display_val = "N/A" if val is None else val
            html += f"""
                    <td>{display_val}</td>"""
        html += """
                </tr>"""
    
    # Cerrar HTML
    html += """
            </tbody>
        </table>
        
        <div class="footer">
            <p>Archivo analizado: telephony.db</p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>
</body>
</html>"""
    
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"[✓] Informe HTML con diseño visual de tarjeta SIM generado exitosamente: {output_path}")
        return True
    except Exception as e:
        print(f"[!] Error al guardar el informe HTML: {e}")
        return False

def main():
    # Configurar el parser de argumentos
    parser = argparse.ArgumentParser(description="Extractor de información SIM de Android con visualización de tarjeta SIM")
    parser.add_argument("--db-path", type=str, 
                      default=str(Path.home() / "ForenSage/analyze/android/data/user_de/0/com.android.providers.telephony/databases/telephony.db"),
                      help="Ruta a la base de datos telephony.db")
    parser.add_argument("--output", type=str, 
                      default=str(Path.home() / "ForenSage/results/and_sim_info.html"),
                      help="Ruta del archivo HTML de salida")
    
    args = parser.parse_args()
    
    # Extraer información de la SIM
    columns, rows = extract_sim_info(args.db_path)
    
    # Si tenemos datos, crear el informe HTML con diseño visual
    if columns and rows:
        create_visual_sim_html(columns, rows, args.output)
    else:
        print("[!] No se pudo generar el informe: no se encontraron datos.")

if __name__ == "__main__":
    main()










