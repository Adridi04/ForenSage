import os
from pathlib import Path
import datetime

BASE_DIR = Path(".")

def buscar_multimedia(rutas_relativas):
    archivos_multimedia = []

    for ruta_relativa in rutas_relativas:

        ruta_absoluta = BASE_DIR / ruta_relativa
        
        if os.path.exists(ruta_absoluta):
            for carpeta, subcarpetas, archivos in os.walk(ruta_absoluta):
                for archivo in archivos:

                    if archivo.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.mp4', '.mov', '.avi', '.mkv', '.webp')):
                        ruta_archivo_abs = Path(carpeta) / archivo
                        
                        ruta_relativa = ruta_archivo_abs.relative_to(BASE_DIR)
                        
                        tamano = round(os.path.getsize(ruta_archivo_abs) / (1024 * 1024), 2)
                        
                        archivos_multimedia.append({
                            'ruta_absoluta': ruta_archivo_abs,
                            'ruta_relativa': ruta_relativa,
                            'nombre': archivo,
                            'tamano': tamano,
                            'tipo': os.path.splitext(archivo)[1].lower()[1:]
                        })
        else:
            print(f"La ruta no existe: {ruta_relativa}")

    return archivos_multimedia

def generar_html_multimedia(archivos, ruta_salida_relativa, web_mode=False):
   
    ruta_salida_abs = BASE_DIR / ruta_salida_relativa
    
    os.makedirs(ruta_salida_abs.parent, exist_ok=True)

    tipos = {}
    for archivo in archivos:
        tipo = archivo['tipo']
        if tipo not in tipos:
            tipos[tipo] = 0
        tipos[tipo] += 1

    total_archivos = len(archivos)
    
    #datetime
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Media Files | Archivos Multimedia</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {{
            /* Colors / Colores */
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
        }}

        /* Base structure/Estructura base */
        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }}

        .container {{
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }}

        .header {{
            text-align: center;
            margin-bottom: 2rem;
            animation: fadeIn 1s ease-in-out;
            padding: 2rem;
            background-color: var(--card-bg);
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
            border-bottom: 3px solid var(--accent);
        }}

        .title {{
            font-size: 2.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            letter-spacing: 1px;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }}

        .stats-container {{
            display: flex;
            justify-content: center;
            gap: 2rem;
            flex-wrap: wrap;
            margin-bottom: 2rem;
        }}

        .stat-card {{
            background-color: var(--card-bg);
            border-radius: 10px;
            padding: 1.5rem;
            min-width: 200px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
            border-left: 3px solid var(--accent);
            animation: fadeIn 0.8s ease-in-out;
        }}

        .stat-value {{
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--accent-light);
            margin-bottom: 0.5rem;
        }}

        .stat-label {{
            color: var(--text-secondary);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}

        .gallery {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 2rem;
        }}

        .media-card {{
            background-color: var(--card-bg);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
        }}

        .media-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.3);
        }}

        .media-img {{
            width: 100%;
            height: 220px;
            object-fit: cover;
            border-radius: 8px;
            transition: transform 0.5s ease;
            border: 3px solid var(--primary-light);
            display: block;
        }}

        .media-img-container {{
            overflow: hidden;
            position: relative;
            margin: 10px;
        }}

        .media-img-container::before {{
            content: '';
            position: absolute;
            inset: 0;
            border-radius: 8px;
            box-shadow: inset 0 0 15px rgba(0, 0, 0, 0.6);
            z-index: 1;
            pointer-events: none;
        }}

        .media-card:hover .media-img {{
            transform: scale(1.05);
        }}

        .media-info {{
            padding: 15px;
        }}

        .media-title {{
            font-weight: 600;
            margin-bottom: 5px;
            color: var(--accent-light);
            font-size: 1rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}

        .media-path {{
            color: var(--text-secondary);
            font-size: 0.85rem;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            margin-bottom: 8px;
        }}

        .media-meta {{
            display: flex;
            justify-content: space-between;
            font-size: 0.8rem;
            color: var(--text-secondary);
        }}

        .section-title {{
            font-size: 1.8rem;
            color: var(--accent-light);
            font-weight: 600;
            margin: 2.5rem 0 1.5rem;
            position: relative;
            padding-bottom: 0.5rem;
            text-align: center;
        }}

        .section-title::after {{
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: linear-gradient(90deg, var(--accent), var(--accent-light));
            animation: borderGrow 1s ease-out;
        }}

        .footer {{
            text-align: center;
            margin-top: 3rem;
            padding: 1.5rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
        }}

        .filter-container {{
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }}

        .filter-btn {{
            background-color: var(--primary-dark);
            color: var(--text);
            border: none;
            border-radius: 20px;
            padding: 8px 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Montserrat', sans-serif;
            font-size: 0.85rem;
        }}

        .filter-btn:hover, .filter-btn.active {{
            background-color: var(--accent);
            transform: translateY(-2px);
        }}

        .filter-btn i {{
            margin-right: 5px;
        }}

        .video-badge {{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 3rem;
            color: rgba(255, 255, 255, 0.8);
            opacity: 0.8;
            z-index: 2;
        }}

        /* Animations/Animaciones */
        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(-10px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @keyframes borderGrow {{
            from {{ width: 0; }}
            to {{ width: 100px; }}
        }}

        /* Responsive */
        @media (max-width: 768px) {{
            .gallery {{
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }}
            
            .title {{
                font-size: 2.2rem;
            }}
            
            .section-title {{
                font-size: 1.5rem;
            }}

            .stat-card {{
                min-width: 150px;
            }}
        }}

        @media (max-width: 576px) {{
            .container {{
                padding: 1rem;
            }}
            
            .gallery {{
                grid-template-columns: 1fr;
            }}
            
            .media-img {{
                height: 180px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Media Files | Archivos Multimedia</h1>
            <p class="subtitle">Análisis forense de contenido multimedia encontrado</p>
            <p>📅 Fecha de análisis: {datetime.datetime.now().strftime('%d de %B de %Y, %H:%M:%S')}</p>
        </div>
        
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-value">{total_archivos}</div>
                <div class="stat-label">Archivos encontrados</div>
            </div>"""

    for tipo, cantidad in sorted(tipos.items(), key=lambda x: x[1], reverse=True)[:3]:
        icon = "fa-image"
        if tipo in ["mp4", "mov", "avi", "mkv"]:
            icon = "fa-video"
        
        html += f"""
            <div class="stat-card">
                <div class="stat-value">{cantidad}</div>
                <div class="stat-label"><i class="fas {icon}"></i> Archivos .{tipo}</div>
            </div>"""
            
    html += """
        </div>
        
        <div class="filter-container">
            <button class="filter-btn active" data-filter="all"><i class="fas fa-th-large"></i> Todos</button>"""
            
    for tipo in sorted(tipos.keys()):
        icon = "fa-image"
        if tipo in ["mp4", "mov", "avi", "mkv"]:
            icon = "fa-video"
            
        html += f"""
            <button class="filter-btn" data-filter="{tipo}"><i class="fas {icon}"></i> {tipo.upper()}</button>"""
    
    html += """
        </div>

        <h2 class="section-title">Galería de Archivos</h2>
        
        <div class="gallery" id="mediaGallery">"""

    for archivo in archivos:
        ruta_absoluta = str(archivo['ruta_absoluta'])
        es_video = archivo['tipo'] in ["mp4", "mov", "avi", "mkv"]
        
        if web_mode:
            
            img_src = f"/media/{archivo['ruta_relativa']}"
        else:
            
            img_src = f"file:///{ruta_absoluta}"
        
        html += f"""
            <div class="media-card" data-type="{archivo['tipo']}">
                <div class="media-img-container">
                    <img src="{img_src}" class="media-img" alt="Previsualización de {archivo['nombre']}">
                    {f'<div class="video-badge"><i class="fas fa-play-circle"></i></div>' if es_video else ''}
                </div>
                <div class="media-info">
                    <h3 class="media-title">{archivo['nombre']}</h3>
                    <p class="media-path">{archivo['ruta_relativa'].parent}</p>
                    <div class="media-meta">
                        <span><i class="fas fa-weight-hanging"></i> {archivo['tamano']} MB</span>
                    </div>
                </div>
            </div>"""

    html += """
        </div>
        
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>
    
    <script>

        const filterButtons = document.querySelectorAll('.filter-btn');
        const mediaItems = document.querySelectorAll('.media-card');
        
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {

                filterButtons.forEach(btn => btn.classList.remove('active'));
                
                button.classList.add('active');
                
                const filterValue = button.getAttribute('data-filter');
                
                mediaItems.forEach(item => {
                    if (filterValue === 'all' || item.getAttribute('data-type') === filterValue) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida_abs, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"Informe HTML generado en: {ruta_salida_relativa}")
    except Exception as e:
        print(f"Error al guardar el HTML: {e}")

def main():
    # Entry paths relative to the base directory / Rutas de entrada relativas al directorio base
    rutas_multimedia_relativas = [
        "analyze/android/data/media/0/DCIM/Camera/",
        "analyze/android/data/media/0/DCIM/Restored/",
        "analyze/android/data/media/0/DCIM/imo/",
        "analyze/android/data/media/0/Pictures/",
        "analyze/android/data/media/0/Download/"
    ]

    # Output path relative to the base directory / Ruta de salida relativa al directorio base
    ruta_salida_relativa = Path("results/and_media_info.html")
    
    #Search for media files in all paths / Buscar archivos multimedia en todas las rutas
    archivos = buscar_multimedia(rutas_multimedia_relativas)
    
    if archivos:
        # Generate the HTML file / Generar el archivo HTML
        generar_html_multimedia(archivos, ruta_salida_relativa)
        print("Proceso completado.")
    else:
        print("No se encontraron archivos multimedia.")

if __name__ == "__main__":
    main()

