#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# scripts/android/and_blocked_numbers.py

import sqlite3
from pathlib import Path
from datetime import datetime

def analyze_blocked_numbers_db(db_path=None, output_html=None):
    """
    Analiza la base de datos de números bloqueados de Android y genera un informe HTML.
    
    Args:
        db_path: Ruta a la base de datos blockednumbers.db
        output_html: Ruta donde guardar el informe HTML
    """
    # If no paths are specified, use the default ones / Si no se especifican rutas, usar las predeterminadas
    if db_path is None:
        base_dir = Path.home() / "ForenSage"
        db_path = base_dir / "analyze/android/data/user_de/0/com.android.providers.blockednumber/databases/blockednumbers.db"
    
    if output_html is None:
        results_dir = Path.home() / "ForenSage" / "results"
        output_html = results_dir / "and_sim_blockphone.html"
    
    # Create directory if it does not exist / Crear directorio si no existe
    output_html.parent.mkdir(exist_ok=True)
    
    print(f"Analizando base de datos en: {db_path}")

    if not db_path.exists():
        print(f"Error: No se encontró la base de datos en la ruta especificada")
        return False

    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Get blocked numbers / Obtener números bloqueados
        cursor.execute("SELECT * FROM blocked")
        blocked_numbers = cursor.fetchall()
        cursor.execute("PRAGMA table_info(blocked);")
        columns = [column[1] for column in cursor.fetchall()]

        #HTML
        html_content = f"""
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title> Blocked Numbers Report | Informe de Números Bloqueados</title>
            <style>
                :root {{
                    --primary-dark: #2c3e50;
                    --primary: #34495e;
                    --primary-light: #4a6278;
                    --accent: #e74c3c;  /* Rojo para indicar bloqueo */
                    --accent-light: #ee8277;
                    --text: #ecf0f1;
                    --text-secondary: #bdc3c7;
                    --background: #1a1a2e;
                    --card-bg: #16213e;
                    --border-color: rgba(255, 255, 255, 0.1);
                }}
                
                body {{
                    font-family: 'Arial', sans-serif;
                    background-color: var(--background);
                    color: var(--text);
                    margin: 0;
                    padding: 20px;
                }}
                
                .container {{
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 20px;
                }}
                
                h1 {{
                    color: var(--accent);
                    text-align: center;
                    margin-bottom: 30px;
                }}
                
                .timestamp {{
                    text-align: center;
                    color: var(--text-secondary);
                    margin-bottom: 40px;
                }}
                
                .blocked-cards-container {{
                    display: flex;
                    flex-wrap: wrap;
                    justify-content: center;
                    gap: 30px;
                    margin-bottom: 40px;
                }}
                
                .blocked-card {{
                    position: relative;
                    width: 300px;
                    background: linear-gradient(145deg, var(--accent), var(--accent-light));
                    border-radius: 15px;
                    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
                    padding: 20px;
                    transition: transform 0.3s ease, box-shadow 0.3s ease;
                }}
                
                .blocked-card:hover {{
                    transform: translateY(-5px);
                    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.4);
                }}
                
                .blocked-logo {{
                    position: absolute;
                    top: 20px;
                    right: 20px;
                    font-size: 18px;
                    font-weight: bold;
                    color: white;
                }}
                
                .blocked-info {{
                    margin-top: 40px;
                    color: white;
                }}
                
                .blocked-field {{
                    margin-bottom: 12px;
                    border-bottom: 1px dashed rgba(255, 255, 255, 0.2);
                    padding-bottom: 5px;
                }}
                
                .blocked-label {{
                    font-size: 12px;
                    text-transform: uppercase;
                    opacity: 0.8;
                }}
                
                .blocked-value {{
                    font-size: 16px;
                    font-weight: bold;
                    word-break: break-word;
                }}
                
                .number-highlight {{
                    font-size: 22px;
                    margin: 15px 0;
                    text-align: center;
                    background: rgba(0, 0, 0, 0.2);
                    padding: 10px;
                    border-radius: 5px;
                }}
                
                .summary {{
                    background-color: var(--card-bg);
                    padding: 20px;
                    border-radius: 8px;
                    margin-top: 30px;
                    text-align: center;
                }}
                
                .footer {{
                    text-align: center;
                    margin-top: 50px;
                    padding-top: 20px;
                    border-top: 1px solid var(--border-color);
                    color: var(--text-secondary);
                }}
                
                @media (max-width: 768px) {{
                    .blocked-card {{
                        width: 100%;
                    }}
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🚫 Blocked Phone Numbers / Números Telefónicos Bloqueados</h1>
                <div class="timestamp">Generado el: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
                
                <div class="blocked-cards-container">
        """

        #  Generate cards for each blocked numbe / Generar tarjetas para cada número bloqueado
        for number in blocked_numbers:
            number_data = dict(zip(columns, number))
            
            html_content += f"""
                <div class="blocked-card">
                    <div class="blocked-logo">BLOQUEADO</div>
                    
                    <div class="blocked-info">
                        <div class="number-highlight">{number_data.get('original_number', 'N/A')}</div>
                        
                        <div class="blocked-field">
                            <div class="blocked-label">ID</div>
                            <div class="blocked-value">{number_data.get('_id', 'N/A')}</div>
                        </div>
                        
                        <div class="blocked-field">
                            <div class="blocked-label">Número Normalizado</div>
                            <div class="blocked-value">{number_data.get('normalized_number', 'N/A')}</div>
                        </div>
                        
                        <div class="blocked-field">
                            <div class="blocked-label">Veces Contactado</div>
                            <div class="blocked-value">{number_data.get('times_contacted', '0')}</div>
                        </div>
                        
                        <div class="blocked-field">
                            <div class="blocked-label">Último Contacto</div>
                            <div class="blocked-value">{number_data.get('last_time_contacted', 'Nunca')}</div>
                        </div>
                    </div>
                </div>
            """

        html_content += f"""
                </div>
                
                <div class="summary">
                    <h3>Resumen del Análisis</h3>
                    <p>Total de números bloqueados encontrados: <strong>{len(blocked_numbers)}</strong></p>
                    <p>Base de datos analizada: <code>{db_path}</code></p>
                </div>
                
            <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
            </footer>

            </div>
        </body>
        </html>
        """

        with open(output_html, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"\nInforme generado con éxito en:\n{output_html}")
        return True

    except sqlite3.Error as e:
        print(f"\nError SQLite: {e}")
        return False
    except Exception as e:
        print(f"\nError inesperado: {e}")
        return False
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    analyze_blocked_numbers_db()