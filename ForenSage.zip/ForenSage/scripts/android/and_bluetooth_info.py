import os
import sqlite3
import xml.etree.ElementTree as ET
import datetime
from pathlib import Path
import json

def analizar_bluetooth_db(ruta_archivo):
    """
    Analiza la base de datos SQLite de Bluetooth y extrae información relevante.
    / Analyzes Bluetooth SQLite database and extracts relevant information.
    """
    resultados = {
        "devices": [],
        "pairings": [],
        "connections": []
    }
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        return resultados, file_exists
            
    try:
        # Conectar a la base de datos SQLite / Connect to SQLite database
        conn = sqlite3.connect(ruta_archivo)
        cursor = conn.cursor()
        
        # Obtener lista de tablas / Get list of tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = cursor.fetchall()
        resultados["tables"] = [tabla[0] for tabla in tablas]
        
        # Extraer dispositivos emparejados si existe la tabla / Extract paired devices if table exists
        if "metadata" in resultados["tables"]:
            cursor.execute("SELECT * FROM metadata")
            metadata_rows = cursor.fetchall()
            
            # Obtener nombres de columnas / Get column names
            column_names = [description[0] for description in cursor.description]
            
            for row in metadata_rows:
                device_info = {}
                for i, value in enumerate(row):
                    device_info[column_names[i]] = str(value)
                resultados["devices"].append(device_info)
        
        # Obtener más información específica si existen otras tablas relevantes
        for table in resultados["tables"]:
            if table not in ["android_metadata", "sqlite_sequence", "metadata"]:
                cursor.execute(f"SELECT * FROM {table} LIMIT 10")
                rows = cursor.fetchall()
                
                # Obtener nombres de columnas / Get column names
                if cursor.description:
                    column_names = [description[0] for description in cursor.description]
                    
                    table_data = []
                    for row in rows:
                        row_data = {}
                        for i, value in enumerate(row):
                            row_data[column_names[i]] = str(value)
                        table_data.append(row_data)
                        
                    if "pair" in table.lower() or "bond" in table.lower():
                        resultados["pairings"] = table_data
                    elif "connect" in table.lower():
                        resultados["connections"] = table_data
        
        conn.close()
                
    except Exception as e:
        print(f"Error analizando {ruta_archivo}: {e}")
    
    return resultados, file_exists

def analizar_bluetooth_xml(ruta_archivo):
    """
    Analiza archivos XML de preferencias de Bluetooth.
    / Analyzes Bluetooth XML preference files.
    """
    resultados = {}
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        return resultados, file_exists
            
    try:
        # Verificar si el archivo tiene contenido
        if os.path.getsize(ruta_archivo) == 0:
            resultados["empty_file"] = True
            return resultados, file_exists
            
        # Leer el archivo XML / Read XML file
        tree = ET.parse(ruta_archivo)
        root = tree.getroot()
        
        # Extraer todas las preferencias / Extract all preferences
        for child in root:
            if child.tag == "string":
                resultados[child.attrib.get("name", "unknown")] = child.text
            elif child.tag == "boolean":
                resultados[child.attrib.get("name", "unknown")] = child.attrib.get("value", "false")
            elif child.tag == "int":
                resultados[child.attrib.get("name", "unknown")] = child.attrib.get("value", "0")
            elif child.tag == "long":
                resultados[child.attrib.get("name", "unknown")] = child.attrib.get("value", "0")
            elif child.tag == "float":
                resultados[child.attrib.get("name", "unknown")] = child.attrib.get("value", "0.0")
            elif child.tag == "set" or child.tag == "map":
                # Para conjuntos o mapas, crear un diccionario anidado
                set_data = {}
                for item in child:
                    if "name" in item.attrib:
                        set_data[item.attrib["name"]] = item.attrib.get("value", "")
                    else:
                        set_data[f"item_{len(set_data)}"] = item.text or item.attrib.get("value", "")
                resultados[child.attrib.get("name", "unknown")] = set_data
                
    except Exception as e:
        print(f"Error analizando {ruta_archivo}: {e}")
        resultados["error"] = str(e)
    
    return resultados, file_exists

def generar_html_bluetooth_analysis(db_datos, prefs_datos, volume_datos, archivos_info, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis de los archivos Bluetooth
    / Generates HTML report with Bluetooth files analysis results
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception as e:
            print(f"Error al crear directorio: {e}")
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Comprobar si hay dispositivos en la base de datos
    num_devices = len(db_datos.get("devices", []))
    devices_info = db_datos.get("devices", [])
    
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Android Bluetooth Analysis | Análisis de Bluetooth Android</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .source-container {{
            margin-top: 2rem;
            margin-bottom: 2rem;
        }}

        .source-card {{
            background-color: var(--primary);
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}

        .source-path {{
            font-family: monospace;
            color: var(--text);
            word-break: break-all;
        }}

        .source-status {{
            font-size: 0.9rem;
            padding: 0.3rem 0.8rem;
            border-radius: 12px;
            margin-left: 1rem;
            white-space: nowrap;
        }}

        .source-found {{
            background-color: var(--success);
            color: var(--text);
        }}

        .source-not-found {{
            background-color: var(--danger);
            color: var(--text);
        }}

        .info-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 2rem;
            margin: 2rem 0;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }}

        .card-title {{
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: var(--accent-light);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }}

        .device-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }}

        .device-card {{
            background-color: var(--card-bg);
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s ease;
        }}

        .device-card:hover {{
            transform: translateY(-5px);
        }}

        .device-name {{
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--accent-light);
        }}

        .device-address {{
            font-family: monospace;
            margin-bottom: 1rem;
            color: var(--text-secondary);
        }}

        .device-details {{
            margin-top: 1rem;
        }}

        .device-detail {{
            display: flex;
            justify-content: space-between;
            border-bottom: 1px solid var(--border-color);
            padding: 0.5rem 0;
        }}

        .detail-label {{
            color: var(--text-secondary);
        }}

        .detail-value {{
            font-family: monospace;
            color: var(--text);
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }}

        .pref-table {{
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
        }}

        .pref-table th, .pref-table td {{
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }}

        .pref-table th {{
            background-color: var(--primary-dark);
            color: var(--accent-light);
        }}

        .pref-key {{
            font-family: monospace;
            color: var(--text-secondary);
        }}

        .pref-value {{
            font-family: monospace;
            color: var(--text);
            word-break: break-all;
        }}

        .footer {{
            text-align: center;
            margin-top: 3rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .toggle-details {{
            background-color: var(--primary-light);
            border: none;
            color: var(--text);
            padding: 0.5rem 1rem;
            border-radius: 5px;
            cursor: pointer;
            font-family: 'Montserrat', sans-serif;
            font-size: 0.9rem;
            margin-top: 1rem;
            transition: background-color 0.3s ease;
        }}

        .toggle-details:hover {{
            background-color: var(--accent);
        }}

        .hidden {{
            display: none;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .source-card {{
                flex-direction: column;
                align-items: flex-start;
            }}
            .source-status {{
                margin-left: 0;
                margin-top: 0.5rem;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Android Bluetooth Analysis | Análisis de Bluetooth Android</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
        </div>

        <!-- Fuentes de datos analizadas -->
        <div class="info-card">
            <div class="card-title">📁 Archivos Analizados | Analyzed Files</div>
            
            <div class="source-container">"""

    # Para cada archivo, mostrar estado
    for i, (ruta_archivo, existe) in enumerate(archivos_info):
        status_text = "Encontrado | Found" if existe else "No encontrado | Not found"
        status_class = "source-found" if existe else "source-not-found"
        
        html += f"""
                <div class="source-card">
                    <div class="source-path">{ruta_archivo}</div>
                    <div class="source-status {status_class}">{status_text}</div>
                </div>"""

    html += """
            </div>
        </div>"""

    # Sección de dispositivos Bluetooth
    if db_datos.get("devices") and len(db_datos["devices"]) > 0:
        html += f"""
        <!-- Dispositivos Bluetooth -->
        <div class="info-card">
            <div class="card-title">📱 Dispositivos Bluetooth ({num_devices}) | Bluetooth Devices ({num_devices})</div>
            
            <div class="device-grid">"""
        
        for device in devices_info:
            device_name = device.get("name", "Desconocido | Unknown")
            device_address = device.get("address", "") or device.get("addr", "") or "Desconocido | Unknown"
            
            html += f"""
                <div class="device-card">
                    <div class="device-name">{device_name}</div>
                    <div class="device-address">{device_address}</div>
                    
                    <div class="device-details">"""
            
            # Mostrar detalles relevantes
            for key, value in device.items():
                if key not in ["name", "address", "addr"] and value:
                    html += f"""
                        <div class="device-detail">
                            <span class="detail-label">{key}</span>
                            <span class="detail-value">{value}</span>
                        </div>"""
            
            html += """
                    </div>
                </div>"""
        
        html += """
            </div>
        </div>"""
    else:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron dispositivos | No devices found</div>
            <p>No se encontraron dispositivos Bluetooth emparejados en la base de datos. | No paired Bluetooth devices found in the database.</p>
        </div>"""

    # Sección de preferencias de Bluetooth
    if prefs_datos and not prefs_datos.get("error"):
        html += """
        <!-- Preferencias de Bluetooth -->
        <div class="info-card">
            <div class="card-title">⚙️ Preferencias de Bluetooth | Bluetooth Preferences</div>
            
            <table class="pref-table">
                <thead>
                    <tr>
                        <th>Clave | Key</th>
                        <th>Valor | Value</th>
                    </tr>
                </thead>
                <tbody>"""
        
        for key, value in prefs_datos.items():
            if key != "error" and key != "empty_file":
                # Si el valor es un diccionario, formatearlo como JSON
                if isinstance(value, dict):
                    formatted_value = json.dumps(value, indent=2)
                else:
                    formatted_value = str(value)
                
                html += f"""
                    <tr>
                        <td class="pref-key">{key}</td>
                        <td class="pref-value">{formatted_value}</td>
                    </tr>"""
        
        html += """
                </tbody>
            </table>
        </div>"""
    elif prefs_datos.get("empty_file"):
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ Archivo de preferencias vacío | Empty preferences file</div>
            <p>El archivo de preferencias está vacío. | The preferences file is empty.</p>
        </div>"""
    elif prefs_datos.get("error"):
        html += f"""
        <div class="warning-card">
            <div class="warning-title">⚠️ Error al analizar preferencias | Error analyzing preferences</div>
            <p>Error: {prefs_datos.get("error")}</p>
        </div>"""
    elif not prefs_datos:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontró archivo de preferencias | Preferences file not found</div>
            <p>No se pudo acceder al archivo de preferencias. | Could not access preferences file.</p>
        </div>"""

    # Sección de configuración de volumen Bluetooth
    if volume_datos and not volume_datos.get("error"):
        html += """
        <!-- Configuración de Volumen Bluetooth -->
        <div class="info-card">
            <div class="card-title">🔊 Configuración de Volumen | Volume Settings</div>
            
            <table class="pref-table">
                <thead>
                    <tr>
                        <th>Dispositivo | Device</th>
                        <th>Volumen | Volume</th>
                    </tr>
                </thead>
                <tbody>"""
        
        if volume_datos.get("empty_file"):
            html += """
                <tr>
                    <td colspan="2">Archivo vacío. No hay configuraciones de volumen. | Empty file. No volume settings.</td>
                </tr>"""
        else:
            for key, value in volume_datos.items():
                if key != "error" and key != "empty_file":
                    # Intentar determinar si es una configuración de volumen
                    if "volume" in key.lower() or isinstance(value, dict):
                        device_name = key
                        volume_value = value
                        
                        html += f"""
                        <tr>
                            <td class="pref-key">{device_name}</td>
                            <td class="pref-value">{volume_value}</td>
                        </tr>"""
        
        html += """
                </tbody>
            </table>
        </div>"""

    # Si hay tablas adicionales, mostrarlas
    if db_datos.get("tables") and len(db_datos["tables"]) > 0:
        html += """
        <!-- Tablas de la Base de Datos -->
        <div class="info-card">
            <div class="card-title">📊 Tablas de la Base de Datos | Database Tables</div>
            
            <div id="tablesInfo">
                <p>Tablas encontradas en la base de datos | Tables found in the database:</p>
                <ul>"""
        
        for table in db_datos["tables"]:
            html += f"""
                    <li class="pref-key">{table}</li>"""
        
        html += """
                </ul>
            </div>
        </div>"""

    # Footer con información del análisis
    html += f"""
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
        </div>
        <footer class="footer">
            <p>ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
        
        // Función para alternar visibilidad
        function toggleDetails(elementId) {{
            const element = document.getElementById(elementId);
            if (element) {{
                if (element.classList.contains('hidden')) {{
                    element.classList.remove('hidden');
                }} else {{
                    element.classList.add('hidden');
                }}
            }}
        }}
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Rutas de los archivos a analizar
    base_path = Path.home() / "ForenSage"
    
    ruta_db = base_path / "analyze/android/data/user_de/0/com.android.bluetooth/databases/bluetooth_db"
    ruta_prefs = base_path / "analyze/android/data/user_de/0/com.android.bluetooth/shared_prefs/com.android.bluetooth_preferences.xml"
    ruta_volume = base_path / "analyze/android/data/user_de/0/com.android.bluetooth/shared_prefs/bluetooth_volume_map.xml"
    
    # Para la salida, crear ruta relativa
    salida_html = base_path / "results/and_Bluetooth_info.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar archivos
    db_datos, db_existe = analizar_bluetooth_db(str(ruta_db))
    prefs_datos, prefs_existe = analizar_bluetooth_xml(str(ruta_prefs))
    volume_datos, volume_existe = analizar_bluetooth_xml(str(ruta_volume))
    
    # Recopilar información de los archivos
    archivos_info = [
        (str(ruta_db), db_existe),
        (str(ruta_prefs), prefs_existe),
        (str(ruta_volume), volume_existe)
    ]
    
    # Generar el informe HTML
    generar_html_bluetooth_analysis(
        db_datos, prefs_datos, volume_datos, 
        archivos_info, str(salida_html)
    )

if __name__ == "__main__":
    main()