import os
from pathlib import Path
import datetime
import sqlite3
import json
import re

def analizar_db_contactos(ruta_db):
    """Analyzes the Android contacts database and extracts basic information"""
    resultados = {'contactos': [], 'numeros': [], 'emails': []}
    try:
        # Verify that the file exists
        db_path = Path(ruta_db)
        if not db_path.exists():
            print(f"❌ Base de datos no encontrada: {db_path}")
            return resultados
            
        # Connect to the database
        conn = sqlite3.connect(ruta_db)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Get tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = [tabla['name'] for tabla in cursor.fetchall()]
        print(f"📊 Tablas encontradas en {db_path}: {', '.join(tablas)}")
        
        # Analyze main contacts
        try:
            if 'raw_contacts' in tablas:
                cursor.execute("""
                    SELECT raw_contacts._id, raw_contacts.display_name, raw_contacts.account_name,
                    raw_contacts.account_type, raw_contacts.times_contacted, raw_contacts.last_time_contacted
                    FROM raw_contacts WHERE deleted = 0
                """)
                
                for row in cursor.fetchall():
                    contacto = {
                        'id': row['_id'],
                        'nombre': row['display_name'] or 'Sin nombre',
                        'cuenta': row['account_name'] or 'Local',
                        'tipo_cuenta': row['account_type'] or 'Local',
                        'veces_contactado': row['times_contacted'] or 0
                    }
                    
                    # Convert timestamp to date
                    if row['last_time_contacted'] and row['last_time_contacted'] > 0:
                        timestamp = row['last_time_contacted']
                        if timestamp > 1000000000000:  # Convert milliseconds to seconds
                            timestamp = timestamp / 1000
                        contacto['ultimo_contacto'] = datetime.datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
                    else:
                        contacto['ultimo_contacto'] = 'Nunca'
                    
                    resultados['contactos'].append(contacto)
            else:
                print("❌ Tabla raw_contacts no encontrada")
        except Exception as e:
            print(f"⚠️ Error al analizar contactos: {e}")
        
        # Extract phone numbers
        try:
            if 'data' in tablas:
                cursor.execute("""
                    SELECT data.raw_contact_id, data.data1 AS phone_number,
                    data.data2 AS phone_type, data.data3 AS phone_label
                    FROM data JOIN mimetypes ON data.mimetype_id = mimetypes._id
                    WHERE mimetypes.mimetype = 'vnd.android.cursor.item/phone_v2'
                """)
                
                phone_types = {
                    1: 'Casa', 2: 'Móvil', 3: 'Trabajo', 4: 'Fax trabajo',
                    5: 'Fax casa', 6: 'Buscapersonas', 7: 'Otro', 8: 'Personalizado'
                }
                
                for row in cursor.fetchall():
                    tipo_numero = phone_types.get(row['phone_type'], 'Desconocido')
                    if row['phone_type'] == 8 and row['phone_label']:
                        tipo_numero = row['phone_label']
                        
                    resultados['numeros'].append({
                        'contacto_id': row['raw_contact_id'],
                        'numero': row['phone_number'] or 'Desconocido',
                        'tipo': tipo_numero
                    })
            else:
                print("❌ Tablas de números telefónicos no encontradas")
        except Exception as e:
            print(f"⚠️ Error al analizar números telefónicos: {e}")
        
        # Extract emails
        try:
            if 'data' in tablas:
                cursor.execute("""
                    SELECT data.raw_contact_id, data.data1 AS email,
                    data.data2 AS email_type, data.data3 AS email_label
                    FROM data JOIN mimetypes ON data.mimetype_id = mimetypes._id
                    WHERE mimetypes.mimetype = 'vnd.android.cursor.item/email_v2'
                """)
                
                email_types = {
                    1: 'Casa', 2: 'Trabajo', 3: 'Otro',
                    4: 'Personalizado', 5: 'Principal'
                }
                
                for row in cursor.fetchall():
                    tipo_email = email_types.get(row['email_type'], 'Desconocido')
                    if row['email_type'] == 4 and row['email_label']:
                        tipo_email = row['email_label']
                        
                    resultados['emails'].append({
                        'contacto_id': row['raw_contact_id'],
                        'email': row['email'] or 'Desconocido',
                        'tipo': tipo_email
                    })
            else:
                print("❌ Tablas de correos electrónicos no encontradas")
        except Exception as e:
            print(f"⚠️ Error al analizar correos electrónicos: {e}")
        
        # Match phone numbers and emails with contacts
        for contacto in resultados['contactos']:
            contacto['numeros'] = [n for n in resultados['numeros'] if n['contacto_id'] == contacto['id']]
            contacto['emails'] = [e for e in resultados['emails'] if e['contacto_id'] == contacto['id']]
        
        conn.close()
        
    except sqlite3.Error as e:
        print(f"❌ Error de SQLite: {e}")
    except Exception as e:
        print(f"❌ Error inesperado: {e}")
    
    return resultados

def analizar_archivos_especiales(ruta_archivo, tipo):
    """Analiza archivos VDEX o diccionarios para extraer información de contactos"""
    resultados = {'contactos': [], 'numeros': [], 'emails': []}
    try:
        archivo_path = Path(ruta_archivo)
        if not archivo_path.exists():
            return resultados
            
        print(f"🔍 Analizando archivo {tipo}: {archivo_path}")
        
        # Leer el archivo
        contenido = None
        try:
            with open(archivo_path, 'r', encoding='utf-8') as f:
                contenido = f.read()
        except UnicodeDecodeError:
            with open(archivo_path, 'rb') as f:
                contenido_bin = f.read()
                for encoding in ['utf-16', 'latin-1', 'cp1252']:
                    try:
                        contenido = contenido_bin.decode(encoding, errors='ignore')
                        break
                    except: pass
                if not contenido:
                    contenido = contenido_bin.decode('utf-8', errors='ignore')
        
        if not contenido:
            return resultados
        
        # Buscar patrones
        patrones_email = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', contenido)
        patrones_telefono = re.findall(r'(\+?[0-9]{7,15})', contenido)
        
        # ID base para evitar colisiones
        id_base = 20000 if tipo == "Dict" else 10000
        
        # Agregar números encontrados
        for i, numero in enumerate(set(patrones_telefono)):
            if len(numero) > 6:
                contact_id = id_base + i
                resultados['numeros'].append({
                    'contacto_id': contact_id,
                    'numero': numero,
                    'tipo': f'Extraído de {tipo}'
                })
                
        # Agregar correos encontrados
        for i, email in enumerate(set(patrones_email)):
            if '@' in email and '.' in email:
                contact_id = id_base + len(patrones_telefono) + i
                resultados['emails'].append({
                    'contacto_id': contact_id,
                    'email': email,
                    'tipo': f'Extraído de {tipo}'
                })
        
        print(f"✅ Extraídos del {tipo}: {len(resultados['numeros'])} números, {len(resultados['emails'])} emails")
            
    except Exception as e:
        print(f"❌ Error analizando {tipo}: {e}")
    
    return resultados

def merge_resultados(resultados_lista):
    """Combina resultados de múltiples fuentes eliminando duplicados"""
    resultados_combinados = {'contactos': [], 'numeros': [], 'emails': []}
    
    # Combinar todos los resultados
    for res in resultados_lista:
        resultados_combinados['contactos'].extend(res['contactos'])
        resultados_combinados['numeros'].extend(res['numeros'])
        resultados_combinados['emails'].extend(res['emails'])
    
    # Eliminar duplicados por nombre
    contactos_unicos = {}
    for contacto in resultados_combinados['contactos']:
        key = contacto['nombre'].lower()
        if key not in contactos_unicos or contacto['veces_contactado'] > contactos_unicos[key]['veces_contactado']:
            contactos_unicos[key] = contacto
    
    resultados_combinados['contactos'] = list(contactos_unicos.values())
    
    return resultados_combinados

def generar_html_contactos(resultados, ruta_salida):
    """Genera un archivo HTML con el análisis de contactos de Android"""
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception as e:
            print(f"❌ Error creando carpeta: {e}")
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())

    # Preparar datos
    resultados['contactos'].sort(key=lambda x: x['nombre'].lower())
    
    # Eliminar duplicados en números y emails
    numeros_unicos = {}
    for numero in resultados['numeros']:
        key = numero['numero'].strip()
        if key and key not in numeros_unicos:
            numeros_unicos[key] = numero
    numeros_ordenados = sorted(numeros_unicos.values(), key=lambda x: x['numero'])
    
    emails_unicos = {}
    for email in resultados['emails']:
        key = email['email'].strip().lower()
        if key and key not in emails_unicos:
            emails_unicos[key] = email
    emails_ordenados = sorted(emails_unicos.values(), key=lambda x: x['email'].lower())

    # Generar CSS
    css = """
        :root {
        --primary: #34495e;
        --primary-dark: #2c3e50;
        --primary-light: #4a6278;
        --accent: #3498db;
        --accent-light: #5dade2;
        --text: #ecf0f1;
        --text-secondary: #bdc3c7;
        --background: #1a1a2e;
        --card-bg: #16213e;
        --border-color: rgba(255, 255, 255, 0.1);
    }
    body {font-family: 'Roboto', sans-serif; background: var(--background); color: var(--text); margin: 0; padding: 0;}
    .container {max-width: 1200px; margin: 2rem auto; padding: 1rem;}
    .header {text-align: center; margin-bottom: 2rem;}
    .title {font-size: 2rem; font-weight: 700; margin-bottom: 0.5rem; color: var(--accent);}
    .subtitle {color: var(--text-secondary); margin-bottom: 1.5rem;}
    .data-container {display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;}
    .section-title {grid-column: 1/-1; font-size: 1.5rem; color: var(--accent); margin: 1rem 0; padding-bottom: 0.5rem; border-bottom: 2px solid var(--border-color);}
    .card {background: var(--card-bg); border-radius: 8px; padding: 1rem; box-shadow: 0 2px 10px rgba(0,0,0,0.2); transition: all 0.3s ease;}
    .card:hover {transform: translateY(-5px); box-shadow: 0 5px 15px rgba(0,0,0,0.3);}
    .contact-header {display: flex; align-items: center; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 1px solid var(--border-color);}
    .avatar {width: 40px; height: 40px; border-radius: 50%; background: var(--primary); color: var(--text); display: flex; align-items: center; justify-content: center; font-size: 1.2rem; font-weight: 500; margin-right: 1rem;}
    .contact-name {font-size: 1.2rem; font-weight: 500;}
    .contact-source {font-size: 0.8rem; color: var(--text-secondary);}
    .item {display: flex; align-items: center; margin-bottom: 0.7rem; padding: 0.5rem; border-radius: 4px;}
    .phone-item {background: rgba(52, 152, 219, 0.15);}
    .email-item {background: rgba(74, 98, 120, 0.15);}
    .icon {margin-right: 0.7rem; font-size: 1.2rem;}
    .phone-icon {color: var(--accent);}
    .email-icon {color: var(--primary-light);}
    .value {font-weight: 500; flex-grow: 1;}
    .tag {font-size: 0.8rem; padding: 0.2rem 0.5rem; border-radius: 12px; color: var(--text);}
    .phone-tag {background: var(--accent);}
    .email-tag {background: var(--primary-light);}
    .meta {font-size: 0.8rem; color: var(--text-secondary); display: flex; justify-content: space-between; margin-top: 1rem; padding-top: 0.5rem; border-top: 1px solid var(--border-color);}
    .search {width: 100%; padding: 0.8rem; margin-bottom: 1.5rem; border-radius: 4px; border: 1px solid var(--border-color); background: var(--primary-dark); color: var(--text); font-size: 1rem;}
    .search::placeholder {color: var(--text-secondary);}
    .tabs {display: flex; justify-content: center; margin-bottom: 2rem;}
    .tab {padding: 0.8rem 1.5rem; background: var(--primary-dark); border-radius: 4px; margin: 0 0.5rem; cursor: pointer; transition: all 0.3s ease; color: var(--text-secondary);}
    .tab:hover, .tab.active {background: var(--accent); color: var(--text);}
    .tab-content {display: none;}
    .tab-content.active {display: block;}
    .no-data {text-align:center; padding:2rem; background:var(--card-bg); border-radius:8px; grid-column:1/-1; color: var(--text-secondary);}
    .footer {text-align:center; margin-top:2rem; color:var(--text-secondary); font-size:0.9rem;}
    """

    # Comenzar HTML
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda de Contactos Android | Android Contacts</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>{css}</style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">📱 Agenda de Contactos Android</h1>
            <p class="subtitle">📅 Generado el {ahora}</p>
        </div>
        
        <div class="tabs">
            <div class="tab active" onclick="changeTab('contacts-tab')">👤 Contactos</div>
            <div class="tab" onclick="changeTab('phones-tab')">📱 Números</div>
            <div class="tab" onclick="changeTab('emails-tab')">✉️ Emails</div>
        </div>
        
        <div id="contacts-tab" class="tab-content active">
            <input type="text" class="search" id="search-contacts" placeholder="Buscar contactos..." 
                onkeyup="filterItems('contacts')">
            
            <div class="data-container" id="contacts-container">
    """
    
    # Añadir contactos
    if resultados['contactos']:
        for contacto in resultados['contactos']:
            iniciales = "".join([palabra[0].upper() for palabra in contacto['nombre'].split() if palabra])[:2] if contacto['nombre'] else "?"
            
            html += f"""
            <div class="card" data-search="{contacto['nombre'].lower()}">
                <div class="contact-header">
                    <div class="avatar" style="background-color: hsl({hash(contacto['nombre']) % 360}, 70%, 65%);">{iniciales}</div>
                    <div>
                        <div class="contact-name">{contacto['nombre']}</div>
                        <div class="contact-source">{contacto['cuenta']} ({contacto['tipo_cuenta']})</div>
                    </div>
                </div>
            """
            
            # Añadir números
            if contacto.get('numeros'):
                for numero in contacto['numeros']:
                    html += f"""
                    <div class="item phone-item">
                        <div class="icon phone-icon">📱</div>
                        <div class="value">{numero['numero']}</div>
                        <div class="tag phone-tag">{numero['tipo']}</div>
                    </div>
                    """
            
            # Añadir emails
            if contacto.get('emails'):
                for email in contacto['emails']:
                    html += f"""
                    <div class="item email-item">
                        <div class="icon email-icon">✉️</div>
                        <div class="value">{email['email']}</div>
                        <div class="tag email-tag">{email['tipo']}</div>
                    </div>
                    """
                    
            html += f"""
                <div class="meta">
                    <div>Veces contactado: {contacto['veces_contactado']}</div>
                    <div>Último: {contacto['ultimo_contacto']}</div>
                </div>
            </div>
            """
    else:
        html += '<div class="no-data"><h3>❌ No se encontraron contactos</h3></div>'
    
    html += '</div></div>'  # Cierre de contacts-tab
    
    # Pestaña de números telefónicos
    html += """
    <div id="phones-tab" class="tab-content">
        <input type="text" class="search" id="search-phones" placeholder="Buscar números..." 
            onkeyup="filterItems('phones')">
        
        <div class="data-container" id="phones-container">
            <h2 class="section-title">📱 Todos los Números Telefónicos</h2>
    """
    
    # Añadir todos los números
    if numeros_ordenados:
        for numero in numeros_ordenados:
            # Buscar el contacto asociado
            contacto_asociado = next((c for c in resultados['contactos'] if c['id'] == numero['contacto_id']), None)
            nombre_contacto = contacto_asociado['nombre'] if contacto_asociado else "Desconocido"
            
            html += f"""
            <div class="card" data-search="{numero['numero']}">
                <div class="item phone-item">
                    <div class="icon phone-icon">📱</div>
                    <div class="value">{numero['numero']}</div>
                    <div class="tag phone-tag">{numero['tipo']}</div>
                </div>
                <div class="meta">
                    <div>Contacto: {nombre_contacto}</div>
                </div>
            </div>
            """
    else:
        html += '<div class="no-data"><h3>❌ No se encontraron números</h3></div>'
    
    html += '</div></div>'  # Cierre de phones-tab
    
    # Pestaña de correos electrónicos
    html += """
    <div id="emails-tab" class="tab-content">
        <input type="text" class="search" id="search-emails" placeholder="Buscar emails..." 
            onkeyup="filterItems('emails')">
        
        <div class="data-container" id="emails-container">
            <h2 class="section-title">✉️ Todos los Correos Electrónicos</h2>
    """
    
    # Añadir todos los correos
    if emails_ordenados:
        for email in emails_ordenados:
            # Buscar el contacto asociado
            contacto_asociado = next((c for c in resultados['contactos'] if c['id'] == email['contacto_id']), None)
            nombre_contacto = contacto_asociado['nombre'] if contacto_asociado else "Desconocido"
            
            html += f"""
            <div class="card" data-search="{email['email'].lower()}">
                <div class="item email-item">
                    <div class="icon email-icon">✉️</div>
                    <div class="value">{email['email']}</div>
                    <div class="tag email-tag">{email['tipo']}</div>
                </div>
                <div class="meta">
                    <div>Contacto: {nombre_contacto}</div>
                </div>
            </div>
            """
    else:
        html += '<div class="no-data"><h3>❌ No se encontraron emails</h3></div>'
    
    # Cerrar HTML
    html += f"""
        </div>
    </div>
        
    <div class="footer">
        <p>📁 Ruta: <code>{ruta_str}</code></p>
        <p>📊 Total: {len(resultados['contactos'])} contactos, {len(numeros_ordenados)} números, {len(emails_ordenados)} emails</p>
    </div>
    </div>

    <script>
    function changeTab(tabId) {{
        // Ocultar todos los tabs
        document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        
        // Mostrar el tab seleccionado
        document.getElementById(tabId).classList.add('active');
        document.querySelector(`.tab[onclick="changeTab('${{tabId}}')"]`).classList.add('active');
     }}
    
    function filterItems(type) {{
        const input = document.getElementById(`search-${type}`);
        const filter = input.value.toUpperCase();
        const container = document.getElementById(`${type}-container`);
        const items = container.getElementsByClassName('card');
        
        for (let i = 0; i < items.length; i++) {{
            const searchText = items[i].getAttribute('data-search');
            if (searchText && searchText.toUpperCase().indexOf(filter) > -1) {{
                items[i].style.display = "";
            }} else {{
                items[i].style.display = "none";
            }}
        }}
    }}
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
    except Exception as e:
        print(f"❌ Error guardando HTML: {e}")

def main():
    base_path = Path.home() / "ForenSage" / "results"
    paths = {
        'db1': Path.home() / "ForenSage" / "analyze" / "android" / "data" / "data" / "com.android.providers.contacts" / "databases" / "contacts2.db",
        'db2': Path.home() / "ForenSage" / "analyze" / "android" / "data" / "data" / "com.google.android.contacts" / "databases" / "contacts.db",
        'vdex': Path.home() / "ForenSage" / "analyze" / "android" / "product" / "app" / "GoogleContacts" / "oat" / "arm64" / "GoogleContacts.vdex",
        'dict': Path.home() / "ForenSage" / "analyze" / "android" / "data" / "data" / "com.google.android.inputmethod.latin" / "files" / "personal" / "Contacts.dict"
    }
    salida_html = base_path / "contacts_analysis.html"
    
    # Lista para almacenar resultados
    todos_resultados = []
    
    # Analizar bases de datos
    for db_key in ['db1', 'db2']:
        if paths[db_key].exists():
            resultados = analizar_db_contactos(paths[db_key])
            todos_resultados.append(resultados)
    
    # Analizar archivos especiales
    for key, tipo in [('vdex', 'VDEX'), ('dict', 'Dict')]:
        if paths[key].exists():
            resultados = analizar_archivos_especiales(paths[key], tipo)
            todos_resultados.append(resultados)
    
    # Combinar resultados
    resultados_combinados = merge_resultados(todos_resultados)
    
    # Resumen final
    print(f"👥 Total de contactos: {len(resultados_combinados['contactos'])}")
    print(f"📱 Total de números: {len(resultados_combinados['numeros'])}")
    print(f"✉️ Total de emails: {len(resultados_combinados['emails'])}")
    
    # Generar informe HTML
    {generar_html_contactos(resultados_combinados, salida_html)}

if __name__ == "__main__":
    main()



