import os
from pathlib import Path
import datetime
import sqlite3
import json

def analizar_db_whatsapp(ruta_db):
    """Analiza la base de datos de WhatsApp y extrae información básica"""
    resultados = {'mensajes': [], 'contactos': [], 'multimedia': []}
    try:
        # Verify that the file exists/Verificar que el archivo existe
        db_path = Path(ruta_db)
        if not db_path.exists():
            print(f"❌ Base de datos no encontrada: {db_path}")
            return resultados
            
        # Connect to the database/Conectar a la base de datos
        conn = sqlite3.connect(ruta_db)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = [tabla['name'] for tabla in cursor.fetchall()]
        print(f"📊 Tablas encontradas: {', '.join(tablas)}")
        
       
        for tabla in tablas:
            if 'message' in tabla.lower() or 'msg' in tabla.lower():
                try:
                    cursor.execute(f"PRAGMA table_info({tabla})")
                    columnas = [info[1] for info in cursor.fetchall()]
                    
                    select_cols = []
                    id_col = next((col for col in columnas if 'id' in col.lower() or '_key' in col.lower()), None)
                    if id_col: select_cols.append(id_col)
                    
                    chat_col = next((col for col in columnas if 'chat' in col.lower() or 'jid' in col.lower()), None)
                    if chat_col: select_cols.append(chat_col)
                    
                    sender_col = next((col for col in columnas if 'sender' in col.lower() or 'from' in col.lower()), None)
                    if sender_col: select_cols.append(sender_col)
                    
                    text_col = next((col for col in columnas if 'text' in col.lower() or 'data' in col.lower() or 'content' in col.lower()), None)
                    if text_col: select_cols.append(text_col)
                    
                    time_col = next((col for col in columnas if 'time' in col.lower() or 'date' in col.lower() or 'sent' in col.lower()), None)
                    if time_col: select_cols.append(time_col)
                    
                    media_col = next((col for col in columnas if 'media' in col.lower() or 'type' in col.lower()), None)
                    if media_col: select_cols.append(media_col)
                    
                    if select_cols:
                        query = f"SELECT {', '.join(select_cols)} FROM {tabla}"
                        if time_col:
                            query += f" ORDER BY {time_col} DESC"
                        query += " LIMIT 500"
                        
                        cursor.execute(query)
                        for row in cursor.fetchall():
                            msg = {}
                            if id_col: msg['id'] = row[id_col]
                            if chat_col: msg['chat_id'] = row[chat_col]
                            if sender_col: msg['sender_id'] = row[sender_col]
                            if text_col: msg['texto'] = row[text_col] if row[text_col] else "(Sin texto)"
                            
                            if time_col:
                                try:
                                    time_val = row[time_col]
                                    if isinstance(time_val, int) and time_val > 1000000000:
                                        msg['fecha'] = datetime.datetime.fromtimestamp(
                                            time_val/1000 if time_val > 1000000000000 else time_val
                                        ).strftime('%Y-%m-%d %H:%M:%S')
                                    else:
                                        msg['fecha'] = str(time_val)
                                except:
                                    msg['fecha'] = 'Desconocido'
                            
                            if media_col: msg['tipo_medio'] = row[media_col] if row[media_col] else 'text'
                            
                            resultados['mensajes'].append(msg)
                except Exception as e:
                    print(f"⚠️ Error al analizar tabla {tabla}: {e}")
            
            # Extract contacts/Extraer contactos    
            elif 'contact' in tabla.lower() or 'user' in tabla.lower():
                try:
                    cursor.execute(f"PRAGMA table_info({tabla})")
                    columnas = [info[1] for info in cursor.fetchall()]
                    
                    id_col = next((col for col in columnas if 'jid' in col.lower() or 'id' in col.lower()), None)
                    name_col = next((col for col in columnas if 'name' in col.lower() or 'display' in col.lower()), None)
                    phone_col = next((col for col in columnas if 'phone' in col.lower() or 'number' in col.lower()), None)
                    
                    if id_col:
                        select_cols = [id_col]
                        if name_col: select_cols.append(name_col)
                        if phone_col: select_cols.append(phone_col)
                        
                        cursor.execute(f"SELECT {', '.join(select_cols)} FROM {tabla} LIMIT 500")
                        for row in cursor.fetchall():
                            contact = {'jid': row[id_col]}
                            if name_col: 
                                contact['nombre'] = row[name_col] or 'Desconocido'
                            else:
                                contact['nombre'] = 'Desconocido'
                                
                            if phone_col: 
                                contact['telefono'] = row[phone_col] or 'Desconocido'
                            else:
                                contact['telefono'] = 'Desconocido'
                                
                            resultados['contactos'].append(contact)
                except Exception as e:
                    print(f"⚠️ Error al analizar tabla de contactos {tabla}: {e}")
            
            elif 'media' in tabla.lower() or 'file' in tabla.lower() or 'attach' in tabla.lower():
                try:
                    cursor.execute(f"PRAGMA table_info({tabla})")
                    columnas = [info[1] for info in cursor.fetchall()]
                    
                    select_cols = []
                    msg_id_col = next((col for col in columnas if ('message' in col.lower() and 'id' in col.lower()) or 'mid' in col.lower()), None)
                    if msg_id_col: select_cols.append(msg_id_col)
                    
                    type_col = next((col for col in columnas if 'mime' in col.lower() or 'type' in col.lower()), None)
                    if type_col: select_cols.append(type_col)
                    
                    name_col = next((col for col in columnas if 'name' in col.lower() or 'title' in col.lower()), None)
                    if name_col: select_cols.append(name_col)
                    
                    path_col = next((col for col in columnas if 'path' in col.lower() or 'url' in col.lower() or 'location' in col.lower()), None)
                    if path_col: select_cols.append(path_col)
                    
                    size_col = next((col for col in columnas if 'size' in col.lower() or 'length' in col.lower()), None)
                    if size_col: select_cols.append(size_col)
                        
                    if select_cols:
                        cursor.execute(f"SELECT {', '.join(select_cols)} FROM {tabla} LIMIT 500")
                        for row in cursor.fetchall():
                            media = {}
                            if msg_id_col: media['message_id'] = row[msg_id_col]
                            if type_col: media['tipo'] = row[type_col] or 'Desconocido'
                            if name_col: media['nombre'] = row[name_col] or 'Sin nombre'
                            if path_col: media['ruta'] = row[path_col] or 'Desconocido'
                            
                            if size_col:
                                try:
                                    size_val = row[size_col]
                                    if isinstance(size_val, (int, float)) and size_val > 0:
                                        media['tamaño'] = f"{size_val/1024:.2f} KB"
                                    else:
                                        media['tamaño'] = str(size_val)
                                except:
                                    media['tamaño'] = 'Desconocido'
                                    
                            resultados['multimedia'].append(media)
                except Exception as e:
                    print(f"⚠️ Error al analizar tabla multimedia {tabla}: {e}")
        
        conn.close()
        
    except sqlite3.Error as e:
        print(f"❌ Error de SQLite: {e}")
    except Exception as e:
        print(f"❌ Error inesperado: {e}")
    
    return resultados

def generar_html_whatsapp(resultados, ruta_salida):
    """Genera un archivo HTML con el análisis de WhatsApp"""
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception as e:
            print(f"❌ Error creando carpeta: {e}")
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())

    # Generate HTML header with styles / Generar cabecera HTML con estilos
    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WhatsApp Report | Informe WhatsApp </title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #075E54;
            --primary: #128C7E;
            --primary-light: #25D366;
            --accent: #34B7F1;
            --accent-light: #5DCDFF;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
        }}
        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}
        .container {{max-width: 1200px; margin: 2rem auto; padding: 2rem; animation: fadeIn 0.7s;}}
        .header {{text-align: center; margin-bottom: 3rem;}}
        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}
        .subtitle {{color: var(--text-secondary); margin-bottom: 2rem;}}
        .report-card {{
            background-color: var(--card-bg);
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            margin-bottom: 2rem;
        }}
        .tabs {{display: flex; margin-bottom: 1rem; overflow-x: auto; scrollbar-width: thin;}}
        .tab {{
            padding: 0.8rem 1.5rem;
            cursor: pointer;
            border-radius: 8px 8px 0 0;
            background-color: var(--primary-dark);
            margin-right: 0.5rem;
            transition: all 0.3s ease;
            white-space: nowrap;
        }}
        .tab.active {{background-color: var(--primary);}}
        .tab:hover {{background-color: var(--primary-light);}}
        .tab-content {{display: none; animation: fadeIn 0.5s;}}
        .tab-content.active {{display: block;}}
        .data-table {{width: 100%; border-collapse: collapse; margin-top: 1rem;}}
        .data-table th {{
            background-color: var(--primary);
            color: var(--text);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
        }}
        .data-table td {{padding: 1rem; border-bottom: 1px solid var(--border-color); vertical-align: top;}}
        .data-table tr:nth-child(even) {{background-color: rgba(52, 152, 219, 0.05);}}
        .data-table tr:hover {{background-color: var(--primary-light); color: var(--background);}}
        .section-header {{display: flex; align-items: center; margin-bottom: 1rem;}}
        .section-icon {{font-size: 1.5rem; margin-right: 1rem;}}
        .section-title {{font-weight: 600; color: var(--accent-light);}}
        .item-count {{
            margin-left: auto;
            background-color: var(--primary);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.9rem;
        }}
        .message {{
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
            background-color: var(--primary-dark);
            position: relative;
        }}
        .message-header {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            color: var(--accent-light);
            font-weight: 600;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.5rem;
        }}
        .message-content {{word-break: break-word;}}
        .message-media {{color: var(--accent); font-style: italic;}}
        .message-timestamp {{font-size: 0.8rem; color: var(--text-secondary); text-align: right; margin-top: 0.5rem;}}
        .footer {{text-align: center; margin-top: 2rem; color: var(--text-secondary); font-size: 0.9rem;}}
        .search-box {{
            width: 100%;
            padding: 0.8rem;
            margin-bottom: 1rem;
            border-radius: 8px;
            border: 1px solid var(--primary-light);
            background-color: var(--card-bg);
            color: var(--text);
        }}
        @keyframes fadeIn {{from {{opacity: 0; transform: translateY(20px);}} to {{opacity: 1; transform: translateY(0);}}
        @media (max-width: 768px) {{
            .container {{padding: 1rem;}}
            .title {{font-size: 2rem;}}
            .message-header {{flex-direction: column;}}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title"> WhatsApp Report | Informe WhatsApp </h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
        </div>
        
        <div class="report-card">
            <div class="tabs">
                <div class="tab active" onclick="openTab('mensajes')">💬 Mensajes ({len(resultados['mensajes'])})</div>
                <div class="tab" onclick="openTab('contactos')">👥 Contactos ({len(resultados['contactos'])})</div>
                <div class="tab" onclick="openTab('multimedia')">🖼️ Multimedia ({len(resultados['multimedia'])})</div>
            </div>
    """
    html += f"""
            <div id="mensajes" class="tab-content active">
                <div class="section-header">
                    <div class="section-icon">💬</div>
                    <div class="section-title">Mensajes | Messages</div>
                    <div class="item-count">{len(resultados['mensajes'])} encontrados</div>
                </div>
                
                <input type="text" class="search-box" id="search-messages" placeholder="Buscar mensajes..." 
                       onkeyup="searchItems('search-messages', 'message')">
                
                <div class="messages-container">
    """

    if resultados['mensajes']:
        for i, mensaje in enumerate(resultados['mensajes'][:50]):
            html += f"""
                    <div class="message">
                        <div class="message-header">
                            <span>De: {mensaje.get('sender_id', 'Desconocido')}</span>
                            <span>Chat: {mensaje.get('chat_id', 'Desconocido')}</span>
                        </div>
                        <div class="message-content">{mensaje.get('texto', '(Sin texto)')}</div>
                        """
            if mensaje.get('tipo_medio') and mensaje.get('tipo_medio') != 'text':
                html += f"""<div class="message-media">📎 Medio: {mensaje.get('tipo_medio', 'Desconocido')}</div>"""
            html += f"""<div class="message-timestamp">{mensaje.get('fecha', 'Desconocido')}</div>
                    </div>"""
    else:
        html += """<div style="text-align: center; padding: 2rem;">❌ No se encontraron mensajes</div>"""
    
    html += """
                </div>
            </div>
    """

    html += f"""
            <div id="contactos" class="tab-content">
                <div class="section-header">
                    <div class="section-icon">👥</div>
                    <div class="section-title">Contactos | Contacts</div>
                    <div class="item-count">{len(resultados['contactos'])} encontrados</div>
                </div>
                
                <input type="text" class="search-box" id="search-contacts" placeholder="Buscar contactos..." 
                       onkeyup="searchTable('search-contacts', 'contacts-table')">
                
                <table id="contacts-table" class="data-table">
                    <thead>
                        <tr>
                            <th>📱 JID / ID</th>
                            <th>👤 Nombre</th>
                            <th>☎️ Teléfono</th>
                        </tr>
                    </thead>
                    <tbody>
    """

    if resultados['contactos']:
        for contacto in resultados['contactos']:
            html += f"""
                        <tr>
                            <td>{contacto.get('jid', 'Desconocido')}</td>
                            <td>{contacto.get('nombre', 'Desconocido')}</td>
                            <td>{contacto.get('telefono', 'Desconocido')}</td>
                        </tr>"""
    else:
        html += """
                        <tr>
                            <td colspan="3" style="text-align: center;">❌ No se encontraron contactos</td>
                        </tr>"""
    
    html += """
                    </tbody>
                </table>
            </div>
    """

    html += f"""
            <div id="multimedia" class="tab-content">
                <div class="section-header">
                    <div class="section-icon">🖼️</div>
                    <div class="section-title">Multimedia | Media</div>
                    <div class="item-count">{len(resultados['multimedia'])} encontrados</div>
                </div>
                
                <input type="text" class="search-box" id="search-media" placeholder="Buscar multimedia..." 
                       onkeyup="searchTable('search-media', 'media-table')">
                
                <table id="media-table" class="data-table">
                    <thead>
                        <tr>
                            <th>📄 Nombre</th>
                            <th>📁 Tipo</th>
                            <th>📏 Tamaño</th>
                            <th>🔗 Ruta</th>
                        </tr>
                    </thead>
                    <tbody>
    """

    if resultados['multimedia']:
        for media in resultados['multimedia']:
            html += f"""
                        <tr>
                            <td>{media.get('nombre', 'Sin nombre')}</td>
                            <td>{media.get('tipo', 'Desconocido')}</td>
                            <td>{media.get('tamaño', 'Desconocido')}</td>
                            <td>{media.get('ruta', 'Desconocido')}</td>
                        </tr>"""
    else:
        html += """
                        <tr>
                            <td colspan="4" style="text-align: center;">❌ No se encontraron archivos multimedia</td>
                        </tr>"""
    
    html += f"""
                    </tbody>
                </table>
            </div>
        </div>

        <div class="footer">
            <p>📁 Ruta del informe: <code>{ruta_str}</code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        // Función para cambiar de pestaña
        function openTab(tabName) {{
            var i, tabContent, tabLinks;
            
            // Ocultar contenidos
            tabContent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabContent.length; i++) {{
                tabContent[i].className = tabContent[i].className.replace(" active", "");
            }}
            
            // Desactivar botones
            tabLinks = document.getElementsByClassName("tab");
            for (i = 0; i < tabLinks.length; i++) {{
                tabLinks[i].className = tabLinks[i].className.replace(" active", "");
            }}
            
            // Activar seleccionado
            document.getElementById(tabName).className += " active";
            for (i = 0; i < tabLinks.length; i++) {{
                if (tabLinks[i].textContent.includes(tabName.charAt(0).toUpperCase() + tabName.slice(1))) {{
                    tabLinks[i].className += " active";
                }}
            }}
        }}
        
        // Buscar en mensajes
        function searchItems(inputId, itemClass) {{
            var input = document.getElementById(inputId);
            var filter = input.value.toUpperCase();
            var items = document.getElementsByClassName(itemClass);
            
            for (var i = 0; i < items.length; i++) {{
                var content = items[i].textContent || items[i].innerText;
                if (content.toUpperCase().indexOf(filter) > -1) {{
                    items[i].style.display = "";
                }} else {{
                    items[i].style.display = "none";
                }}
            }}
        }}
        
        // Buscar en tablas
        function searchTable(inputId, tableId) {{
            var input = document.getElementById(inputId);
            var filter = input.value.toUpperCase();
            var table = document.getElementById(tableId);
            var tr = table.getElementsByTagName("tr");
            
            for (var i = 1; i < tr.length; i++) {{
                var found = false;
                var td = tr[i].getElementsByTagName("td");
                
                for (var j = 0; j < td.length; j++) {{
                    var cell = td[j];
                    if (cell) {{
                        var content = cell.textContent || cell.innerText;
                        if (content.toUpperCase().indexOf(filter) > -1) {{
                            found = true;
                            break;
                        }}
                    }}
                }}
                
                if (found) {{
                    tr[i].style.display = "";
                }} else {{
                    tr[i].style.display = "none";
                }}
            }}
        }}
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
    except Exception as e:
        print(f"❌ Error guardando HTML: {e}")

def main():
    base_path = Path.home() / "ForenSage" / "results"
    db_path = Path.home() / "ForenSage" / "analyze" / "android" / "data" / "data" / "com.whatsapp" / "databases" / "msgstore.db"
    salida_html = base_path / "and_whatsapp_info.html"
    
    print(f"🔍 Analizando base de datos WhatsApp: {db_path}")
    if not db_path.exists():
        print(f"❌ Base de datos no encontrada: {db_path}")
        return
        
    resultados = analizar_db_whatsapp(db_path)
    
    # Summary of results/Resumen de resultados
    print(f"📊 Mensajes encontrados: {len(resultados['mensajes'])}")
    print(f"👥 Contactos encontrados: {len(resultados['contactos'])}")
    print(f"🖼️ Archivos multimedia encontrados: {len(resultados['multimedia'])}")
    
    generar_html_whatsapp(resultados, salida_html)

if __name__ == "__main__":
    main()