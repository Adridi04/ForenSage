import os
import sqlite3
import datetime
from pathlib import Path
import sys

def analizar_location_db(ruta_archivo):
    """
    Analiza el archivo cache_encryptedB.db de iOS y extrae la información de ubicaciones.
    / Analyzes iOS cache_encryptedB.db file and extracts location information.
    """
    resultados = []
    file_exists = os.path.exists(ruta_archivo)
    
    print(f"Verificando archivo: {ruta_archivo}")
    print(f"El archivo existe: {file_exists}")
    
    if not file_exists:
        return resultados, file_exists
            
    try:
        print("Intentando conectar a la base de datos...")
        # Conectar a la base de datos SQLite / Connect to SQLite database
        conn = sqlite3.connect(ruta_archivo)
        cursor = conn.cursor()
        
        # Obtener lista de tablas / Get list of tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = cursor.fetchall()
        tablas_nombres = [tabla[0] for tabla in tablas]
        
        print(f"Tablas encontradas: {tablas_nombres}")
        
        # Intentar extraer datos de ubicación / Try to extract location data
        location_tables = [tabla for tabla in tablas_nombres if 'Location' in tabla or 'location' in tabla]
        
        print(f"Tablas de ubicación encontradas: {location_tables}")
        
        if location_tables:
            for tabla in location_tables:
                # Obtener información de las columnas de la tabla
                cursor.execute(f"PRAGMA table_info({tabla});")
                columnas = cursor.fetchall()
                columnas_nombres = [col[1] for col in columnas]
                
                print(f"Columnas en tabla {tabla}: {columnas_nombres}")
                
                # Verificar si existen las columnas de latitud y longitud
                lat_col = next((col for col in columnas_nombres if 'lat' in col.lower()), None)
                lon_col = next((col for col in columnas_nombres if 'lon' in col.lower() or 'lng' in col.lower()), None)
                
                print(f"Columna de latitud: {lat_col}, Columna de longitud: {lon_col}")
                
                if lat_col and lon_col:
                    # Columnas básicas que buscaremos - pueden variar según la estructura de la BD
                    base_cols = [lat_col, lon_col]
                    
                    # Columnas opcionales que podemos buscar
                    opt_cols = {
                        'alt': next((col for col in columnas_nombres if 'alt' in col.lower()), None),
                        'time': next((col for col in columnas_nombres if 'time' in col.lower() or 'date' in col.lower()), None),
                        'accuracy': next((col for col in columnas_nombres if 'acc' in col.lower()), None),
                        'speed': next((col for col in columnas_nombres if 'speed' in col.lower()), None),
                        'course': next((col for col in columnas_nombres if 'course' in col.lower() or 'direction' in col.lower()), None)
                    }
                    
                    # Construir consulta SQL dinámica
                    query_cols = base_cols + [col for col in opt_cols.values() if col]
                    query = f"SELECT {', '.join(query_cols)} FROM {tabla} LIMIT 10000;"
                    
                    print(f"Ejecutando consulta: {query}")
                    
                    cursor.execute(query)
                    rows = cursor.fetchall()
                    
                    print(f"Filas recuperadas: {len(rows)}")
                    
                    for row in rows:
                        location_data = {
                            'Latitude': row[0],  # Latitud es siempre la primera columna
                            'Longitude': row[1]  # Longitud es siempre la segunda columna
                        }
                        
                        # Añadir datos opcionales si existen
                        col_index = 2
                        for opt_name, opt_col in opt_cols.items():
                            if opt_col and col_index < len(row):
                                location_data[opt_name.capitalize()] = row[col_index]
                                col_index += 1
                        
                        resultados.append(location_data)
        
        # Si no se encontraron tablas de ubicación estándar, buscar en otras tablas comunes
        if not resultados:
            print("No se encontraron datos en tablas estándar. Buscando en tablas comunes...")
            common_tables = ['CellLocation', 'WifiLocation', 'Visits', 'SignificantLocations']
            for tabla in common_tables:
                if tabla in tablas_nombres:
                    cursor.execute(f"PRAGMA table_info({tabla});")
                    columnas = cursor.fetchall()
                    columnas_nombres = [col[1] for col in columnas]
                    
                    lat_col = next((col for col in columnas_nombres if 'lat' in col.lower()), None)
                    lon_col = next((col for col in columnas_nombres if 'lon' in col.lower() or 'lng' in col.lower()), None)
                    
                    if lat_col and lon_col:
                        cursor.execute(f"SELECT {lat_col}, {lon_col} FROM {tabla} LIMIT 10000;")
                        for row in cursor.fetchall():
                            resultados.append({
                                'Latitude': row[0],
                                'Longitude': row[1],
                                'Source': tabla
                            })
        
        conn.close()
        print(f"Total de ubicaciones encontradas: {len(resultados)}")
    except Exception as e:
        print(f"Error analizando {ruta_archivo}: {e}")
        # Imprime el traceback completo para mejor diagnóstico
        import traceback
        traceback.print_exc()
    
    return resultados, file_exists

def generar_html_mapa(ubicaciones, archivo_info, ruta_salida):
    """
    Genera un archivo HTML con un mapa interactivo mostrando las ubicaciones extraídas
    / Generates HTML with interactive map showing the extracted locations
    """
    print(f"Generando HTML en: {ruta_salida}")
    
    try:
        if not os.path.exists(os.path.dirname(ruta_salida)):
            try:
                os.makedirs(os.path.dirname(ruta_salida))
                print(f"Directorio creado: {os.path.dirname(ruta_salida)}")
            except Exception as e:
                print(f"Error al crear directorio: {e}")
                return False

        ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        archivo_ruta, archivo_existe = archivo_info
        
        # Preparar los datos de ubicaciones para JavaScript
        js_locations = []
        time_data = []
        
        for loc in ubicaciones:
            lat = loc.get('Latitude')
            lon = loc.get('Longitude')
            
            if not isinstance(lat, (int, float)) or not isinstance(lon, (int, float)):
                continue
                
            # Preparar propiedades para el popup
            props = {}
            for key, value in loc.items():
                if key not in ['Latitude', 'Longitude'] and value is not None:
                    # Formato especial para timestamp si existe
                    if key == 'Time' and isinstance(value, (int, float)):
                        try:
                            # Guardar timestamp para estadísticas
                            time_data.append(value)
                            # Intentar convertir timestamp a fecha legible
                            fecha = datetime.datetime.fromtimestamp(value).strftime('%Y-%m-%d %H:%M:%S')
                            props[key] = fecha
                        except:
                            props[key] = value
                    else:
                        props[key] = value
            
            # Añadir a la lista de ubicaciones para JS
            js_location = {
                "lat": lat,
                "lon": lon,
                "props": props
            }
            js_locations.append(js_location)
        
        # Calcular estadísticas
        total_locations = len(js_locations)
        
        # Calcular ubicaciones únicas (aproximado, por redondeo)
        unique_coords = set()
        for loc in js_locations:
            # Redondear a 5 decimales para agrupar ubicaciones muy cercanas
            unique_coords.add((round(loc["lat"], 5), round(loc["lon"], 5)))
        
        unique_locations = len(unique_coords)
        
        # Obtener rango de fechas si es posible
        date_range = "N/A"
        if time_data:
            try:
                earliest = datetime.datetime.fromtimestamp(min(time_data)).strftime('%Y-%m-%d')
                latest = datetime.datetime.fromtimestamp(max(time_data)).strftime('%Y-%m-%d')
                date_range = f"{earliest} - {latest}"
            except Exception as e:
                print(f"Error al procesar fechas: {e}")
        
        # Convertir la lista de ubicaciones a formato JSON para JavaScript
        import json
        js_locations_json = json.dumps(js_locations)

        html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iOS Location Information | Información de Ubicaciones</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .map-container {{
            position: relative;
            height: 600px;
            width: 100%;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
            margin-bottom: 3rem;
        }}

        #map {{
            height: 100%;
            width: 100%;
        }}

        .stats-container {{
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
            justify-content: center;
            margin-bottom: 3rem;
        }}

        .stat-card {{
            position: relative;
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 1.5rem;
            min-width: 200px;
            flex: 1;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            transition: all 0.3s ease;
            overflow: hidden;
            z-index: 1;
        }}

        .stat-card:hover {{
            transform: translateY(-10px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.6);
        }}

        .stat-card::before {{
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                0deg,
                transparent,
                transparent,
                var(--accent),
                var(--accent)
            );
            transform-origin: bottom right;
            animation: rotate 6s linear infinite;
            z-index: -1;
            opacity: 0.2;
        }}

        @keyframes rotate {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}

        .stat-value {{
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--accent-light);
            margin-bottom: 0.5rem;
        }}

        .stat-label {{
            font-size: 1rem;
            color: var(--text-secondary);
        }}

        .locations-table-container {{
            overflow-x: auto;
            margin-bottom: 3rem;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        }}

        .locations-table {{
            width: 100%;
            border-collapse: collapse;
            background-color: var(--card-bg);
        }}

        .locations-table th,
        .locations-table td {{
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }}

        .locations-table th {{
            background-color: var(--primary);
            color: var(--text);
            font-weight: 600;
        }}

        .locations-table tr:nth-child(even) {{
            background-color: rgba(255, 255, 255, 0.05);
        }}

        .locations-table tr:hover {{
            background-color: rgba(255, 255, 255, 0.1);
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .map-container {{
                height: 400px;
            }}
            .stats-container {{
                flex-direction: column;
            }}
        }}
        
        .debug-info {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--accent);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 800px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            overflow: auto;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">iOS Location Information | Información de Ubicaciones</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
        </div>"""

        if not ubicaciones:
            html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron datos | No data found</div>
            <p>No se ha podido extraer información de ubicaciones. | Could not extract location information.</p>
        </div>"""
        else:
            # Información del mapa usando Leaflet con datos embebidos
            html += f"""
        <div class="map-container">
            <div id="map"></div>
        </div>
        
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-value">{total_locations}</div>
                <div class="stat-label">Total de ubicaciones | Total locations</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{unique_locations}</div>
                <div class="stat-label">Ubicaciones únicas | Unique locations</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{date_range}</div>
                <div class="stat-label">Rango de fechas | Date range</div>
            </div>
        </div>
        
        <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
        <script>
            // Datos de ubicaciones incrustados en el HTML
            const locations = {js_locations_json};
            
            // Inicializar mapa
            var map = L.map('map').setView([0, 0], 2);
            
            // Añadir capa de mapa base
            L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }}).addTo(map);

            // Crear capa para los marcadores
            const markers = [];
            
            // Añadir marcadores al mapa
            locations.forEach(loc => {{
                const marker = L.circleMarker([loc.lat, loc.lon], {{
                    radius: 8,
                    fillColor: "#3498db",
                    color: "#fff",
                    weight: 1,
                    opacity: 1,
                    fillOpacity: 0.8
                }});
                
                // Crear contenido del popup
                let popupContent = '<div style="max-width: 300px;"><h4>Detalles de Ubicación</h4><ul>';
                popupContent += `<li><b>Latitud:</b> ${{loc.lat}}</li>`;
                popupContent += `<li><b>Longitud:</b> ${{loc.lon}}</li>`;
                
                for (const [key, value] of Object.entries(loc.props)) {{
                    popupContent += `<li><b>${{key}}:</b> ${{value}}</li>`;
                }}
                
                popupContent += '</ul></div>';
                marker.bindPopup(popupContent);
                marker.addTo(map);
                markers.push(marker);
            }});
            
            // Si hay marcadores, ajustar la vista del mapa
            if (markers.length > 0) {{
                const group = L.featureGroup(markers);
                map.fitBounds(group.getBounds());
            }}
        </script>"""
            
            # Tabla de ubicaciones (limitada a 100 para no hacer el HTML demasiado grande)
            html += """
        <h2 style="text-align: center; color: var(--accent-light);">Últimas ubicaciones registradas | Last recorded locations</h2>
        <div class="locations-table-container">
            <table class="locations-table">
                <thead>
                    <tr>
                        <th>Latitud | Latitude</th>
                        <th>Longitud | Longitude</th>
                        <th>Altitud | Altitude</th>
                        <th>Fecha/Hora | Date/Time</th>
                        <th>Precisión | Accuracy</th>
                    </tr>
                </thead>
                <tbody>"""
                    
            # Añadir filas a la tabla (limitado a 100)
            for loc in ubicaciones[:100]:
                lat = loc.get('Latitude', 'N/A')
                lon = loc.get('Longitude', 'N/A')
                alt = loc.get('Alt', loc.get('Altitude', 'N/A'))
                
                # Intentar formatear la fecha si existe
                time_val = loc.get('Time', 'N/A')
                if isinstance(time_val, (int, float)):
                    try:
                        time_val = datetime.datetime.fromtimestamp(time_val).strftime('%Y-%m-%d %H:%M:%S')
                    except:
                        pass
                
                accuracy = loc.get('Accuracy', 'N/A')
                
                html += f"""
                    <tr>
                        <td>{lat}</td>
                        <td>{lon}</td>
                        <td>{alt}</td>
                        <td>{time_val}</td>
                        <td>{accuracy}</td>
                    </tr>"""
            
            html += """
                </tbody>
            </table>
        </div>"""

        # Añadir información del archivo analizado
        status_text = "Encontrado | Found" if archivo_existe else "No encontrado | Not found"
        html += f"""
        <div class="debug-info">
            <h3>Información de depuración | Debug Information</h3>
            <ul>
                <li>Ruta del archivo analizado | Analyzed file path: <code>{archivo_ruta}</code></li>
                <li>Archivo existe | File exists: <code>{archivo_existe}</code></li>
                <li>Ruta del informe HTML | HTML report path: <code>{ruta_salida}</code></li>
            </ul>
        </div>
        
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
            <p>📁 Archivo analizado | Analyzed file: <code>{archivo_ruta}</code> ({status_text})</p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
    </script>
</body>
</html>"""

        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    # Permitir especificar ruta como argumento
    if len(sys.argv) > 1:
        ruta_a_analizar = sys.argv[1]
        ruta_base = os.path.dirname(os.path.dirname(ruta_a_analizar))
    else:
        # Usar rutas relativas basadas en el directorio home del usuario
        ruta_base = Path.home() / "ForenSage"
        ruta_a_analizar = ruta_base / "analyze/ios/private/var/root/Library/Caches/locationd/cache_encryptedB.db"
    
    print(f"Ruta base: {ruta_base}")
    print(f"Archivo a analizar: {ruta_a_analizar}")
    
    # Para la salida, crear ruta basada en el directorio base
    salida_html = ruta_base / "results/IOS_location_Info.html"
    
    print(f"Ruta del informe HTML: {salida_html}")
    
    # Asegurar que el directorio de salida existe
    try:
        os.makedirs(os.path.dirname(salida_html), exist_ok=True)
        print(f"Directorio de resultados creado: {os.path.dirname(salida_html)}")
    except Exception as e:
        print(f"Error al crear directorio de resultados: {e}")
    
    # Analizar archivo
    ubicaciones, existe = analizar_location_db(ruta_a_analizar)
    
    # Generar el informe HTML con el mapa integrado
    html_generado = generar_html_mapa(ubicaciones, (ruta_a_analizar, existe), str(salida_html))
    print(f"HTML con mapa generado: {html_generado}")

if __name__ == "__main__":
    main()