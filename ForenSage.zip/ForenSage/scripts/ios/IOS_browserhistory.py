import os
import sqlite3
import datetime
from pathlib import Path
from urllib.parse import urlparse, unquote

def analizar_safari_history(ruta_archivo):
    """
    Analiza el archivo History.db de Safari en iOS y extrae el historial de navegación,
    enfocándose especialmente en la tabla history_visits.
    """
    resultados = []
    file_exists = os.path.exists(ruta_archivo)
    stats = {'total_items': 0, 'total_visits': 0}
    top_domains = []
    
    if not file_exists:
        print(f"El archivo no existe: {ruta_archivo}")
        return resultados, file_exists, stats, top_domains
            
    try:
        # Conectar a la base de datos SQLite 
        conn = sqlite3.connect(ruta_archivo)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Analizar estructura de la base de datos
        print("Analizando estructura de la base de datos...")
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [table[0] for table in cursor.fetchall()]
        print(f"Tablas encontradas: {tables}")
        
        # Verificar cada tabla relevante y sus columnas
        for table in tables:
            cursor.execute(f"PRAGMA table_info({table})")
            columns = [col[1] for col in cursor.fetchall()]
            print(f"Tabla '{table}' tiene columnas: {columns}")
        
        # Verificar si podemos ejecutar una consulta de prueba en history_visits
        if 'history_visits' in tables:
            try:
                cursor.execute("SELECT * FROM history_visits LIMIT 1")
                sample_row = cursor.fetchone()
                if sample_row:
                    print(f"Ejemplo de datos en history_visits: {dict(sample_row)}")
            except sqlite3.Error as e:
                print(f"Error al consultar history_visits: {e}")
        
        # Intentar consultar con JOIN entre ambas tablas (approach 1)
        if 'history_items' in tables and 'history_visits' in tables:
            try:
                print("Intentando consulta principal...")
                query = """
                    SELECT 
                        history_items.id,
                        history_items.url,
                        history_items.title,
                        history_visits.id as visit_id,
                        history_visits.history_item,
                        history_visits.visit_time
                    FROM 
                        history_visits
                    LEFT JOIN 
                        history_items ON history_items.id = history_visits.history_item
                    ORDER BY 
                        history_visits.visit_time DESC
                    LIMIT 500
                """
                cursor.execute(query)
                
                rows = cursor.fetchall()
                print(f"Filas recuperadas: {len(rows)}")
                
                for row in cursor.fetchall():
                    # Convertir timestamp
                    mac_time = row['visit_time'] if 'visit_time' in row.keys() else None
                    formatted_date = "Desconocido"
                    
                    if mac_time:
                        try:
                            # Tiempo de referencia: 1 de enero de 2001
                            reference_date = datetime.datetime(2001, 1, 1)
                            
                            # Intentar detectar el formato de timestamp correcto
                            if mac_time > 1000000000000:  # Probablemente nanosegundos
                                visit_date = reference_date + datetime.timedelta(seconds=mac_time/1000000000)
                            else:  # Probablemente microsegundos
                                visit_date = reference_date + datetime.timedelta(seconds=mac_time/1000000)
                                
                            formatted_date = visit_date.strftime("%Y-%m-%d %H:%M:%S")
                        except Exception as e:
                            print(f"Error al convertir timestamp {mac_time}: {e}")
                            formatted_date = f"Error ({mac_time})"
                    
                    # Extraer URL y título si están disponibles
                    url = row['url'] if 'url' in row.keys() and row['url'] else "No disponible"
                    title = row['title'] if 'title' in row.keys() and row['title'] else "Sin título"
                    
                    # Extraer dominio
                    domain = "desconocido"
                    try:
                        if url != "No disponible":
                            parsed_url = urlparse(url)
                            domain = parsed_url.netloc
                    except Exception as e:
                        print(f"Error al parsear URL {url}: {e}")
                    
                    # Crear entrada
                    entry = {
                        'id': row['id'] if 'id' in row.keys() else "N/A",
                        'url': url,
                        'title': title,
                        'visit_time': formatted_date,
                        'success': "Desconocido",
                        'domain': domain,
                        'visit_id': row['visit_id'] if 'visit_id' in row.keys() else "N/A"
                    }
                    resultados.append(entry)
            except sqlite3.Error as e:
                print(f"Error en consulta principal: {e}")
                
        # Si la primera consulta no funcionó, intentar approach 2 - analizar tablas por separado
        if not resultados:
            print("Intentando enfoque alternativo...")
            try:
                # Primero obtener datos de history_visits
                visit_data = {}
                if 'history_visits' in tables:
                    cursor.execute("SELECT * FROM history_visits ORDER BY visit_time DESC LIMIT 500")
                    for row in cursor.fetchall():
                        visit_id = row['id'] if 'id' in row.keys() else None
                        history_item_id = row['history_item'] if 'history_item' in row.keys() else None
                        
                        if not visit_id or not history_item_id:
                            continue
                            
                        # Convertir timestamp
                        mac_time = row['visit_time'] if 'visit_time' in row.keys() else None
                        formatted_date = "Desconocido"
                        
                        if mac_time:
                            try:
                                reference_date = datetime.datetime(2001, 1, 1)
                                if mac_time > 1000000000000:
                                    visit_date = reference_date + datetime.timedelta(seconds=mac_time/1000000000)
                                else:
                                    visit_date = reference_date + datetime.timedelta(seconds=mac_time/1000000)
                                formatted_date = visit_date.strftime("%Y-%m-%d %H:%M:%S")
                            except Exception as e:
                                formatted_date = f"Error ({mac_time})"
                                
                        # Almacenar temporalmente
                        visit_data[history_item_id] = {
                            'visit_id': visit_id,
                            'visit_time': formatted_date,
                            'raw_time': mac_time
                        }
                
                # Luego obtener datos de history_items
                if 'history_items' in tables and visit_data:
                    for item_id in visit_data.keys():
                        try:
                            cursor.execute("SELECT * FROM history_items WHERE id = ?", (item_id,))
                            item = cursor.fetchone()
                            
                            if item:
                                url = item['url'] if 'url' in item.keys() and item['url'] else "No disponible"
                                title = item['title'] if 'title' in item.keys() and item['title'] else "Sin título"
                                
                                # Extraer dominio
                                domain = "desconocido"
                                try:
                                    if url != "No disponible":
                                        parsed_url = urlparse(url)
                                        domain = parsed_url.netloc
                                except Exception:
                                    pass
                                
                                # Crear entrada completa
                                entry = {
                                    'id': item_id,
                                    'url': url,
                                    'title': title,
                                    'visit_time': visit_data[item_id]['visit_time'],
                                    'success': "Desconocido",
                                    'domain': domain,
                                    'visit_id': visit_data[item_id]['visit_id']
                                }
                                resultados.append(entry)
                        except sqlite3.Error as e:
                            print(f"Error al procesar item_id {item_id}: {e}")
                
                # Ordenar resultados por tiempo de visita (más recientes primero)
                resultados.sort(key=lambda x: x['visit_time'], reverse=True)
                
            except sqlite3.Error as e:
                print(f"Error en enfoque alternativo: {e}")
        
        # Enfoque 3: búsqueda directa de información
        if not resultados:
            print("Intentando enfoque directo de consulta...")
            try:
                # Buscar información específica de búsquedas
                if 'history_items' in tables:
                    # Consultar URLs que parecen búsquedas 
                    cursor.execute("SELECT * FROM history_items WHERE url LIKE '%search%' OR url LIKE '%query%' OR url LIKE '%q=%' LIMIT 500")
                    for item in cursor.fetchall():
                        url = item['url'] if 'url' in item.keys() and item['url'] else "No disponible"
                        title = item['title'] if 'title' in item.keys() and item['title'] else "Sin título"
                        item_id = item['id'] if 'id' in item.keys() else "N/A"
                        
                        # Intentar extraer el término de búsqueda de la URL
                        search_term = "Desconocido"
                        try:
                            if "q=" in url:
                                parts = url.split("q=")
                                if len(parts) > 1:
                                    search_part = parts[1].split("&")[0]
                                    search_term = unquote(search_part).replace("+", " ")
                        except Exception:
                            pass
                        
                        # Extraer dominio
                        domain = "desconocido"
                        try:
                            parsed_url = urlparse(url)
                            domain = parsed_url.netloc
                        except Exception:
                            pass
                        
                        # Crear entrada
                        entry = {
                            'id': item_id,
                            'url': url,
                            'title': title,
                            'visit_time': "Desconocido",  # No tenemos timestamp aquí
                            'success': "Desconocido",
                            'domain': domain,
                            'search_term': search_term
                        }
                        resultados.append(entry)
            except sqlite3.Error as e:
                print(f"Error en enfoque directo: {e}")
        
        # Obtener estadísticas básicas
        try:
            if 'history_items' in tables:
                cursor.execute("SELECT COUNT(*) FROM history_items")
                total_items = cursor.fetchone()[0]
            else:
                total_items = 0
                
            if 'history_visits' in tables:
                cursor.execute("SELECT COUNT(*) FROM history_visits")
                total_visits = cursor.fetchone()[0]
            else:
                total_visits = 0
                
            stats = {
                'total_items': total_items,
                'total_visits': total_visits
            }
        except sqlite3.Error as e:
            print(f"Error al obtener estadísticas: {e}")
        
        # Calcular dominios más visitados desde los resultados procesados
        domains_count = {}
        for entry in resultados:
            domain = entry.get('domain', '')
            if domain and domain != "desconocido":
                domains_count[domain] = domains_count.get(domain, 0) + 1
        
        # Ordenar por número de visitas
        sorted_domains = sorted(domains_count.items(), key=lambda x: x[1], reverse=True)
        top_domains = [{'domain': domain, 'count': count} for domain, count in sorted_domains[:10]]
        
        # Cerrar la conexión
        cursor.close()
        conn.close()
        
    except Exception as e:
        print(f"Error analizando {ruta_archivo}: {e}")
        import traceback
        traceback.print_exc()
    
    print(f"Resultados obtenidos: {len(resultados)}")
    return resultados, file_exists, stats, top_domains

def generar_html_BrowserHistory(datos, archivo_info, stats, top_domains, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis del History.db de Safari
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception:
            return False

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())
    archivo_ruta, archivo_existe = archivo_info

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iOS Safari Browser History | Historial de Navegación Safari</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .stats-container {{
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-bottom: 3rem;
        }}

        .stat-box {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 1.5rem;
            min-width: 200px;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            transition: all 0.3s ease;
        }}

        .stat-box:hover {{
            transform: translateY(-10px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.6);
        }}

        .stat-value {{
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--accent-light);
            margin-bottom: 0.5rem;
        }}

        .stat-label {{
            font-size: 1rem;
            color: var(--text-secondary);
            text-transform: uppercase;
        }}

        .domains-container {{
            margin: 3rem 0;
            background-color: var(--card-bg);
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        }}

        .domains-title {{
            margin-bottom: 1.5rem;
            text-align: center;
            font-size: 1.5rem;
            color: var(--accent-light);
        }}

        .domain-chart {{
            height: 250px;
            display: flex;
            align-items: flex-end;
            justify-content: space-around;
            padding: 1rem 0;
        }}

        .domain-bar {{
            position: relative;
            width: 40px;
            background: linear-gradient(to top, var(--accent), var(--accent-light));
            border-radius: 5px 5px 0 0;
            transition: all 0.3s ease;
            cursor: pointer;
        }}

        .domain-bar:hover {{
            transform: scaleY(1.05);
            background: linear-gradient(to top, var(--accent-light), var(--accent));
        }}

        .domain-label {{
            position: absolute;
            bottom: -40px;
            left: 50%;
            transform: translateX(-50%);
            text-align: center;
            font-size: 0.8rem;
            color: var(--text-secondary);
            width: 100px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}

        .domain-count {{
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            color: var(--text);
            font-weight: 600;
            font-size: 0.9rem;
        }}

        .history-table-container {{
            overflow-x: auto;
            margin-top: 3rem;
        }}

        .history-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
            background-color: var(--card-bg);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        }}

        .history-table th {{
            background-color: var(--primary);
            color: var(--text);
            text-align: left;
            padding: 1rem;
            font-size: 0.9rem;
            text-transform: uppercase;
        }}

        .history-table tr:nth-child(even) {{
            background-color: rgba(255, 255, 255, 0.05);
        }}

        .history-table td {{
            padding: 0.8rem 1rem;
            border-top: 1px solid var(--border-color);
            font-size: 0.9rem;
        }}

        .url-cell {{
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}

        .title-cell {{
            max-width: 250px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}

        .search-term {{
            color: var(--warning);
            font-weight: 600;
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .stats-container {{
                flex-direction: column;
                align-items: center;
            }}
            .stat-box {{
                width: 100%;
            }}
            .domain-bar {{
                width: 30px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">iOS Safari Browser History | Historial de Navegación Safari</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
        </div>"""

    if not archivo_existe:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontró el archivo | File not found</div>
            <p>No se ha podido encontrar el archivo History.db de Safari. | Could not find Safari's History.db file.</p>
        </div>"""
    elif not datos:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron datos de historial | No history data found</div>
            <p>No se ha podido extraer información del historial de Safari. | Could not extract information from Safari's history.</p>
        </div>"""
    else:
        # Mostrar estadísticas
        html += f"""
        <div class="stats-container">
            <div class="stat-box">
                <div class="stat-value">{stats['total_items']}</div>
                <div class="stat-label">Páginas Únicas | Unique Pages</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">{stats['total_visits']}</div>
                <div class="stat-label">Visitas Totales | Total Visits</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">{len(datos)}</div>
                <div class="stat-label">Entradas Mostradas | Displayed Entries</div>
            </div>
        </div>"""

        # Mostrar dominios más visitados si hay datos
        if top_domains:
            html += """
        <div class="domains-container">
            <div class="domains-title">Dominios Más Visitados | Most Visited Domains</div>
            <div class="domain-chart">"""
            
            max_count = max([domain['count'] for domain in top_domains]) if top_domains else 1
            
            for domain in top_domains:
                # Calcular altura proporcional
                height = int((domain['count'] / max_count) * 200) + 50
                html += f"""
                <div class="domain-bar" style="height: {height}px;">
                    <div class="domain-count">{domain['count']}</div>
                    <div class="domain-label">{domain['domain']}</div>
                </div>"""
                
            html += """
            </div>
        </div>"""

        # Tabla de historial - ahora con posible columna de término de búsqueda
        html += """
        <h2 style="text-align: center; margin-top: 3rem; color: var(--accent-light);">Historial de Navegación | Browsing History</h2>
        <div class="history-table-container">
            <table class="history-table">
                <thead>
                    <tr>
                        <th>Fecha/Date</th>
                        <th>Título/Title</th>
                        <th>URL</th>"""
        
        # Verificar si tenemos datos de términos de búsqueda
        has_search_terms = any('search_term' in entry for entry in datos)
        if has_search_terms:
            html += """
                        <th>Búsqueda/Search Term</th>"""
        
        html += """
                        <th>Éxito/Success</th>
                    </tr>
                </thead>
                <tbody>"""
                
        for entry in datos:
            html += f"""
                    <tr>
                        <td>{entry['visit_time']}</td>
                        <td class="title-cell">{entry['title']}</td>
                        <td class="url-cell">{entry['url']}</td>"""
            
            if has_search_terms:
                search_term = entry.get('search_term', 'N/A')
                html += f"""
                        <td class="search-term">{search_term}</td>"""
            
            html += f"""
                        <td>{entry['success']}</td>
                    </tr>"""
                
        html += """
                </tbody>
            </table>
        </div>"""

    # Añadir información del archivo analizado en el footer
    status_text = "Encontrado | Found" if archivo_existe else "No encontrado | Not found"
    html += f"""
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
            <p>📁 Archivo analizado | Analyzed file: <code>{archivo_ruta}</code> ({status_text})</p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Usar rutas relativas como se solicitó
    ruta_a_analizar = os.path.expanduser("~/ForenSage/analyze/ios/var/mobile/Library/Safari/History.db")
    
    # Para mostrar información adicional
    print(f"Intentando analizar: {ruta_a_analizar}")
    print(f"¿El archivo existe? {os.path.exists(ruta_a_analizar)}")
    
    # Para la salida, crear ruta basada en el directorio actual
    base_path = Path.home() / "ForenSage"
    salida_html = base_path / "results/IOS_browserhistory.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar archivo
    datos, existe, stats, top_domains = analizar_safari_history(ruta_a_analizar)
    
    # Generar el informe HTML
    generar_html_BrowserHistory(datos, (ruta_a_analizar, existe), stats, top_domains, str(salida_html))

if __name__ == "__main__":
    main()