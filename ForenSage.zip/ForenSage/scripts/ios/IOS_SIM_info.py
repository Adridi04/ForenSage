import os
import plistlib
import datetime
from pathlib import Path

def analizar_commcenter_plist(ruta_archivo):
    """
    Analiza el archivo com.apple.commcenter.plist de iOS y extrae la información relacionada con la tarjeta SIM.
    / Analyzes iOS com.apple.commcenter.plist file and extracts SIM card related information.
    """
    resultados = {}
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        return resultados, file_exists
            
    try:
        # Leer el archivo plist / Read plist file
        with open(ruta_archivo, 'rb') as fp:
            pl = plistlib.load(fp)
        
        # Extraer información relevante de la tarjeta SIM / Extract relevant SIM card information
        # Mapeo de claves importantes / Mapping of important keys
        sim_info_keys = [
            "SIMStatus", "ICCID", "IMSI", "SIMTrayStatus", "kIMSI", "kCTPostponementInfoPRIVersion",
            "kCTPostponementStatus", "LastKnownNetwork", "PhoneNumber", "MobileSubscriberCountryCode",
            "MobileSubscriberNetworkCode", "OperatorName", "CarrierBundleInfoArray", "ServicesStatusInfo"
        ]
        
        # Extraer información organizada / Extract organized information
        for key in sim_info_keys:
            if key in pl:
                resultados[key] = pl[key]
        
        # Extraer información anidada sobre el operador / Extract nested operator information
        if "CarrierBundleInfoArray" in pl and pl["CarrierBundleInfoArray"]:
            for idx, bundle in enumerate(pl["CarrierBundleInfoArray"]):
                for bundle_key, bundle_value in bundle.items():
                    resultados[f"CarrierBundle_{idx}_{bundle_key}"] = bundle_value
        
        # Extraer información anidada sobre los servicios / Extract nested services information
        if "ServicesStatusInfo" in pl and pl["ServicesStatusInfo"]:
            for service_key, service_value in pl["ServicesStatusInfo"].items():
                resultados[f"ServiceStatus_{service_key}"] = service_value
        
        # Añadir cualquier otra información relevante / Add any other relevant information
        if "SignalStrength" in pl:
            resultados["SignalStrength"] = pl["SignalStrength"]
            
        if "PUKInfo" in pl:
            resultados["PUKLocked"] = "Yes" if pl["PUKInfo"].get("PUKLocked", False) else "No"
            resultados["PINEnabled"] = "Yes" if pl["PUKInfo"].get("PINEnabled", False) else "No"
            resultados["PINAttemptsLeft"] = pl["PUKInfo"].get("PINAttemptsLeft", "Unknown")
            
        if "CellularUsageInfo" in pl:
            usage_info = pl["CellularUsageInfo"]
            if isinstance(usage_info, dict):
                for usage_key, usage_value in usage_info.items():
                    resultados[f"CellularUsage_{usage_key}"] = usage_value
        
        # Obtener información del nivel de red / Get network level information
        network_keys = [key for key in pl.keys() if "Network" in key or "network" in key or "Cellular" in key]
        for key in network_keys:
            if key not in resultados:
                value = pl[key]
                # Convertir valores complejos a cadena / Convert complex values to string
                if not (isinstance(value, str) or isinstance(value, int) or isinstance(value, float) or isinstance(value, bool)):
                    value = str(value)
                resultados[key] = value
                
    except Exception as e:
        print(f"Error analizando {ruta_archivo}: {e}")
    
    return resultados, file_exists

def formato_iccid(iccid):
    """
    Da formato al ICCID para mostrarlo en grupos de 4 dígitos como en una tarjeta SIM física
    / Formats the ICCID to display it in groups of 4 digits like on a physical SIM card
    """
    if not iccid or not isinstance(iccid, str):
        return "Unknown/Desconocido"
    
    # Eliminar espacios y formatear en grupos de 4 / Remove spaces and format in groups of 4
    iccid = iccid.replace(" ", "")
    return " ".join([iccid[i:i+4] for i in range(0, len(iccid), 4)])

def generar_html_SimCardInfo(datos, archivo_info, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis del com.apple.commcenter.plist
    / Generates HTML report with com.apple.commcenter.plist analysis results
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception:
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())
    archivo_ruta, archivo_existe = archivo_info

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iOS SIM Card Information | Información de Tarjeta SIM</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --sim-gold: #e6b800;
            --sim-silver: #c0c0c0;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .sim-card-container {{
            position: relative;
            perspective: 1000px;
            margin: 2rem auto;
            width: 90%;
            max-width: 500px;
        }}

        .sim-card {{
            position: relative;
            width: 100%;
            height: 300px;
            border-radius: 20px;
            background: linear-gradient(145deg, var(--sim-gold), var(--sim-silver));
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
            display: flex;
            flex-direction: column;
            padding: 1.5rem;
            transition: all 0.5s ease;
            transform-style: preserve-3d;
            margin-bottom: 3rem;
        }}

        .sim-card:hover {{
            transform: rotateY(10deg);
            box-shadow: -15px 15px 25px rgba(0, 0, 0, 0.6);
        }}

        .chip {{
            position: absolute;
            top: 30px;
            left: 30px;
            width: 70px;
            height: 70px;
            background: linear-gradient(145deg, #d4af37, #b8860b);
            border-radius: 10px;
            box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.5);
        }}

        .chip::before {{
            content: '';
            position: absolute;
            top: 10px;
            left: 10px;
            right: 10px;
            bottom: 10px;
            background: linear-gradient(145deg, #ffcc00, #e6b800);
            border-radius: 5px;
            box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.5);
        }}

        .chip::after {{
            content: '';
            position: absolute;
            top: 25px;
            left: 25px;
            right: 25px;
            bottom: 25px;
            background: linear-gradient(145deg, #d4af37, #b8860b);
            border-radius: 3px;
        }}

        .sim-info {{
            margin-top: 110px;
            color: var(--primary-dark);
            font-weight: 600;
            z-index: 1;
        }}

        .sim-row {{
            display: flex;
            margin-bottom: 0.5rem;
            align-items: center;
        }}

        .sim-label {{
            width: 120px;
            font-size: 0.85rem;
            text-transform: uppercase;
            color: var(--primary-dark);
            font-weight: 700;
        }}

        .sim-value {{
            flex: 1;
            font-size: 1rem;
            font-family: monospace;
            color: var(--primary-dark);
            font-weight: 600;
            text-shadow: 0 1px 1px rgba(255, 255, 255, 0.5);
        }}

        .carrier-logo {{
            position: absolute;
            top: 30px;
            right: 30px;
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--primary-dark);
            text-transform: uppercase;
            text-shadow: 0 1px 1px rgba(255, 255, 255, 0.5);
        }}

        .sim-card-back {{
            background: linear-gradient(145deg, #d4af37, #b8860b);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 20px;
            backface-visibility: hidden;
            transform: rotateY(180deg);
            padding: 1.5rem;
            box-sizing: border-box;
        }}

        .circles-container {{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 2rem;
            margin: 3rem 0;
        }}

        .data-circle {{
            position: relative;
            width: 160px;
            height: 160px;
            border-radius: 50%;
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            text-align: center;
            transition: all 0.3s ease;
            overflow: hidden;
        }}

        .data-circle:hover {{
            transform: translateY(-10px) scale(1.05);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.6);
        }}

        .data-circle::before {{
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                0deg,
                transparent,
                transparent,
                var(--accent),
                var(--accent)
            );
            transform-origin: bottom right;
            animation: rotate 6s linear infinite;
            z-index: -1;
            opacity: 0.3;
        }}

        @keyframes rotate {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}

        .data-label {{
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }}

        .data-value {{
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--accent-light);
            word-break: break-word;
            max-width: 100%;
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .sim-card {{
                height: 250px;
            }}
            .data-circle {{
                width: 140px;
                height: 140px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">iOS SIM Card Information | Información de Tarjeta SIM</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
        </div>"""

    if not datos:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron datos | No data found</div>
            <p>No se ha podido extraer información del archivo com.apple.commcenter.plist. | Could not extract information from com.apple.commcenter.plist file.</p>
        </div>"""
    else:
        # Preparar datos para la tarjeta SIM
        iccid = formato_iccid(datos.get("ICCID", ""))
        imsi = datos.get("IMSI", datos.get("kIMSI", "Unknown/Desconocido"))
        carrier = datos.get("OperatorName", "Unknown/Desconocido")
        phone_number = datos.get("PhoneNumber", "Unknown/Desconocido")
        sim_status = datos.get("SIMStatus", "Unknown/Desconocido")
        sim_tray_status = datos.get("SIMTrayStatus", "Unknown/Desconocido")
        mcc = datos.get("MobileSubscriberCountryCode", "Unknown/Desconocido")
        mnc = datos.get("MobileSubscriberNetworkCode", "Unknown/Desconocido")
        
        # Agregar tarjeta SIM visual
        html += f"""
        <div class="sim-card-container">
            <div class="sim-card">
                <div class="chip"></div>
                <div class="carrier-logo">{carrier}</div>
                <div class="sim-info">
                    <div class="sim-row">
                        <div class="sim-label">ICCID:</div>
                        <div class="sim-value">{iccid}</div>
                    </div>
                    <div class="sim-row">
                        <div class="sim-label">IMSI:</div>
                        <div class="sim-value">{imsi}</div>
                    </div>
                    <div class="sim-row">
                        <div class="sim-label">Phone:</div>
                        <div class="sim-value">{phone_number}</div>
                    </div>
                    <div class="sim-row">
                        <div class="sim-label">Status:</div>
                        <div class="sim-value">{sim_status}</div>
                    </div>
                    <div class="sim-row">
                        <div class="sim-label">MCC-MNC:</div>
                        <div class="sim-value">{mcc}-{mnc}</div>
                    </div>
                </div>
            </div>
        </div>"""
        
        # Agregar círculos con información adicional
        html += """
        <div class="circles-container">"""
        
        # Seleccionar información adicional importante
        circle_data = {
            "SIM Tray": sim_tray_status,
            "PIN Status": datos.get("PINEnabled", "Unknown/Desconocido"),
            "PIN Attempts": datos.get("PINAttemptsLeft", "Unknown/Desconocido"),
            "PUK Locked": datos.get("PUKLocked", "Unknown/Desconocido"),
            "Signal Strength": datos.get("SignalStrength", "Unknown/Desconocido"),
        }
        
        # Crear círculos para cada dato seleccionado
        for label, value in circle_data.items():
            html += f"""
            <div class="data-circle">
                <div class="data-label">{label}</div>
                <div class="data-value">{value}</div>
            </div>"""
        
        # Buscar y agregar información de red
        network_items = [(k, v) for k, v in datos.items() if "Network" in k or "Cellular" in k or "LastKnown" in k]
        
        # Limitar a no más de 3 elementos adicionales
        for key, value in network_items[:3]:
            label = key.replace("Network", "").replace("Cellular", "")
            if isinstance(value, (bool, int, float)):
                display_value = str(value)
            elif isinstance(value, str):
                display_value = value
            else:
                display_value = "Complex data"
                
            html += f"""
            <div class="data-circle">
                <div class="data-label">{label}</div>
                <div class="data-value">{display_value}</div>
            </div>"""

        html += """
        </div>"""
        
        # Sección de servicios si existen
        services_items = [(k, v) for k, v in datos.items() if "ServiceStatus" in k]
        if services_items:
            html += """
            <div class="circles-container">
                <h2 style="width: 100%; text-align: center; color: var(--accent-light);">Servicios | Services</h2>"""
                
            # Limitar a 6 servicios máximo
            for key, value in services_items[:6]:
                service_name = key.replace("ServiceStatus_", "")
                html += f"""
                <div class="data-circle">
                    <div class="data-label">{service_name}</div>
                    <div class="data-value">{value}</div>
                </div>"""
                
            html += """
            </div>"""

    # Añadir información del archivo analizado en el footer
    status_text = "Encontrado | Found" if archivo_existe else "No encontrado | Not found"
    html += f"""
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
            <p>📁 Archivo analizado | Analyzed file: <code>{archivo_ruta}</code> ({status_text})</p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Usar la ruta exacta proporcionada por el usuario
    ruta_a_analizar = "/home/adrian/ForenSage/analyze/ios/private/var/wireless/Library/Preferences/com.apple.commcenter.plist"
    
    # Para la salida, crear ruta basada en el directorio home del usuario
    base_path = Path.home() / "ForenSage"
    salida_html = base_path / "results/IOS_sim_Info.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar archivo
    datos, existe = analizar_commcenter_plist(ruta_a_analizar)
    
    # Generar el informe HTML
    generar_html_SimCardInfo(datos, (ruta_a_analizar, existe), str(salida_html))

if __name__ == "__main__":
    main()