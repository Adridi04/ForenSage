import os
import sqlite3
import datetime
import sys
from pathlib import Path

def analizar_db_appstore(ruta_archivo):
    """
    Analiza un archivo de base de datos de Apple App Store y extrae información sobre aplicaciones.
    Enfoque mejorado para detectar y extraer datos sin asumir la estructura de la base de datos.
    """
    resultados = {
        "aplicaciones": [],
        "estadisticas": {
            "total_apps": 0,
            "total_compras": 0,
            "primera_compra": None,
            "ultima_compra": None,
            "categorias": {},
            "desarrolladores_frecuentes": {}
        },
        "metadata": {}
    }
    
    # Verificar si el archivo existe
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        print(f"❌ Error: El archivo {ruta_archivo} no existe.")
        resultados["metadata"]["error"] = f"El archivo {ruta_archivo} no existe"
        return resultados, file_exists
            
    try:
        print(f"📂 Analizando base de datos: {ruta_archivo}")
        
        # Conectar a la base de datos
        conn = sqlite3.connect(ruta_archivo)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Obtener la lista de tablas
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = [row['name'] for row in cursor.fetchall()]
        resultados["metadata"]["tablas"] = tablas
        
        print(f"📊 Tablas encontradas: {len(tablas)}")
        for tabla in tablas:
            print(f"  - {tabla}")
        
        # Analizar cada tabla para encontrar datos de aplicaciones
        tablas_apps = []
        for tabla in tablas:
            # Obtener estructura de la tabla
            cursor.execute(f"PRAGMA table_info({tabla});")
            columnas = [row['name'] for row in cursor.fetchall()]
            
            # Obtener primer registro para ver los datos
            try:
                cursor.execute(f"SELECT * FROM {tabla} LIMIT 1;")
                first_row = cursor.fetchone()
                
                # Verificar si la tabla contiene datos y columnas relevantes
                if first_row:
                    columnas_lower = [col.lower() for col in columnas]
                    # Buscar indicadores de que esta tabla puede contener apps
                    if any(keyword in " ".join(columnas_lower) for keyword in 
                          ['app', 'item', 'product', 'title', 'name', 'bundle', 'purchase']):
                        tablas_apps.append((tabla, columnas, dict(first_row)))
            except Exception as e:
                print(f"  ⚠️ Error al leer la tabla {tabla}: {str(e)}")
                continue
        
        print(f"🔍 Tablas potenciales con datos de apps: {len(tablas_apps)}")
        
        # Si no encontramos tablas con datos de apps, vamos a examinar todas las tablas
        if not tablas_apps:
            print("⚠️ No se identificaron tablas específicas de apps. Examinando todas las tablas...")
            for tabla in tablas:
                try:
                    cursor.execute(f"SELECT COUNT(*) as count FROM {tabla};")
                    count = cursor.fetchone()['count']
                    if count > 0:
                        cursor.execute(f"PRAGMA table_info({tabla});")
                        columnas = [row['name'] for row in cursor.fetchall()]
                        cursor.execute(f"SELECT * FROM {tabla} LIMIT 1;")
                        first_row = cursor.fetchone()
                        if first_row:
                            tablas_apps.append((tabla, columnas, dict(first_row)))
                except Exception as e:
                    continue
        
        # Procesar cada tabla potencial con datos de apps
        total_apps_encontradas = 0
        for tabla, columnas, muestra in tablas_apps:
            print(f"📱 Procesando tabla: {tabla} ({len(columnas)} columnas)")
            
            # Determinar qué columnas son relevantes basado en los nombres
            campos_relevantes = {}
            for col in columnas:
                col_lower = col.lower()
                
                # Detectar campos por nombres comunes
                if any(keyword in col_lower for keyword in ['name', 'título', 'title']):
                    campos_relevantes['nombre'] = col
                elif any(keyword in col_lower for keyword in ['bundle', 'identifier', 'id']) and 'date' not in col_lower:
                    campos_relevantes['bundleid'] = col
                elif any(keyword in col_lower for keyword in ['develop', 'artist', 'vendor', 'autor']):
                    campos_relevantes['desarrollador'] = col
                elif any(keyword in col_lower for keyword in ['category', 'genre', 'tipo']):
                    campos_relevantes['categoria'] = col
                elif any(keyword in col_lower for keyword in ['version']):
                    campos_relevantes['version'] = col
                elif any(keyword in col_lower for keyword in ['date', 'time', 'fecha']):
                    campos_relevantes['fecha'] = col
                elif any(keyword in col_lower for keyword in ['price', 'cost', 'precio']):
                    campos_relevantes['precio'] = col
                elif any(keyword in col_lower for keyword in ['size', 'tamaño']):
                    campos_relevantes['tamaño'] = col
                elif any(keyword in col_lower for keyword in ['rating', 'stars', 'calificación']):
                    campos_relevantes['calificacion'] = col
                elif any(keyword in col_lower for keyword in ['description', 'desc', 'info']):
                    campos_relevantes['descripcion'] = col
            
            # Si no encontramos campos específicos, tratar de usar los que parecen informativos
            if not campos_relevantes:
                for col in columnas:
                    # Examinar el primer valor para ver si contiene datos útiles
                    valor = muestra.get(col)
                    if isinstance(valor, str) and len(valor) > 2:
                        if 'nombre' not in campos_relevantes:
                            campos_relevantes['nombre'] = col
                        elif 'bundleid' not in campos_relevantes and ('.' in valor or '/' in valor):
                            campos_relevantes['bundleid'] = col
                        elif 'desarrollador' not in campos_relevantes:
                            campos_relevantes['desarrollador'] = col
                    elif isinstance(valor, (int, float)) and valor > 0:
                        if 'precio' not in campos_relevantes:
                            campos_relevantes['precio'] = col
            
            print(f"  🔑 Campos identificados: {len(campos_relevantes)}")
            for campo, columna in campos_relevantes.items():
                print(f"    - {campo}: {columna}")
            
            # Si encontramos al menos un campo relevante, extraer datos
            if campos_relevantes:
                try:
                    # Preparar consulta para obtener todos los registros
                    columnas_consulta = list(campos_relevantes.values())
                    consulta = f"SELECT {', '.join(columnas_consulta)} FROM {tabla}"
                    cursor.execute(consulta)
                    rows = cursor.fetchall()
                    
                    print(f"  📊 Registros encontrados: {len(rows)}")
                    
                    # Procesar cada registro
                    for row in rows:
                        app_data = {}
                        for campo, columna in campos_relevantes.items():
                            valor = row[columna]
                            if valor is not None:
                                app_data[campo] = valor
                        
                        # Procesar fecha si existe
                        if 'fecha' in app_data:
                            fecha_str = str(app_data['fecha'])
                            try:
                                fecha = None
                                # Intentar varios formatos de fecha
                                if fecha_str.isdigit():
                                    timestamp = int(fecha_str)
                                    # Si es timestamp de iOS (segundos desde 2001)
                                    if timestamp > 1000000000000:  # Milisegundos
                                        timestamp = timestamp / 1000
                                    fecha = datetime.datetime.fromtimestamp(timestamp)
                                elif len(fecha_str) > 8 and fecha_str[0:4].isdigit():
                                    try:
                                        fecha = datetime.datetime.strptime(fecha_str, "%Y-%m-%d %H:%M:%S")
                                    except:
                                        try:
                                            fecha = datetime.datetime.fromisoformat(fecha_str.replace('Z', '+00:00'))
                                        except:
                                            pass
                                
                                if fecha:
                                    app_data['fecha_formateada'] = fecha.strftime("%Y-%m-%d %H:%M:%S")
                                    
                                    # Actualizar estadísticas de fechas
                                    if (not resultados["estadisticas"]["primera_compra"] or 
                                        fecha < datetime.datetime.strptime(resultados["estadisticas"]["primera_compra"], "%Y-%m-%d %H:%M:%S")):
                                        resultados["estadisticas"]["primera_compra"] = app_data['fecha_formateada']
                                    
                                    if (not resultados["estadisticas"]["ultima_compra"] or 
                                        fecha > datetime.datetime.strptime(resultados["estadisticas"]["ultima_compra"], "%Y-%m-%d %H:%M:%S")):
                                        resultados["estadisticas"]["ultima_compra"] = app_data['fecha_formateada']
                            except Exception as e:
                                app_data['fecha_original'] = fecha_str
                        
                        # Añadir info de la app a resultados
                        resultados["aplicaciones"].append(app_data)
                        
                        # Actualizar estadísticas
                        if 'categoria' in app_data and app_data['categoria']:
                            categoria = app_data['categoria']
                            resultados["estadisticas"]["categorias"][categoria] = resultados["estadisticas"]["categorias"].get(categoria, 0) + 1
                        
                        if 'desarrollador' in app_data and app_data['desarrollador']:
                            desarrollador = app_data['desarrollador']
                            resultados["estadisticas"]["desarrolladores_frecuentes"][desarrollador] = resultados["estadisticas"]["desarrolladores_frecuentes"].get(desarrollador, 0) + 1
                    
                    total_apps_encontradas += len(rows)
                    
                except Exception as e:
                    print(f"  ❌ Error al procesar tabla {tabla}: {str(e)}")
        
        # Actualizar estadísticas finales
        resultados["estadisticas"]["total_apps"] = total_apps_encontradas
        
        # Ordenar desarrolladores por frecuencia y limitar a los 5 más comunes
        desarrolladores = resultados["estadisticas"]["desarrolladores_frecuentes"]
        resultados["estadisticas"]["desarrolladores_frecuentes"] = {k: v for k, v in sorted(desarrolladores.items(), key=lambda item: item[1], reverse=True)[:5]}
        
        conn.close()
        print(f"✅ Análisis completado. Aplicaciones encontradas: {total_apps_encontradas}")
                
    except Exception as e:
        error_msg = f"Error analizando {ruta_archivo}: {str(e)}"
        print(f"❌ {error_msg}")
        resultados["metadata"]["error"] = error_msg
    
    return resultados, file_exists

def generar_html_AppStoreAnalysis(datos, archivo_info, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis de la base de datos del App Store
    mostrando cada aplicación en una tarjeta individual
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception as e:
            print(f"❌ Error al crear directorio de salida: {str(e)}")
            return False

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())
    archivo_ruta, archivo_existe = archivo_info

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de App Store | App Store Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .source-path {{
            font-family: monospace;
            color: var(--text);
        }}

        .source-status {{
            font-size: 0.9rem;
            padding: 0.3rem 0.8rem;
            border-radius: 12px;
        }}

        .source-found {{
            background-color: var(--success);
            color: var(--text);
        }}

        .source-not-found {{
            background-color: var(--danger);
            color: var(--text);
        }}

        .stats-container {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
            transition: transform 0.3s ease;
        }}

        .stat-card:hover {{
            transform: translateY(-5px);
        }}

        .stat-value {{
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0.5rem 0;
            color: var(--accent);
        }}

        .stat-label {{
            font-size: 1rem;
            color: var(--text-secondary);
        }}

        .apps-container {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }}

        .app-card {{
            background-color: var(--card-bg);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: fadeIn 0.7s ease-in-out;
            animation-fill-mode: both;
            animation-delay: calc(var(--animation-order) * 0.1s);
        }}

        .app-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.6);
        }}

        .app-header {{
            background: linear-gradient(145deg, var(--accent), var(--accent-light));
            padding: 1.5rem;
            color: white;
        }}

        .app-title {{
            font-size: 1.2rem;
            font-weight: 600;
            margin: 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}

        .app-bundleid {{
            font-size: 0.8rem;
            opacity: 0.9;
            font-family: monospace;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}

        .app-body {{
            padding: 1.5rem;
        }}

        .app-info {{
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }}

        .app-info-item {{
            display: flex;
            justify-content: space-between;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.5rem;
        }}

        .app-info-label {{
            color: var(--text-secondary);
            font-size: 0.9rem;
        }}

        .app-info-value {{
            font-weight: 600;
            text-align: right;
            word-break: break-word;
        }}

        .category-badge {{
            display: inline-block;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 0.3rem 0.8rem;
            margin-top: 0.5rem;
            font-size: 0.8rem;
        }}

        .price {{
            font-weight: 700;
            color: var(--accent);
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        .badge {{
            display: inline-block;
            padding: 0.25rem 0.6rem;
            border-radius: 10px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }}

        .badge-success {{
            background-color: var(--success);
            color: white;
        }}

        .badge-free {{
            background-color: var(--success);
        }}

        .badge-paid {{
            background-color: var(--warning);
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .apps-container {{
                grid-template-columns: 1fr;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Análisis de App Store | App Store Analysis</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
            <p class="subtitle">📁 Ruta del archivo: <code>{archivo_ruta}</code> - <span class="source-status {'source-found' if archivo_existe else 'source-not-found'}">{("Encontrado | Found" if archivo_existe else "No encontrado | Not found")}</span></p>
        </div>"""

    if not datos or not datos.get("aplicaciones"):
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron aplicaciones | No apps found</div>
            <p>No se ha podido extraer información de aplicaciones de la base de datos. | Could not extract app information from the database file.</p>
        </div>"""
        
        # Si hay metadatos con errores, mostrarlos
        if datos and "metadata" in datos and "error" in datos["metadata"]:
            html += f"""
            <div class="warning-card">
                <div class="warning-title">⚠️ Error de análisis | Analysis Error</div>
                <p>{datos["metadata"]["error"]}</p>
            </div>"""
            
        # Si hay tablas identificadas, mostrarlas
        if datos and "metadata" in datos and "tablas" in datos["metadata"]:
            html += """
            <div class="warning-card">
                <div class="warning-title">📊 Tablas encontradas | Found Tables</div>
                <p>Se encontraron las siguientes tablas en la base de datos:</p>
                <ul>"""
                
            for tabla in datos["metadata"]["tablas"]:
                html += f"<li><code>{tabla}</code></li>"
                
            html += """</ul>
            </div>"""
    else:
        # Mostrar estadísticas
        estadisticas = datos.get("estadisticas", {})
        html += """
        <div class="stats-container">"""
        
        # Total de aplicaciones
        html += f"""
            <div class="stat-card">
                <div class="stat-label">Total de Aplicaciones</div>
                <div class="stat-value">{estadisticas.get("total_apps", 0)}</div>
                <div class="stat-label">Apps Found</div>
            </div>"""
            
        # Periodo de tiempo
        if estadisticas.get("primera_compra") and estadisticas.get("ultima_compra"):
            html += f"""
            <div class="stat-card">
                <div class="stat-label">Periodo</div>
                <div class="stat-value">
                    <span style="font-size: 1rem;">{estadisticas.get("primera_compra", "").split(" ")[0]}</span>
                    <br>a<br>
                    <span style="font-size: 1rem;">{estadisticas.get("ultima_compra", "").split(" ")[0]}</span>
                </div>
                <div class="stat-label">Period</div>
            </div>"""
            
        # Categorías más comunes
        categorias = estadisticas.get("categorias", {})
        if categorias:
            categoria_principal = max(categorias.items(), key=lambda x: x[1])[0] if categorias else "N/A"
            html += f"""
            <div class="stat-card">
                <div class="stat-label">Categoría Principal</div>
                <div class="stat-value" style="font-size: 1.5rem;">{categoria_principal}</div>
                <div class="stat-label">Main Category</div>
            </div>"""
            
        html += """
        </div>"""
        
        # Mostrar tarjetas de aplicaciones
        html += """
        <h2 style="text-align: center; margin-top: 3rem;">Aplicaciones Encontradas | Found Applications</h2>
        <div class="apps-container">"""
        
        for i, app in enumerate(datos["aplicaciones"]):
            # Preparar valores para mostrar
            titulo = app.get("nombre", app.get("bundleid", "App Desconocida"))
            bundleid = app.get("bundleid", "")
            desarrollador = app.get("desarrollador", "Desconocido")
            categoria = app.get("categoria", "")
            version = app.get("version", "")
            fecha = app.get("fecha_formateada", app.get("fecha", ""))
            precio = app.get("precio", "")
            tamaño = app.get("tamaño", "")
            
            # Formatear precio si existe
            precio_formateado = ""
            precio_badge = ""
            if precio:
                try:
                    precio_num = float(precio)
                    if precio_num == 0:
                        precio_formateado = "Gratis"
                        precio_badge = "badge-free"
                    else:
                        precio_formateado = f"${precio_num:.2f}"
                        precio_badge = "badge-paid"
                except:
                    precio_formateado = str(precio)
            
            html += f"""
            <div class="app-card" style="--animation-order: {i}">
                <div class="app-header">
                    <h3 class="app-title">{titulo}</h3>
                    <div class="app-bundleid">{bundleid}</div>
                </div>
                <div class="app-body">
                    <div class="app-info">"""
                    
            if desarrollador:
                html += f"""
                        <div class="app-info-item">
                            <div class="app-info-label">Desarrollador:</div>
                            <div class="app-info-value">{desarrollador}</div>
                        </div>"""
                        
            if version:
                html += f"""
                        <div class="app-info-item">
                            <div class="app-info-label">Versión:</div>
                            <div class="app-info-value">{version}</div>
                        </div>"""
                        
            if fecha:
                html += f"""
                        <div class="app-info-item">
                            <div class="app-info-label">Fecha:</div>
                            <div class="app-info-value">{fecha}</div>
                        </div>"""
                        
            if precio_formateado:
                html += f"""
                        <div class="app-info-item">
                            <div class="app-info-label">Precio:</div>
                            <div class="app-info-value price">
                                {precio_formateado}
                                <span class="badge {precio_badge}"></span>
                            </div>
                        </div>"""
            
            if tamaño:
                html += f"""
                        <div class="app-info-item">
                            <div class="app-info-label">Tamaño:</div>
                            <div class="app-info-value">{tamaño}</div>
                        </div>"""
                        
            html += """
                    </div>"""
                    
            if categoria:
                html += f"""
                    <div class="category-badge">{categoria}</div>"""
                    
            html += """
                </div>
            </div>"""
            
        html += """
        </div>"""

    # Pie de página
    html += """
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Obtener la ruta base del proyecto ForenSage
    base_dir = os.path.expanduser("~/ForenSage")
    
    # Construir la ruta completa del archivo a analizar usando ruta relativa
    ruta_a_analizar = os.path.join(
        base_dir, 
        "analyze", 
        "ios", 
        "private", 
        "var", 
        "mobile", 
        "Library", 
        "Caches", 
        "com.apple.appstored", 
        "storeUser.db"
    )
    
    print(f"🔍 Analizando archivo: {ruta_a_analizar}")
    
    # Para la salida, crear ruta relativa
    salida_html = os.path.join(base_dir, "results", "IOS_app_installed.html")
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar archivo
    datos, existe = analizar_db_appstore(ruta_a_analizar)
    
    # Generar el informe HTML
    generar_html_AppStoreAnalysis(datos, (ruta_a_analizar, existe), salida_html)

if __name__ == "__main__":
    main()