import os
import sqlite3
import datetime
import json
from pathlib import Path

def analizar_db_mensajes(ruta_archivo):
    """
    Analiza un archivo de base de datos de mensajes y extrae la información relevante.
    """
    resultados = {
        "mensajes": [],
        "estadisticas": {
            "total_mensajes": 0,
            "contactos_unicos": 0,
            "fecha_primer_mensaje": None,
            "fecha_ultimo_mensaje": None,
            "contacto_mas_frecuente": None,
            "mensajes_por_fecha": {}
        },
        "metadata": {}
    }
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        return resultados, file_exists
            
    try:
        # Conectar a la base de datos
        conn = sqlite3.connect(ruta_archivo)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Obtener la lista de tablas
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = [row['name'] for row in cursor.fetchall()]
        resultados["metadata"]["tablas"] = tablas
        
        # Buscar tablas relacionadas con mensajes (para iOS sms.db)
        tablas_mensajes = [tabla for tabla in tablas if 'message' in tabla.lower()]
        
        if not tablas_mensajes:
            resultados["metadata"]["error"] = "No se encontraron tablas de mensajes en la base de datos"
            return resultados, file_exists
        
        # En iOS sms.db, la tabla principal suele ser 'message'
        tabla_mensajes = 'message' if 'message' in tablas else tablas_mensajes[0]
        
        # Obtener estructura de la tabla
        cursor.execute(f"PRAGMA table_info({tabla_mensajes});")
        columnas = [row['name'] for row in cursor.fetchall()]
        resultados["metadata"]["columnas"] = columnas
        
        # En iOS, las columnas relevantes suelen ser:
        col_texto = 'text' if 'text' in columnas else None
        col_fecha = 'date' if 'date' in columnas else None
        col_is_sent = 'is_from_me' if 'is_from_me' in columnas else None
        col_handle_id = 'handle_id' if 'handle_id' in columnas else None
        
        # Si no se encuentran columnas básicas, intentar otra estrategia
        if not col_texto or not col_fecha:
            # Obtener primeras filas para inspección
            cursor.execute(f"SELECT * FROM {tabla_mensajes} LIMIT 5;")
            sample_rows = cursor.fetchall()
            resultados["metadata"]["muestra"] = [dict(row) for row in sample_rows]
            resultados["metadata"]["error"] = "No se pudieron identificar columnas necesarias"
            return resultados, file_exists
        
        # Buscar la tabla de contactos (handles en iOS)
        tabla_contactos = 'handle' if 'handle' in tablas else None
        
        # Verificar si podemos relacionar con contactos
        contactos_dict = {}
        if tabla_contactos:
            cursor.execute(f"SELECT ROWID, id FROM {tabla_contactos};")
            for row in cursor.fetchall():
                contactos_dict[row['ROWID']] = row['id']
        
        # Preparar consulta SQL para mensajes
        select_sql = f"""
            SELECT m.{col_texto}, m.{col_fecha}, m.{col_is_sent}, m.{col_handle_id} 
            FROM {tabla_mensajes} m 
            ORDER BY m.{col_fecha}
        """
        
        # Ejecutar consulta
        cursor.execute(select_sql)
        mensajes_raw = cursor.fetchall()
        
        # Procesar mensajes
        contactos = set()
        fecha_primer_mensaje = None
        fecha_ultimo_mensaje = None
        conteo_contactos = {}
        mensajes_por_fecha = {}
        
        for msg in mensajes_raw:
            mensaje = {}
            
            # Verificar que el mensaje tenga texto
            if not msg[col_texto]:
                continue
                
            # Texto del mensaje
            mensaje["texto"] = msg[col_texto]
            
            # Fecha (iOS usa timestamp en segundos desde 2001-01-01)
            timestamp = msg[col_fecha]
            try:
                # iOS usa un offset diferente al UNIX standard (segundos desde 2001-01-01)
                mac_epoch = datetime.datetime(2001, 1, 1)
                if isinstance(timestamp, int) or timestamp.isdigit():
                    timestamp = int(timestamp)
                    # Convertir timestamp de iOS a datetime
                    if timestamp > 1000000000000:  # Si está en milisegundos
                        timestamp = timestamp / 1000
                    fecha = mac_epoch + datetime.timedelta(seconds=timestamp)
                else:
                    # Intentar parsear como string de fecha
                    fecha = datetime.datetime.fromisoformat(str(timestamp).replace('Z', '+00:00'))
                
                mensaje["fecha"] = fecha.strftime("%Y-%m-%d %H:%M:%S")
                
                # Actualizar estadísticas de fechas
                fecha_dia = fecha.strftime("%Y-%m-%d")
                mensajes_por_fecha[fecha_dia] = mensajes_por_fecha.get(fecha_dia, 0) + 1
                
                if not fecha_primer_mensaje or fecha < datetime.datetime.strptime(fecha_primer_mensaje, "%Y-%m-%d %H:%M:%S"):
                    fecha_primer_mensaje = mensaje["fecha"]
                if not fecha_ultimo_mensaje or fecha > datetime.datetime.strptime(fecha_ultimo_mensaje, "%Y-%m-%d %H:%M:%S"):
                    fecha_ultimo_mensaje = mensaje["fecha"]
            except Exception as e:
                mensaje["fecha"] = str(timestamp)
                resultados["metadata"]["error_fecha"] = str(e)
            
            # Determinar si es enviado o recibido
            is_from_me = bool(msg[col_is_sent])
            mensaje["is_from_me"] = is_from_me
            
            # Remitente o destinatario
            handle_id = msg[col_handle_id]
            if handle_id in contactos_dict:
                contacto = contactos_dict[handle_id]
                mensaje["contacto"] = contacto
                contactos.add(contacto)
                
                # Solo contar mensajes recibidos para el contacto más frecuente
                if not is_from_me:
                    conteo_contactos[contacto] = conteo_contactos.get(contacto, 0) + 1
            
            resultados["mensajes"].append(mensaje)
        
        # Actualizar estadísticas
        resultados["estadisticas"]["total_mensajes"] = len(resultados["mensajes"])
        resultados["estadisticas"]["contactos_unicos"] = len(contactos)
        resultados["estadisticas"]["fecha_primer_mensaje"] = fecha_primer_mensaje
        resultados["estadisticas"]["fecha_ultimo_mensaje"] = fecha_ultimo_mensaje
        resultados["estadisticas"]["mensajes_por_fecha"] = mensajes_por_fecha
        
        # Encontrar contacto más frecuente
        if conteo_contactos:
            contacto_mas_frecuente = max(conteo_contactos.items(), key=lambda x: x[1])
            resultados["estadisticas"]["contacto_mas_frecuente"] = {
                "nombre": contacto_mas_frecuente[0],
                "mensajes": contacto_mas_frecuente[1]
            }
        
        conn.close()
                
    except Exception as e:
        resultados["metadata"]["error"] = f"Error analizando {ruta_archivo}: {str(e)}"
    
    return resultados, file_exists

def generar_html_ConversacionAnalysis(datos, archivo_info, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis de la base de datos de mensajes
    en formato de conversación
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception:
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())
    archivo_ruta, archivo_existe = archivo_info

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de Mensajes iOS | iOS Messages Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --sent-msg: #34B7F1;
            --received-msg: #444444;
            --msg-text: #ffffff;
            --date-text: #9e9e9e;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .source-path {{
            font-family: monospace;
            color: var(--text);
        }}

        .source-status {{
            font-size: 0.9rem;
            padding: 0.3rem 0.8rem;
            border-radius: 12px;
        }}

        .source-found {{
            background-color: var(--success);
            color: var(--text);
        }}

        .source-not-found {{
            background-color: var(--danger);
            color: var(--text);
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        /* Estilos para la conversación */
        .chat-container {{
            max-width: 800px;
            margin: 2rem auto;
            border-radius: 15px;
            background-color: var(--card-bg);
            padding: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }}

        .chat-header {{
            text-align: center;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 1rem;
            margin-bottom: 1rem;
        }}

        .chat-messages {{
            padding: 1rem;
            max-height: 600px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }}

        .message {{
            max-width: 70%;
            padding: 0.8rem 1rem;
            border-radius: 18px;
            position: relative;
            word-wrap: break-word;
            font-family: 'Open Sans', sans-serif;
        }}

        .message-time {{
            font-size: 0.7rem;
            margin-top: 5px;
            opacity: 0.8;
            text-align: right;
            color: var(--date-text);
        }}

        .message-sent {{
            background-color: var(--sent-msg);
            color: var(--msg-text);
            align-self: flex-end;
            border-bottom-right-radius: 5px;
        }}

        .message-received {{
            background-color: var(--received-msg);
            color: var(--msg-text);
            align-self: flex-start;
            border-bottom-left-radius: 5px;
        }}

        .date-divider {{
            text-align: center;
            margin: 1rem 0;
            position: relative;
            z-index: 1;
        }}

        .date-divider span {{
            background-color: var(--card-bg);
            padding: 0 10px;
            font-size: 0.8rem;
            color: var(--text-secondary);
        }}

        .date-divider::before {{
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background-color: var(--border-color);
            z-index: -1;
        }}

        .chat-info {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
        }}

        .contact-badge {{
            display: inline-block;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 0.3rem 0.8rem;
            margin: 0.2rem;
            font-size: 0.9rem;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .message {{
                max-width: 85%;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Análisis de Mensajes iOS | iOS Messages Analysis</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
            <p class="subtitle">📁 Ruta del archivo: <code>{archivo_ruta}</code> - <span class="source-status {'source-found' if archivo_existe else 'source-not-found'}">{("Encontrado | Found" if archivo_existe else "No encontrado | Not found")}</span></p>
        </div>"""

    if not datos or not datos.get("mensajes"):
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron mensajes | No messages found</div>
            <p>No se ha podido extraer información de la base de datos. | Could not extract information from the database file.</p>
        </div>"""
        
        # Si hay metadatos con errores, mostrarlos
        if datos and "metadata" in datos and "error" in datos["metadata"]:
            html += f"""
            <div class="warning-card">
                <div class="warning-title">⚠️ Error de análisis | Analysis Error</div>
                <p>{datos["metadata"]["error"]}</p>
            </div>"""
    else:
        # Mostrar información de resumen
        estadisticas = datos.get("estadisticas", {})
        html += f"""
        <div class="chat-info">
            <h2>Resumen de Mensajes iOS | iOS Messages Summary</h2>
            <p>Se encontraron {estadisticas.get("total_mensajes", 0)} mensajes con {estadisticas.get("contactos_unicos", 0)} contactos.</p>
            <p>Periodo: {estadisticas.get("fecha_primer_mensaje", "N/A")} - {estadisticas.get("fecha_ultimo_mensaje", "N/A")}</p>
            {f"<p>Contacto más frecuente: {estadisticas.get('contacto_mas_frecuente', {}).get('nombre', 'N/A')}</p>" if estadisticas.get('contacto_mas_frecuente') else ""}
        </div>"""

        # Mostrar los mensajes en formato de chat
        html += """
        <div class="chat-container">
            <div class="chat-header">
                <h2>Mensajes Recuperados | Recovered Messages</h2>
                <p>Los mensajes están organizados en orden cronológico y por fecha</p>
            </div>
            <div class="chat-messages">"""
        
        # Agrupar mensajes por fecha
        mensajes_por_fecha = {}
        for msg in datos["mensajes"]:
            fecha = msg.get("fecha", "")
            if fecha:
                fecha_dia = fecha.split(" ")[0]  # Extraer solo la fecha sin hora
                if fecha_dia not in mensajes_por_fecha:
                    mensajes_por_fecha[fecha_dia] = []
                mensajes_por_fecha[fecha_dia].append(msg)
        
        # Mostrar los mensajes agrupados por fecha
        for fecha_dia, mensajes in sorted(mensajes_por_fecha.items()):
            html += f"""
            <div class="date-divider">
                <span>{fecha_dia}</span>
            </div>"""
            
            for msg in mensajes:
                # Determinar si el mensaje es enviado o recibido
                es_enviado = msg.get("is_from_me", False)
                
                msg_class = "message-sent" if es_enviado else "message-received"
                hora = msg.get("fecha", "").split(" ")[1] if " " in msg.get("fecha", "") else ""
                
                contacto = msg.get("contacto", "")
                contacto_info = f"<strong>{contacto}</strong><br>" if contacto and not es_enviado else ""
                
                html += f"""
                <div class="message {msg_class}">
                    {contacto_info}{msg.get("texto", "")}
                    <div class="message-time">{hora}</div>
                </div>"""
        
        html += """
            </div>
        </div>"""

    # Pie de página
    html += """
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Ruta del archivo a analizar (según el path proporcionado)
    ruta_a_analizar = "/home/adrian/ForenSage/analyze/ios/private/var/mobile/Library/SMS/sms.db"
    
    # Para la salida, crear ruta relativa
    base_path = Path.home() / "ForenSage"
    salida_html = base_path / "results/iOS_Messages_Analysis.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar archivo
    datos, existe = analizar_db_mensajes(ruta_a_analizar)
    
    # Generar el informe HTML
    generar_html_ConversacionAnalysis(datos, (ruta_a_analizar, existe), str(salida_html))

if __name__ == "__main__":
    main()