import os
import sqlite3
import datetime
from pathlib import Path

def analizar_calendario_sqlite(ruta_archivo):
    """
    Analiza el archivo Calendar.sqlitedb de iOS y extrae información de eventos del calendario.
    / Analyzes iOS Calendar.sqlitedb file and extracts calendar events information.
    """
    resultados = {
        'eventos': [],
        'estadisticas': {},
        'calendarios': []
    }
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        print(f"Error: Archivo no encontrado en {ruta_archivo}")
        return resultados, file_exists
    
    try:
        # Conexión en modo solo lectura
        conn = sqlite3.connect(f"file:{ruta_archivo}?mode=ro", uri=True)
        cursor = conn.cursor()
        
        # 1. Obtener información de calendarios
        cursor.execute("SELECT rowid, title, color FROM Calendar")
        calendarios = cursor.fetchall()
        
        for cal in calendarios:
            # Convertir color de formato iOS (RGB integer) a hexadecimal
            color = f"{cal[2]:06x}" if cal[2] else "5dade2"
            resultados['calendarios'].append({
                'id': cal[0],
                'nombre': cal[1] if cal[1] else "Sin nombre",
                'color': color
            })
        
        # 2. Obtener eventos recientes
        cursor.execute("""
            SELECT 
                e.ROWID, e.summary, e.description, e.location, 
                e.start_date, e.end_date, e.all_day, e.has_alarms,
                e.calendar_id, c.title, c.color
            FROM Event e
            JOIN Calendar c ON e.calendar_id = c.rowid
            ORDER BY e.start_date DESC
            LIMIT 100
        """)
        
        for evento in cursor.fetchall():
            # Convertir timestamps de Apple (segundos desde 2001-01-01)
            inicio = evento[4] + 978307200 if evento[4] else None
            fin = evento[5] + 978307200 if evento[5] else None
            color = f"{evento[10]:06x}" if evento[10] else "5dade2"
            
            resultados['eventos'].append({
                'id': evento[0],
                'titulo': evento[1] if evento[1] else "Sin título",
                'descripcion': evento[2] if evento[2] else "Sin descripción",
                'ubicacion': evento[3] if evento[3] else "Sin ubicación",
                'inicio': datetime.datetime.fromtimestamp(inicio) if inicio else None,
                'fin': datetime.datetime.fromtimestamp(fin) if fin else None,
                'todo_el_dia': bool(evento[6]),
                'tiene_alarmas': bool(evento[7]),
                'calendario_id': evento[8],
                'calendario_nombre': evento[9] if evento[9] else "Sin nombre",
                'color': color
            })
        
        # 3. Calcular estadísticas
        cursor.execute("SELECT COUNT(*) FROM Event")
        resultados['estadisticas']['total_eventos'] = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM Event WHERE all_day = 1")
        resultados['estadisticas']['eventos_todo_el_dia'] = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM Event WHERE has_alarms = 1")
        resultados['estadisticas']['eventos_con_alarmas'] = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT calendar_id) FROM Event")
        resultados['estadisticas']['calendarios_utilizados'] = cursor.fetchone()[0]
        
        conn.close()
        
    except sqlite3.Error as e:
        print(f"Error de base de datos: {e}")
        # Intentar identificar estructura de la base de datos
        try:
            conn = sqlite3.connect(f"file:{ruta_archivo}?mode=ro", uri=True)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            print("Tablas disponibles:", cursor.fetchall())
            conn.close()
        except:
            pass
        return resultados, False
        
    except Exception as e:
        print(f"Error inesperado: {e}")
        return resultados, False
    
    return resultados, True

def generar_html_calendario(datos, archivo_info, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis del Calendar.sqlitedb
    / Generates HTML report with Calendar.sqlitedb analysis results
    """
    # Crear directorio si no existe
    os.makedirs(os.path.dirname(ruta_salida), exist_ok=True)
    
    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_archivo, archivo_existe = archivo_info

    # Función para formatear fechas
    def formato_fecha(fecha):
        if not fecha:
            return "Desconocido"
        return fecha.strftime("%d/%m/%Y %H:%M")

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iOS Calendar Analysis | Análisis de Calendario</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Roboto', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            animation: fadeIn 0.5s ease-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }}

        .title {{
            font-family: 'Montserrat', sans-serif;
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0.5rem 0;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            font-size: 1.1rem;
            margin-top: 0;
        }}

        .stats-container {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
        }}

        .stat-card {{
            background: var(--card-bg);
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            border-top: 4px solid var(--accent);
        }}

        .stat-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }}

        .stat-value {{
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--accent-light);
            margin: 0.5rem 0;
            font-family: 'Montserrat', sans-serif;
        }}

        .stat-label {{
            font-size: 0.95rem;
            color: var(--text-secondary);
            margin: 0;
        }}

        .events-container {{
            margin: 3rem 0;
        }}

        .section-title {{
            font-family: 'Montserrat', sans-serif;
            color: var(--accent-light);
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--border-color);
            display: flex;
            align-items: center;
        }}

        .section-title svg {{
            margin-right: 0.8rem;
        }}

        .event-card {{
            background: var(--card-bg);
            border-radius: 10px;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            transition: all 0.3s ease;
        }}

        .event-card:hover {{
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }}

        .event-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 1.5rem;
            border-left: 5px solid;
        }}

        .event-title {{
            font-family: 'Montserrat', sans-serif;
            font-size: 1.3rem;
            font-weight: 600;
            margin: 0;
            color: var(--accent-light);
            flex-grow: 1;
        }}

        .calendar-tag {{
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-left: 1rem;
            background-color: var(--primary-light);
            color: white;
        }}

        .event-body {{
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--border-color);
        }}

        .event-details {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1rem;
        }}

        .detail-item {{
            margin-bottom: 0.5rem;
        }}

        .detail-label {{
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-bottom: 0.2rem;
            display: flex;
            align-items: center;
        }}

        .detail-label svg {{
            margin-right: 0.5rem;
            width: 16px;
            height: 16px;
        }}

        .detail-value {{
            font-size: 0.95rem;
            word-break: break-word;
            padding-left: 1.5rem;
        }}

        .footer {{
            text-align: center;
            margin-top: 3rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border-color);
            color: var(--text-secondary);
            font-size: 0.9rem;
        }}

        .file-info {{
            background: var(--card-bg);
            padding: 1rem;
            border-radius: 8px;
            margin-top: 2rem;
            font-family: monospace;
            font-size: 0.9rem;
            word-break: break-all;
        }}

        .no-events {{
            text-align: center;
            padding: 2rem;
            background: var(--card-bg);
            border-radius: 10px;
            border-left: 5px solid var(--warning);
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .event-details {{
                grid-template-columns: 1fr;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">iOS Calendar Analysis</h1>
            <p class="subtitle">Análisis de eventos del calendario | Generated on {ahora}</p>
        </div>"""

    if not datos['eventos']:
        html += """
        <div class="no-events">
            <h3>⚠️ No se encontraron eventos</h3>
            <p>No se pudieron extraer eventos del archivo Calendar.sqlitedb.</p>
        </div>"""
    else:
        # Mostrar estadísticas
        html += """
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-value">{0}</div>
                <div class="stat-label">Total de Eventos</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{1}</div>
                <div class="stat-label">Eventos Todo el Día</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{2}</div>
                <div class="stat-label">Eventos con Alarmas</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{3}</div>
                <div class="stat-label">Calendarios Utilizados</div>
            </div>
        </div>""".format(
            datos['estadisticas'].get('total_eventos', 0),
            datos['estadisticas'].get('eventos_todo_el_dia', 0),
            datos['estadisticas'].get('eventos_con_alarmas', 0),
            datos['estadisticas'].get('calendarios_utilizados', 0)
        )

        # Mostrar eventos
        html += """
        <div class="events-container">
            <h2 class="section-title">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
                Eventos Recientes
            </h2>"""

        for evento in datos['eventos']:
            html += f"""
            <div class="event-card" style="border-left-color: #{evento['color']}">
                <div class="event-header">
                    <h3 class="event-title">{evento['titulo']}</h3>
                    <span class="calendar-tag" style="background-color: #{evento['color']}">{evento['calendario_nombre']}</span>
                </div>
                <div class="event-body">
                    <div class="event-details">
                        <div class="detail-item">
                            <div class="detail-label">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <polyline points="12 6 12 12 16 14"></polyline>
                                </svg>
                                Inicio
                            </div>
                            <div class="detail-value">{formato_fecha(evento['inicio'])}</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <polyline points="12 6 12 12 16 14"></polyline>
                                </svg>
                                Fin
                            </div>
                            <div class="detail-value">{formato_fecha(evento['fin'])}</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M3 3h18v18H3z"></path>
                                </svg>
                                Todo el día
                            </div>
                            <div class="detail-value">{'Sí' if evento['todo_el_dia'] else 'No'}</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="12" r="3"></circle>
                                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                                </svg>
                                Alarmas
                            </div>
                            <div class="detail-value">{'Sí' if evento['tiene_alarmas'] else 'No'}</div>
                        </div>"""

            if evento['ubicacion'] != "Sin ubicación":
                html += f"""
                        <div class="detail-item">
                            <div class="detail-label">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                    <circle cx="12" cy="10" r="3"></circle>
                                </svg>
                                Ubicación
                            </div>
                            <div class="detail-value">{evento['ubicacion']}</div>
                        </div>"""

            if evento['descripcion'] != "Sin descripción":
                html += f"""
                        <div class="detail-item" style="grid-column: 1 / -1">
                            <div class="detail-label">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                    <polyline points="14 2 14 8 20 8"></polyline>
                                    <line x1="16" y1="13" x2="8" y2="13"></line>
                                    <line x1="16" y1="17" x2="8" y2="17"></line>
                                    <polyline points="10 9 9 9 8 9"></polyline>
                                </svg>
                                Descripción
                            </div>
                            <div class="detail-value">{evento['descripcion']}</div>
                        </div>"""

            html += """
                    </div>
                </div>
            </div>"""

        html += """
        </div>"""

    # Footer con información del archivo
    status = "Encontrado" if archivo_existe else "No encontrado"
    html += f"""
        <div class="footer">
            <div class="file-info">
                <p><strong>Archivo analizado:</strong> {ruta_archivo}</p>
                <p><strong>Estado:</strong> {status}</p>
                <p><strong>Generado el:</strong> {ahora}</p>
            </div>
            <p style="margin-top: 1.5rem;">ForenSage © 2025 - Herramienta Forense para iOS</p>
        </div>
    </div>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"Reporte generado exitosamente: {ruta_salida}")
        return True
    except Exception as e:
        print(f"Error al guardar el reporte: {e}")
        return False

def main():
    # Configuración de rutas
    base_path = Path.home() / "ForenSage"
    ruta_a_analizar = base_path / "analyze/ios/private/var/mobile/Library/Calendar/Calendar.sqlitedb"
    salida_html = base_path / "results/IOS_calendar_Info.html"
    
    print(f"Analizando archivo: {ruta_a_analizar}")
    
    # Verificar si el archivo existe
    if not ruta_a_analizar.exists():
        print(f"Error: El archivo no existe en la ruta especificada")
        # Crear un reporte vacío para indicar el error
        generar_html_calendario(
            {'eventos': [], 'estadisticas': {}, 'calendarios': []},
            (str(ruta_a_analizar), False),
            str(salida_html)
        )
        return
    
    # Analizar el archivo
    datos, exito = analizar_calendario_sqlite(str(ruta_a_analizar))
    
    # Generar el reporte HTML
    generar_html_calendario(datos, (str(ruta_a_analizar), exito), str(salida_html))

if __name__ == "__main__":
    main()