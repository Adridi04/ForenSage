import os
import plistlib
import datetime
from pathlib import Path

def analizar_system_version_plist(ruta_archivo):
    """
    Analiza el archivo SystemVersion.plist de iOS y extrae la información del sistema.
    / Analyzes iOS SystemVersion.plist file and extracts system information.
    """
    resultados = {}
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        return resultados, file_exists
            
    try:
        # Leer el archivo plist / Read plist file
        with open(ruta_archivo, 'rb') as fp:
            pl = plistlib.load(fp)
        
        # Extraer información relevante / Extract relevant information
        resultados = {
            "ProductName": pl.get("ProductName", "Unknown/Desconocido"),
            "ProductVersion": pl.get("ProductVersion", "Unknown/Desconocido"),
            "BuildVersion": pl.get("BuildVersion", "Unknown/Desconocido"),
            "ProductBuildVersion": pl.get("ProductBuildVersion", "Unknown/Desconocido"),
            "ProductCopyright": pl.get("ProductCopyright", "Unknown/Desconocido"),
            "ReleaseType": pl.get("ReleaseType", "Unknown/Desconocido"),
        }
        
        # Añadir cualquier otra información relevante / Add any other relevant information
        for key, value in pl.items():
            if key not in resultados:
                resultados[key] = str(value)
                
    except Exception as e:
        print(f"Error analizando {ruta_archivo}: {e}")
    
    return resultados, file_exists

def generar_html_SystemInfo1(datos, archivo_info, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis del SystemVersion.plist
    / Generates HTML report with SystemVersion.plist analysis results
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception:
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(ruta_salida).resolve())
    archivo_ruta, archivo_existe = archivo_info

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iOS System Version | Versión del Sistema iOS</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .source-container {{
            margin-top: 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }}

        .source-card {{
            background-color: var(--primary);
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }}

        .source-path {{
            font-family: monospace;
            color: var(--text);
        }}

        .source-status {{
            font-size: 0.9rem;
            padding: 0.3rem 0.8rem;
            border-radius: 12px;
        }}

        .source-found {{
            background-color: var(--success);
            color: var(--text);
        }}

        .source-not-found {{
            background-color: var(--danger);
            color: var(--text);
        }}

        .circles-container {{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 2rem;
            margin: 3rem 0;
        }}

        .data-circle {{
            position: relative;
            width: 180px;
            height: 180px;
            border-radius: 50%;
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            text-align: center;
            transition: all 0.3s ease;
            overflow: hidden;
        }}

        .data-circle:hover {{
            transform: translateY(-10px) scale(1.05);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.6);
        }}

        .data-circle::before {{
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                0deg,
                transparent,
                transparent,
                var(--accent),
                var(--accent)
            );
            transform-origin: bottom right;
            animation: rotate 6s linear infinite;
            z-index: -1;
            opacity: 0.3;
        }}

        @keyframes rotate {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}

        .data-label {{
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }}

        .data-value {{
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--accent-light);
            word-break: break-word;
            max-width: 100%;
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .lang-toggle {{
            background-color: var(--card-bg);
            color: var(--text);
            border: 1px solid var(--primary-light);
            border-radius: 20px;
            padding: 0.5rem 1rem;
            cursor: pointer;
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-left: 1rem;
        }}

        .lang-toggle:hover {{
            border-color: var(--accent);
            transform: translateY(-2px);
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        .ios-info-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 2rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
        }}

        .ios-version {{
            font-size: 2.5rem;
            font-weight: 700;
            margin: 1rem 0;
            color: var(--accent-light);
        }}

        .ios-name {{
            font-size: 1.5rem;
            color: var(--text);
            margin-bottom: 1rem;
        }}

        .ios-build {{
            font-size: 1rem;
            color: var(--text-secondary);
            font-family: monospace;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .data-circle {{
                width: 150px;
                height: 150px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">iOS System Version | Versión del Sistema iOS</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
        </div>"""

    if not datos:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron datos | No data found</div>
            <p>No se ha podido extraer información del archivo SystemVersion.plist. | Could not extract information from SystemVersion.plist file.</p>
        </div>"""
    else:
        # Mostrar información de iOS destacada
        html += f"""
        <div class="ios-info-card">
            <div class="ios-name">{datos.get("ProductName", "iOS")}</div>
            <div class="ios-version">{datos.get("ProductVersion", "Unknown/Desconocido")}</div>
            <div class="ios-build">Build {datos.get("BuildVersion", "")} ({datos.get("ProductBuildVersion", "")})</div>
        </div>

        <div class="circles-container">"""
        
        # Crear círculos para cada propiedad del sistema
        for key, value in datos.items():
            label_map = {
                "ProductName": "Nombre del Producto / Product Name",
                "ProductVersion": "Versión / Version",
                "BuildVersion": "Versión Build / Build Version",
                "ProductBuildVersion": "Build ID / Build ID",
                "ProductCopyright": "Copyright / Copyright",
                "ReleaseType": "Tipo de Lanzamiento / Release Type"
            }
            
            label = label_map.get(key, f"{key}")
            html += f"""
            <div class="data-circle">
                <div class="data-label">{label}</div>
                <div class="data-value">{value}</div>
            </div>"""
        
        html += """
        </div>"""

    # Añadir información del archivo analizado en el footer
    status_text = "Encontrado | Found" if archivo_existe else "No encontrado | Not found"
    html += f"""
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
            <p>📁 Archivo analizado | Analyzed file: <code>{archivo_ruta}</code> ({status_text})</p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Ruta del archivo a analizar (ruta relativa desde el directorio del script)
    base_path = Path.home() / "ForenSage"
    ruta_a_analizar = base_path / "analyze/ios/System/Library/CoreServices/SystemVersion.plist"
    
    # Para la salida, crear ruta relativa
    salida_html = base_path / "results/IOS_SystemInfo1.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar archivo
    datos, existe = analizar_system_version_plist(str(ruta_a_analizar))
    
    # Generar el informe HTML
    generar_html_SystemInfo1(datos, (str(ruta_a_analizar), existe), str(salida_html))

if __name__ == "__main__":
    main()