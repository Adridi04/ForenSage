import os
import sqlite3
import datetime
import json
from pathlib import Path

def analizar_db_cellular_usage(ruta_archivo):
    """
    Analiza un archivo de base de datos de uso celular y extrae la información relevante.
    """
    resultados = {
        "datos_celulares": [],
        "estadisticas": {
            "total_registros": 0,
            "aplicaciones_unicas": 0,
            "fecha_primer_registro": None,
            "fecha_ultimo_registro": None,
            "app_mas_trafico": None,
            "total_datos_enviados": 0,
            "total_datos_recibidos": 0,
            "uso_por_fecha": {}
        },
        "metadata": {}
    }
    file_exists = os.path.exists(ruta_archivo)
    
    if not file_exists:
        return resultados, file_exists
            
    try:
        # Conectar a la base de datos
        conn = sqlite3.connect(ruta_archivo)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Obtener la lista de tablas
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tablas = [row['name'] for row in cursor.fetchall()]
        resultados["metadata"]["tablas"] = tablas
        
        # Buscar tablas relacionadas con uso celular
        tablas_cellular = [tabla for tabla in tablas if 'cellular' in tabla.lower() or 'usage' in tabla.lower()]
        
        if not tablas_cellular:
            resultados["metadata"]["error"] = "No se encontraron tablas de uso celular en la base de datos"
            return resultados, file_exists
        
        # Explorar cada tabla relevante
        for tabla in tablas_cellular:
            # Obtener estructura de la tabla
            cursor.execute(f"PRAGMA table_info({tabla});")
            columnas = [row['name'] for row in cursor.fetchall()]
            resultados["metadata"][f"columnas_{tabla}"] = columnas
            
            # Obtener primeras filas para inspección
            cursor.execute(f"SELECT * FROM {tabla} LIMIT 5;")
            sample_rows = cursor.fetchall()
            resultados["metadata"][f"muestra_{tabla}"] = [dict(row) for row in sample_rows]
            
            # Identificar columnas relevantes (pueden variar según la estructura)
            try:
                # Intentar encontrar columnas de datos celulares
                col_app = next((col for col in columnas if 'app' in col.lower() or 'bundle' in col.lower()), None)
                col_rx = next((col for col in columnas if 'rx' in col.lower() or 'received' in col.lower()), None)
                col_tx = next((col for col in columnas if 'tx' in col.lower() or 'sent' in col.lower()), None)
                col_fecha = next((col for col in columnas if 'date' in col.lower() or 'time' in col.lower()), None)
                
                if not all([col_app, col_rx, col_tx]):
                    continue  # Si no se encuentran las columnas básicas, pasar a la siguiente tabla
                
                # Preparar consulta SQL
                if col_fecha:
                    select_sql = f"SELECT {col_app}, {col_rx}, {col_tx}, {col_fecha} FROM {tabla}"
                else:
                    select_sql = f"SELECT {col_app}, {col_rx}, {col_tx} FROM {tabla}"
                
                # Ejecutar consulta
                cursor.execute(select_sql)
                registros = cursor.fetchall()
                
                # Procesar registros
                aplicaciones = set()
                app_trafico = {}
                fecha_primer_registro = None
                fecha_ultimo_registro = None
                uso_por_fecha = {}
                
                for reg in registros:
                    registro = {}
                    
                    # Nombre de la aplicación
                    app_name = reg[col_app]
                    if not app_name:
                        continue
                    
                    registro["aplicacion"] = app_name
                    aplicaciones.add(app_name)
                    
                    # Datos enviados y recibidos (en bytes)
                    datos_rx = int(reg[col_rx]) if reg[col_rx] is not None else 0
                    datos_tx = int(reg[col_tx]) if reg[col_tx] is not None else 0
                    
                    registro["datos_recibidos"] = datos_rx
                    registro["datos_enviados"] = datos_tx
                    registro["datos_total"] = datos_rx + datos_tx
                    
                    # Actualizar estadísticas de tráfico por app
                    if app_name not in app_trafico:
                        app_trafico[app_name] = {"rx": 0, "tx": 0, "total": 0}
                    app_trafico[app_name]["rx"] += datos_rx
                    app_trafico[app_name]["tx"] += datos_tx
                    app_trafico[app_name]["total"] += datos_rx + datos_tx
                    
                    # Fecha (si existe)
                    if col_fecha:
                        timestamp = reg[col_fecha]
                        try:
                            # Intentar convertir el timestamp según el formato
                            if isinstance(timestamp, int):
                                # iOS puede usar segundos desde 2001-01-01
                                if timestamp > 1000000000000:  # Si está en milisegundos
                                    timestamp = timestamp / 1000
                                    
                                # Determinar si es un timestamp de UNIX o de Apple
                                if timestamp > 1000000000:  # Es UNIX timestamp (segundos desde 1970)
                                    fecha = datetime.datetime.fromtimestamp(timestamp)
                                else:  # Es Apple timestamp (segundos desde 2001)
                                    mac_epoch = datetime.datetime(2001, 1, 1)
                                    fecha = mac_epoch + datetime.timedelta(seconds=timestamp)
                            else:
                                # Intentar parsear como string de fecha
                                fecha = datetime.datetime.fromisoformat(str(timestamp).replace('Z', '+00:00'))
                            
                            fecha_str = fecha.strftime("%Y-%m-%d %H:%M:%S")
                            registro["fecha"] = fecha_str
                            
                            # Actualizar estadísticas de fechas
                            fecha_dia = fecha.strftime("%Y-%m-%d")
                            if fecha_dia not in uso_por_fecha:
                                uso_por_fecha[fecha_dia] = {"rx": 0, "tx": 0, "total": 0}
                            uso_por_fecha[fecha_dia]["rx"] += datos_rx
                            uso_por_fecha[fecha_dia]["tx"] += datos_tx
                            uso_por_fecha[fecha_dia]["total"] += datos_rx + datos_tx
                            
                            if not fecha_primer_registro or fecha < datetime.datetime.strptime(fecha_primer_registro, "%Y-%m-%d %H:%M:%S"):
                                fecha_primer_registro = fecha_str
                            if not fecha_ultimo_registro or fecha > datetime.datetime.strptime(fecha_ultimo_registro, "%Y-%m-%d %H:%M:%S"):
                                fecha_ultimo_registro = fecha_str
                        except Exception as e:
                            registro["fecha"] = str(timestamp)
                            resultados["metadata"]["error_fecha"] = str(e)
                    
                    resultados["datos_celulares"].append(registro)
                
                # Actualizar estadísticas globales
                resultados["estadisticas"]["total_registros"] += len(resultados["datos_celulares"])
                resultados["estadisticas"]["aplicaciones_unicas"] = len(aplicaciones)
                resultados["estadisticas"]["fecha_primer_registro"] = fecha_primer_registro
                resultados["estadisticas"]["fecha_ultimo_registro"] = fecha_ultimo_registro
                
                # Calcular totales
                total_rx = sum(app["rx"] for app in app_trafico.values())
                total_tx = sum(app["tx"] for app in app_trafico.values())
                resultados["estadisticas"]["total_datos_enviados"] = total_tx
                resultados["estadisticas"]["total_datos_recibidos"] = total_rx
                
                # Encontrar app con más tráfico
                if app_trafico:
                    app_max_trafico = max(app_trafico.items(), key=lambda x: x[1]["total"])
                    resultados["estadisticas"]["app_mas_trafico"] = {
                        "nombre": app_max_trafico[0],
                        "datos_total": app_max_trafico[1]["total"],
                        "datos_enviados": app_max_trafico[1]["tx"],
                        "datos_recibidos": app_max_trafico[1]["rx"]
                    }
                
                resultados["estadisticas"]["uso_por_fecha"] = uso_por_fecha
            
            except Exception as e:
                resultados["metadata"][f"error_analisis_{tabla}"] = str(e)
        
        conn.close()
                
    except Exception as e:
        resultados["metadata"]["error"] = f"Error analizando {ruta_archivo}: {str(e)}"
    
    return resultados, file_exists

def formatear_tamano(tamano_bytes):
    """
    Formatea el tamaño en bytes a una unidad más legible (KB, MB, GB)
    """
    if tamano_bytes < 1024:
        return f"{tamano_bytes} B"
    elif tamano_bytes < 1024 * 1024:
        return f"{tamano_bytes/1024:.2f} KB"
    elif tamano_bytes < 1024 * 1024 * 1024:
        return f"{tamano_bytes/(1024*1024):.2f} MB"
    else:
        return f"{tamano_bytes/(1024*1024*1024):.2f} GB"

def generar_html_CellularUsageAnalysis(datos, archivo_info, ruta_salida):
    """
    Genera un archivo HTML con los resultados del análisis de la base de datos de uso celular
    en formato de burbujas
    """
    if not os.path.exists(os.path.dirname(ruta_salida)):
        try:
            os.makedirs(os.path.dirname(ruta_salida))
        except Exception:
            return

    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_str = str(Path(archivo_info[0]).resolve())
    archivo_existe = archivo_info[1]

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de Uso Celular iOS | iOS Cellular Usage Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50;
            --primary: #34495e;
            --primary-light: #4a6278;
            --accent: #3498db;
            --accent-light: #5dade2;
            --text: #ecf0f1;
            --text-secondary: #bdc3c7;
            --background: #1a1a2e;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --upload: #e74c3c;
            --download: #3498db;
            --data-text: #ffffff;
            --date-text: #9e9e9e;
        }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }}

        .container {{
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
        }}

        .title {{
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}

        .source-path {{
            font-family: monospace;
            color: var(--text);
        }}

        .source-status {{
            font-size: 0.9rem;
            padding: 0.3rem 0.8rem;
            border-radius: 12px;
        }}

        .source-found {{
            background-color: var(--success);
            color: var(--text);
        }}

        .source-not-found {{
            background-color: var(--danger);
            color: var(--text);
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }}

        .warning-card {{
            background-color: var(--card-bg);
            border-left: 4px solid var(--warning);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }}

        /* Estilos para los datos de uso celular */
        .usage-container {{
            max-width: 800px;
            margin: 2rem auto;
            border-radius: 15px;
            background-color: var(--card-bg);
            padding: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }}

        .usage-header {{
            text-align: center;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 1rem;
            margin-bottom: 1rem;
        }}

        .usage-entries {{
            padding: 1rem;
            max-height: 600px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }}

        .app-usage {{
            border-radius: 15px;
            padding: 1.2rem;
            position: relative;
            word-wrap: break-word;
            font-family: 'Open Sans', sans-serif;
            background-color: var(--primary);
            margin-bottom: 1rem;
        }}

        .app-name {{
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
        }}

        .data-bubbles {{
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }}

        .data-bubble {{
            padding: 0.8rem 1rem;
            border-radius: 18px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            color: var(--data-text);
        }}

        .upload-bubble {{
            background-color: var(--upload);
        }}

        .download-bubble {{
            background-color: var(--download);
        }}

        .date-bubble {{
            background-color: var(--primary-dark);
            font-size: 0.8rem;
            padding: 0.4rem 0.8rem;
        }}

        .date-divider {{
            text-align: center;
            margin: 1rem 0;
            position: relative;
            z-index: 1;
        }}

        .date-divider span {{
            background-color: var(--card-bg);
            padding: 0 10px;
            font-size: 0.8rem;
            color: var(--text-secondary);
        }}

        .date-divider::before {{
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background-color: var(--border-color);
            z-index: -1;
        }}

        .usage-info {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px;
            padding: 1.5rem;
            margin: 2rem auto;
            max-width: 600px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
        }}

        .app-badge {{
            display: inline-block;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 0.3rem 0.8rem;
            margin: 0.2rem;
            font-size: 0.9rem;
        }}

        .usage-chart {{
            margin: 2rem auto;
            padding: 1rem;
            background-color: var(--card-bg);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }}

        .bar-chart {{
            height: 250px;
            display: flex;
            align-items: flex-end;
            justify-content: space-around;
            padding: 1rem 0;
        }}

        .bar {{
            width: 40px;
            background: linear-gradient(to top, var(--download), var(--upload));
            border-radius: 5px 5px 0 0;
            position: relative;
            transition: height 0.3s ease;
        }}

        .bar-label {{
            position: absolute;
            bottom: -25px;
            left: 50%;
            transform: translateX(-50%);
            text-align: center;
            font-size: 0.7rem;
            color: var(--text-secondary);
        }}

        .bar-value {{
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            text-align: center;
            font-size: 0.7rem;
            color: var(--text);
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{
                padding: 1rem;
            }}
            .title {{
                font-size: 2rem;
            }}
            .data-bubbles {{
                flex-direction: column;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Análisis de Uso Celular iOS | iOS Cellular Usage Analysis</h1>
            <p class="subtitle">📅 Generado el {ahora} | Generated on {ahora}</p>
            <p class="subtitle">📁 Ruta del archivo: <code>{ruta_str}</code> - <span class="source-status {'source-found' if archivo_existe else 'source-not-found'}">{("Encontrado | Found" if archivo_existe else "No encontrado | Not found")}</span></p>
        </div>"""

    if not datos or not datos.get("datos_celulares"):
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No se encontraron datos de uso celular | No cellular usage data found</div>
            <p>No se ha podido extraer información de la base de datos. | Could not extract information from the database file.</p>
        </div>"""
        
        # Si hay metadatos con errores, mostrarlos
        if datos and "metadata" in datos and "error" in datos["metadata"]:
            html += f"""
            <div class="warning-card">
                <div class="warning-title">⚠️ Error de análisis | Analysis Error</div>
                <p>{datos["metadata"]["error"]}</p>
            </div>"""
    else:
        # Mostrar información de resumen
        estadisticas = datos.get("estadisticas", {})
        total_rx = formatear_tamano(estadisticas.get("total_datos_recibidos", 0))
        total_tx = formatear_tamano(estadisticas.get("total_datos_enviados", 0))
        total_datos = formatear_tamano(estadisticas.get("total_datos_recibidos", 0) + estadisticas.get("total_datos_enviados", 0))
        
        html += f"""
        <div class="usage-info">
            <h2>Resumen de Uso Celular iOS | iOS Cellular Usage Summary</h2>
            <p>Se encontraron {estadisticas.get("total_registros", 0)} registros de {estadisticas.get("aplicaciones_unicas", 0)} aplicaciones.</p>
            <p>Periodo: {estadisticas.get("fecha_primer_registro", "N/A")} - {estadisticas.get("fecha_ultimo_registro", "N/A")}</p>
            <p>Total de datos: {total_datos} (↓ {total_rx} recibidos, ↑ {total_tx} enviados)</p>"""
        
        # Mostrar app con más tráfico si existe
        app_mas_trafico = estadisticas.get("app_mas_trafico", {})
        if app_mas_trafico:
            app_nombre = app_mas_trafico.get("nombre", "N/A")
            app_total = formatear_tamano(app_mas_trafico.get("datos_total", 0))
            html += f"""
            <p>Aplicación con más tráfico: <span class="app-badge">{app_nombre}</span> ({app_total})</p>"""
        
        html += """
        </div>"""

        # Crear gráfico de uso por fecha si existen datos temporales
        uso_por_fecha = estadisticas.get("uso_por_fecha", {})
        if uso_por_fecha:
            # Tomar las últimas 10 fechas como máximo para el gráfico
            fechas = sorted(uso_por_fecha.keys())[-10:]
            max_valor = max([uso_por_fecha[fecha]["total"] for fecha in fechas])
            
            html += """
        <div class="usage-chart">
            <h3 style="text-align:center">Uso de datos por fecha | Data usage by date</h3>
            <div class="bar-chart">"""
            
            for fecha in fechas:
                valor = uso_por_fecha[fecha]["total"]
                altura = int((valor / max_valor) * 200) if max_valor > 0 else 10  # Altura máxima 200px
                valor_formateado = formatear_tamano(valor)
                
                html += f"""
                <div class="bar" style="height:{altura}px">
                    <span class="bar-value">{valor_formateado}</span>
                    <span class="bar-label">{fecha}</span>
                </div>"""
            
            html += """
            </div>
        </div>"""

        # Mostrar los datos de uso celular agrupados por app
        html += """
        <div class="usage-container">
            <div class="usage-header">
                <h2>Datos de Uso Celular | Cellular Usage Data</h2>
                <p>Los datos se muestran agrupados por aplicación</p>
            </div>
            <div class="usage-entries">"""
        
        # Agrupar datos por aplicación
        datos_por_app = {}
        for registro in datos["datos_celulares"]:
            app = registro.get("aplicacion", "Desconocida")
            if app not in datos_por_app:
                datos_por_app[app] = []
            datos_por_app[app].append(registro)
        
        # Mostrar cada aplicación y sus datos
        for app, registros in datos_por_app.items():
            # Calcular totales para esta app
            total_rx_app = sum(reg.get("datos_recibidos", 0) for reg in registros)
            total_tx_app = sum(reg.get("datos_enviados", 0) for reg in registros)
            
            html += f"""
            <div class="app-usage">
                <div class="app-name">{app}</div>
                <div class="data-bubbles">
                    <div class="data-bubble download-bubble">↓ {formatear_tamano(total_rx_app)}</div>
                    <div class="data-bubble upload-bubble">↑ {formatear_tamano(total_tx_app)}</div>"""
            
            # Mostrar fecha si disponible (última actividad)
            fechas = [reg.get("fecha") for reg in registros if reg.get("fecha")]
            if fechas:
                ultima_fecha = max(fechas)
                html += f"""
                    <div class="date-bubble">📅 {ultima_fecha}</div>"""
            
            html += """
                </div>
            </div>"""
        
        html += """
            </div>
        </div>"""

    # Pie de página
    html += """
        <div class="footer">
            <p>📁 Ruta del informe: <code id="reportPath"></code></p>
            <p>📁 Report path: <code id="reportPathEn"></code></p>
        </div>
        <footer class="footer">
            <p> ForenSage © 2025 - Forensic Tool</p>
        </footer>
    </div>

    <script>
        document.getElementById('reportPath').textContent = document.location.pathname;
        document.getElementById('reportPathEn').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(ruta_salida, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Informe generado en: {ruta_salida}")
        return True
    except Exception as e:
        print(f"❌ Error al generar el informe: {e}")
        return False

def main():
    # Ruta del archivo a analizar (usando rutas relativas como se solicitó)
    ruta_a_analizar = os.path.expanduser("~/ForenSage/analyze/ios/private/var/wireless/Library/Databases/CellularUsage.db")
    
    # Para la salida, crear ruta relativa
    base_path = Path.home() / "ForenSage"
    salida_html = base_path / "results/iOS_SimUsage.html"
    
    # Asegurar que el directorio de salida existe
    os.makedirs(os.path.dirname(salida_html), exist_ok=True)
    
    # Analizar archivo
    datos, existe = analizar_db_cellular_usage(ruta_a_analizar)
    
    # Generar el informe HTML
    generar_html_CellularUsageAnalysis(datos, (ruta_a_analizar, existe), str(salida_html))

if __name__ == "__main__":
    main()