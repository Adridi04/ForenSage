import os
import datetime
from pathlib import Path
import re
import hashlib
import imghdr
import base64
import mimetypes

def analyze_images(directory_path):
    """Analyzes all image files in the given directory and extracts their metadata."""
    results = {}
    
    try:
        if not os.path.exists(directory_path):
            print(f"Error: Directory not found: {directory_path}")
            return results, False
        
        # Get all files in directory
        files = [f for f in os.listdir(directory_path) if os.path.isfile(os.path.join(directory_path, f))]
        
        if not files:
            print(f"No files found in: {directory_path}")
            return results, True
        
        for file_name in files:
            file_path = os.path.join(directory_path, file_name)
            file_data = {}
            
            try:
                # Get file metadata
                file_stats = os.stat(file_path)
                file_size = file_stats.st_size
                creation_time = datetime.datetime.fromtimestamp(file_stats.st_ctime)
                modified_time = datetime.datetime.fromtimestamp(file_stats.st_mtime)
                access_time = datetime.datetime.fromtimestamp(file_stats.st_atime)
                
                # Check if it's an image file
                image_type = imghdr.what(file_path)
                
                # Get md5 hash of file
                md5_hash = calculate_file_hash(file_path)
                
                # Determine MIME type
                mime_type = mimetypes.guess_type(file_path)[0]
                if not mime_type and image_type:
                    mime_type = f"image/{image_type}"
                elif not mime_type:
                    mime_type = "application/octet-stream"
                
                # Get image base64 for preview (if it's an image)
                preview_base64 = None
                if image_type and file_size < 10000000:  # Only encode if < 10MB
                    try:
                        with open(file_path, "rb") as img_file:
                            preview_base64 = base64.b64encode(img_file.read()).decode('utf-8')
                    except Exception as e:
                        print(f"Error encoding image: {e}")
                
                file_data = {
                    "file_size": file_size,
                    "file_size_formatted": format_file_size(file_size),
                    "creation_time": creation_time,
                    "modified_time": modified_time,
                    "access_time": access_time,
                    "image_type": image_type,
                    "mime_type": mime_type,
                    "md5_hash": md5_hash,
                    "preview_base64": preview_base64,
                    "is_image": image_type is not None
                }
                
                results[file_name] = {
                    "data": file_data,
                    "file_path": file_path,
                    "file_exists": True
                }
                
            except Exception as e:
                print(f"Error analyzing {file_path}: {e}")
                results[file_name] = {
                    "data": {},
                    "file_path": file_path,
                    "file_exists": os.path.exists(file_path),
                    "error": str(e)
                }
        
        return results, True
        
    except Exception as e:
        print(f"General error: {e}")
        return results, False

def calculate_file_hash(file_path):
    """Calculate MD5 hash of a file."""
    md5_hash = hashlib.md5()
    with open(file_path, "rb") as f:
        # Read in chunks to handle large files
        for chunk in iter(lambda: f.read(4096), b""):
            md5_hash.update(chunk)
    return md5_hash.hexdigest()

def format_file_size(size_bytes):
    """Format file size in a human-readable format."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.2f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"

def categorize_image(file_name, file_data):
    """Categorizes images based on name patterns and metadata"""
    name_lower = file_name.lower()
    
    categories = {
        "Screenshot": ["screenshot", "screen", "captura"],
        "Profile": ["profile", "avatar", "perfil", "user"],
        "Document": ["doc", "scan", "document", "documento"],
        "System": ["system", "sistema", "backup", "copia"],
        "Snapshot": ["snapshot", "instant", "momento"]
    }
    
    for category, patterns in categories.items():
        for pattern in patterns:
            if pattern in name_lower:
                return category
    
    # If it's not determined by name, try by creation time
    hour = file_data.get("creation_time").hour if file_data.get("creation_time") else 0
    if 22 <= hour or hour <= 5:
        return "Night Capture"
    
    return "Uncategorized"

def generate_amecho_images_html (results, directory_info, output_path):
    """Generates an HTML report with the analyzed image files"""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    directory_path, directory_exists = directory_info
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    file_count = len(results)
    image_count = sum(1 for _, file_info in results.items() if 
                      file_info.get("data", {}).get("is_image", False))

    # Generate colors for different categories
    category_colors = {
        "Screenshot": "#3498db", "Profile": "#2ecc71", "Document": "#e74c3c",
        "System": "#f39c12", "Snapshot": "#9b59b6", "Night Capture": "#1abc9c",
        "Uncategorized": "#7f8c8d"
    }
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Android Snapshot Images Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50; --primary: #34495e; --primary-light: #4a6278;
            --accent: #3498db; --accent-light: #5dade2; --text: #ecf0f1;
            --text-secondary: #bdc3c7; --background: #0b0b1a; --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1); --success: #27ae60;
            --warning: #f39c12; --danger: #e74c3c; --grid-line: rgba(52, 152, 219, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Montserrat', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(52, 152, 219, 0.03) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(52, 152, 219, 0.02) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.3;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Orbitron', sans-serif; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .stat-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}

        .stat-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .stat-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;
        }}

        .stat-value {{ font-size: 2rem; font-weight: 700; color: var(--accent-light); }}

        .source-container {{ margin-top: 2rem; margin-bottom: 2rem; }}

        .source-card {{
            background-color: var(--primary); border-radius: 12px;
            padding: 1.5rem; margin-bottom: 1.5rem; border-left: 4px solid var(--accent);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); position: relative; overflow: hidden;
        }}

        .source-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}

        .source-title {{
            font-family: 'Orbitron', sans-serif; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; display: flex; align-items: center;
        }}

        .source-path {{
            font-family: monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem;
            width: 100%; overflow-x: auto; margin-top: 0.5rem; white-space: nowrap;
        }}

        .source-status {{
            font-size: 0.8rem; padding: 0.3rem 0.8rem; border-radius: 12px;
            font-weight: 600; letter-spacing: 0.5px;
        }}

        .source-found {{ background-color: var(--success); color: var(--text); }}
        .source-not-found {{ background-color: var(--danger); color: var(--text); }}

        .image-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-top: 1.5rem;
        }}

        .image-card {{
            background-color: var(--card-bg);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease;
        }}

        .image-card:hover {{
            transform: translateY(-5px);
        }}

        .image-preview {{
            width: 100%;
            height: 200px;
            background-position: center;
            background-size: cover;
            background-repeat: no-repeat;
            position: relative;
            background-color: var(--primary-dark);
            display: flex;
            align-items: center;
            justify-content: center;
        }}

        .image-preview img {{
            max-width: 100%;
            max-height: 200px;
            object-fit: contain;
        }}

        .image-preview .no-preview {{
            color: var(--text-secondary);
            font-size: 0.9rem;
            text-align: center;
            padding: 1rem;
        }}

        .image-details {{
            padding: 1rem;
        }}

        .image-name {{
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}

        .image-meta {{
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-bottom: 0.3rem;
        }}

        .category-badge {{
            padding: 0.2rem 0.6rem;
            border-radius: 10px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
            margin-top: 0.5rem;
        }}

        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}

        .error-message {{ color: var(--danger); margin-top: 0.5rem; font-style: italic; font-size: 0.9rem; }}
        .search-bar {{
            background-color: var(--primary-dark); border: 1px solid var(--border-color);
            border-radius: 30px; padding: 0.8rem 1.5rem; width: 100%; max-width: 600px;
            margin: 1rem auto 2rem; display: block; color: var(--text);
            font-family: 'Montserrat', sans-serif; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }}

        .expandable-toggle {{
            background-color: var(--primary-dark); color: var(--text); border: none;
            width: 100%; text-align: left; padding: 0.8rem; border-radius: 8px;
            margin-bottom: 0.5rem; cursor: pointer; display: flex;
            justify-content: space-between; align-items: center; font-weight: 600;
        }}

        .expandable-content {{ display: none; padding: 0.5rem; }}

        .modal {{
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.9);
            padding: 2rem;
        }}

        .modal-content {{
            margin: auto;
            display: block;
            max-width: 90%;
            max-height: 90%;
        }}

        .close {{
            position: absolute;
            top: 15px;
            right: 35px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            transition: 0.3s;
            cursor: pointer;
        }}

        .close:hover,
        .close:focus {{
            color: #bbb;
            text-decoration: none;
            cursor: pointer;
        }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .image-grid {{ grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Android Snapshot Images Analysis</h1>
            <p class="subtitle">📅 Generated on {now} | Generado el {now}</p>
        </div>

        <!-- Dashboard Stats -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-label">Total Files / Archivos Totales</div>
                <div class="stat-value">{file_count}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Images / Imágenes</div>
                <div class="stat-value">{image_count}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Directory / Directorio</div>
                <div class="stat-value">{os.path.basename(directory_path)}</div>
            </div>
        </div>

        <!-- Search Bar -->
        <input type="text" id="searchInput" placeholder="Search files... / Buscar archivos..." class="search-bar">"""

    if not directory_exists:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ Directory not found / Directorio no encontrado</div>
            <p>The specified directory could not be found. | El directorio especificado no pudo ser encontrado.</p>
        </div>"""
    elif not results:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No files found / No se encontraron archivos</div>
            <p>No files were found in the specified directory. | No se encontraron archivos en el directorio especificado.</p>
        </div>"""
    else:
        # Group by category
        categorized_files = {}
        for file_name, file_info in results.items():
            if not file_info["file_exists"] or "error" in file_info:
                continue
                
            file_data = file_info["data"]
            category = categorize_image(file_name, file_data)
            
            if category not in categorized_files:
                categorized_files[category] = []
            categorized_files[category].append((file_name, file_info))
        
        # Process files by category
        html += """
        <div class="source-container">"""
        
        for category, files in categorized_files.items():
            color = category_colors.get(category, "#7f8c8d")
            
            html += f"""
            <div class="expandable-section">
                <button class="expandable-toggle" onclick="toggleSection(this)">
                    {category} ({len(files)})
                </button>
                <div class="expandable-content">
                    <div class="image-grid">"""
            
            for file_name, file_info in files:
                file_path = file_info["file_path"]
                file_data = file_info["data"]
                
                # Extract metadata
                file_size = file_data.get("file_size_formatted", "Unknown")
                creation_time = file_data.get("creation_time", "Unknown")
                creation_time_str = creation_time.strftime("%Y-%m-%d %H:%M:%S") if isinstance(creation_time, datetime.datetime) else "Unknown"
                image_type = file_data.get("image_type", "Unknown")
                mime_type = file_data.get("mime_type", "Unknown")
                md5_hash = file_data.get("md5_hash", "Unknown")
                preview_base64 = file_data.get("preview_base64")
                
                html += f"""
                <div class="image-card">
                    <div class="image-preview">"""
                
                if preview_base64 and file_data.get("is_image"):
                    html += f"""
                        <img src="data:{mime_type};base64,{preview_base64}" alt="{file_name}" onclick="openModal(this.src)">"""
                else:
                    html += f"""
                        <div class="no-preview">
                            <p>No preview available / Vista previa no disponible</p>
                            <p>{mime_type}</p>
                        </div>"""
                
                html += f"""
                    </div>
                    <div class="image-details">
                        <div class="image-name">{file_name}</div>
                        <div class="image-meta"><strong>Size / Tamaño:</strong> {file_size}</div>
                        <div class="image-meta"><strong>Created / Creado:</strong> {creation_time_str}</div>
                        <div class="image-meta"><strong>Type / Tipo:</strong> {mime_type}</div>
                        <div class="image-meta"><strong>MD5:</strong> {md5_hash}</div>
                        <span class="category-badge" style="background-color:{color};">{category}</span>
                    </div>
                </div>"""
            
            html += """
                    </div>
                </div>
            </div>"""
        
        html += """
        </div>"""

    # Modal for image preview
    html += """
    <div id="imageModal" class="modal">
        <span class="close" onclick="closeModal()">&times;</span>
        <img class="modal-content" id="modalImg">
    </div>
    """

    # Footer
    html += f"""
        <div class="footer">
            <p>📁 Report path / Ruta del informe: <code id="reportPath">{output_path}</code></p>
            <p>📁 Directory analyzed / Directorio analizado: <code>{directory_path}</code></p>
            <p>ForenSage © 2025 - Android Forensic Tool</p>
        </div>
    </div>

    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('input', function() {{
            let searchTerm = this.value.toLowerCase();
            let cards = document.querySelectorAll('.image-card');
            
            cards.forEach(card => {{
                let fileName = card.querySelector('.image-name').textContent.toLowerCase();
                let metaData = card.querySelector('.image-details').textContent.toLowerCase();
                
                if (fileName.includes(searchTerm) || metaData.includes(searchTerm)) {{
                    card.style.display = 'block';
                    // Make sure parent expandable section is open
                    let parent = card.closest('.expandable-content');
                    if (parent) {{
                        parent.style.display = 'block';
                        let toggle = parent.previousElementSibling;
                        toggle.classList.add('active');
                    }}
                }} else {{
                    card.style.display = 'none';
                }}
            }});
        }});

        // Toggle expandable sections
        function toggleSection(el) {{
            el.classList.toggle('active');
            let content = el.nextElementSibling;
            content.style.display = content.style.display === 'block' ? 'none' : 'block';
        }}

        // Image modal functionality
        function openModal(src) {{
            document.getElementById('modalImg').src = src;
            document.getElementById('imageModal').style.display = 'block';
        }}

        function closeModal() {{
            document.getElementById('imageModal').style.display = 'none';
        }}

        // Close modal on escape key
        document.addEventListener('keydown', function(event) {{
            if (event.key === 'Escape') {{
                closeModal();
            }}
        }});

        // Set absolute path for report
        document.getElementById('reportPath').textContent = document.location.pathname;
        
        // Open first category by default
        const firstToggle = document.querySelector('.expandable-toggle');
        if (firstToggle) {{
            firstToggle.click();
        }}
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # Directory to analyze
    directory_to_analyze = "/media/adrian/data/system_ce/0/snapshots"
    
    # For output, create relative path
    base_path = Path.home() / "ForenSage"
    output_html = base_path / "results/amecho_images_info.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    # Analyze image files
    results, directory_exists = analyze_images(directory_to_analyze)
    
    # Generate HTML report
    generate_amecho_images_html(results, (directory_to_analyze, directory_exists), str(output_html))

if __name__ == "__main__":
    main()