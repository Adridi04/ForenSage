import os
import sqlite3
import datetime
from pathlib import Path
import json

def analyze_sqlite_database(db_path):
    """Analyzes an SQLite database file and extracts its content."""
    results = {}
    
    try:
        if not os.path.exists(db_path):
            print(f"Error: Database file not found: {db_path}")
            return results, False
        
        # Connect to the database
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get list of tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        
        if not tables:
            print(f"No tables found in: {db_path}")
            return results, True
        
        # Extract data from each table
        for table in tables:
            table_name = table[0]
            table_data = {}
            
            try:
                # Get column names
                cursor.execute(f"PRAGMA table_info({table_name})")
                columns = cursor.fetchall()
                column_names = [col[1] for col in columns]
                column_types = [col[2] for col in columns]
                
                # Get data
                cursor.execute(f"SELECT * FROM {table_name}")
                rows = cursor.fetchall()
                
                # Process data
                processed_rows = []
                for row in rows:
                    processed_row = {}
                    for i, value in enumerate(row):
                        col_name = column_names[i]
                        col_type = column_types[i]
                        processed_row[col_name] = analyze_field_value(value, col_type, col_name)
                    processed_rows.append(processed_row)
                
                table_data["columns"] = column_names
                table_data["column_types"] = column_types
                table_data["rows"] = processed_rows
                table_data["row_count"] = len(rows)
            
                results[table_name] = table_data
                
            except Exception as e:
                print(f"Error analyzing table {table_name}: {e}")
                results[table_name] = {
                    "error": str(e),
                    "row_count": 0
                }
        
        conn.close()
        return results, True
        
    except Exception as e:
        print(f"General database error: {e}")
        return results, False

def analyze_field_value(value, field_type, field_name):
    """Analyzes and formats the value of a database field."""
    if value is None:
        return {"value": None, "formatted": "NULL", "type": "null"}
    
    # Check for timestamps in field names
    timestamp_keywords = ["time", "date", "created", "modified", "accessed", "last"]
    is_potential_timestamp = any(keyword in field_name.lower() for keyword in timestamp_keywords)
    
    # Integer that might be a timestamp
    if isinstance(value, int) and is_potential_timestamp:
        if value > 1000000000 and value < 5000000000:  # Unix timestamp range
            try:
                date = datetime.datetime.fromtimestamp(value)
                return {
                    "value": value,
                    "formatted": date.strftime("%Y-%m-%d %H:%M:%S"),
                    "type": "timestamp_seconds"
                }
            except:
                pass
        
        if value > 1000000000000 and value < 5000000000000:  # Milliseconds timestamp
            try:
                date = datetime.datetime.fromtimestamp(value/1000)
                return {
                    "value": value,
                    "formatted": date.strftime("%Y-%m-%d %H:%M:%S"),
                    "type": "timestamp_milliseconds"
                }
            except:
                pass
    
    # Handle different types
    if isinstance(value, int):
        return {"value": value, "formatted": str(value), "type": "integer"}
    
    elif isinstance(value, float):
        return {"value": value, "formatted": str(value), "type": "float"}
    
    elif isinstance(value, str):
        # Check if it's JSON
        if (value.startswith('{') and value.endswith('}')) or (value.startswith('[') and value.endswith(']')):
            try:
                parsed = json.loads(value)
                return {
                    "value": value,
                    "formatted": json.dumps(parsed, indent=2),
                    "type": "json"
                }
            except:
                pass
                
        # Check if it's a path
        if '/' in value and not ' ' in value:
            return {"value": value, "formatted": value, "type": "path"}
            
        return {"value": value, "formatted": value, "type": "text"}
    
    elif isinstance(value, bytes):
        # Try to decode as utf-8
        try:
            decoded = value.decode('utf-8')
            return {"value": "BLOB", "formatted": decoded, "type": "blob_text"}
        except:
            # Return as hex if can't decode as text
            return {"value": "BLOB", "formatted": value.hex()[:60] + "..." if len(value.hex()) > 60 else value.hex(), "type": "blob_hex"}
    
    return {"value": str(value), "formatted": str(value), "type": "unknown"}

def categorize_table(table_name):
    """Categorizes tables based on name patterns"""
    name_lower = table_name.lower()
    
    categories = {
        "Accounts": ["account", "auth", "login", "user", "credential"],
        "Settings": ["setting", "config", "preference", "option"],
        "System": ["system", "device", "registry", "status"],
        "Security": ["security", "permission", "access", "token", "key", "cert"],
        "Metadata": ["meta", "_meta", "info", "property"],
        "Logs": ["log", "event", "history", "activity", "audit"]
    }
    
    for category, patterns in categories.items():
        for pattern in patterns:
            if pattern in name_lower:
                return category
    
    return "Miscellaneous"

def generate_amecho_accounts_html(results, db_info, output_path):
    """Generates an HTML report with the analyzed SQLite database"""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    db_path, db_exists = db_info
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    table_count = len(results)
    
    # Total row count
    total_rows = sum(table.get("row_count", 0) for table in results.values())

    # Generate colors for different categories
    category_colors = {
        "Accounts": "#3498db", "Settings": "#2ecc71", "System": "#9b59b6",
        "Security": "#f39c12", "Metadata": "#1abc9c", "Logs": "#e74c3c",
        "Miscellaneous": "#7f8c8d"
    }
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Android Database Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #2c3e50; --primary: #34495e; --primary-light: #4a6278;
            --accent: #3498db; --accent-light: #5dade2; --text: #ecf0f1;
            --text-secondary: #bdc3c7; --background: #0b0b1a; --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1); --success: #27ae60;
            --warning: #f39c12; --danger: #e74c3c; --grid-line: rgba(52, 152, 219, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Montserrat', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(52, 152, 219, 0.03) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(52, 152, 219, 0.02) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.3;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Orbitron', sans-serif; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .stat-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}

        .stat-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .stat-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;
        }}

        .stat-value {{ font-size: 2rem; font-weight: 700; color: var(--accent-light); }}

        .table-container {{ margin-top: 2rem; margin-bottom: 2rem; }}

        .table-card {{
            background-color: var(--primary); border-radius: 12px;
            padding: 1.5rem; margin-bottom: 1.5rem; border-left: 4px solid var(--accent);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); position: relative; overflow: hidden;
        }}

        .table-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}

        .table-title {{
            font-family: 'Orbitron', sans-serif; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; display: flex; align-items: center;
        }}

        .row-count {{
            font-size: 0.8rem; padding: 0.3rem 0.8rem; border-radius: 12px;
            font-weight: 600; letter-spacing: 0.5px; background-color: var(--primary-dark);
        }}

        .data-table {{
            width: 100%; border-collapse: collapse; margin-top: 1rem;
            background-color: var(--card-bg); border-radius: 8px; overflow: hidden;
        }}

        .data-table th {{
            background-color: var(--primary-dark); padding: 0.8rem; text-align: left;
            color: var(--accent-light); font-weight: 600; text-transform: uppercase; font-size: 0.8rem;
        }}

        .data-table td {{
            padding: 0.8rem; border-top: 1px solid var(--border-color);
            font-size: 0.9rem; word-break: break-all;
        }}

        .data-table tr:hover {{ background-color: rgba(52, 152, 219, 0.05); }}

        .field-type {{
            font-size: 0.75rem; padding: 0.2rem 0.5rem; border-radius: 10px;
            background-color: rgba(255, 255, 255, 0.1); color: var(--text-secondary);
        }}

        .timestamp {{ color: #e74c3c; }}
        .json-data {{ color: #f39c12; }}
        .path-data {{ color: #27ae60; }}
        .blob-data {{ color: #9b59b6; }}

        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}

        .expandable-toggle {{
            background-color: var(--primary-dark); color: var(--text); border: none;
            width: 100%; text-align: left; padding: 0.8rem; border-radius: 8px;
            margin-bottom: 0.5rem; cursor: pointer; display: flex;
            justify-content: space-between; align-items: center; font-weight: 600;
        }}

        .expandable-content {{ display: none; padding: 0.5rem; }}
        .category-badge {{ padding: 0.2rem 0.6rem; border-radius: 10px; font-size: 0.75rem; font-weight: 600; }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .table-header {{ flex-direction: column; align-items: flex-start; }}
            .row-count {{ margin-top: 0.5rem; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Android Database Analysis</h1>
            <p class="subtitle">📅 Generated on {now} | Generado el {now}</p>
        </div>

        <!-- Dashboard Stats -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-label">Tables Found / Tablas Encontradas</div>
                <div class="stat-value">{table_count}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Total Rows / Filas Totales</div>
                <div class="stat-value">{total_rows}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Database / Base de Datos</div>
                <div class="stat-value">{os.path.basename(db_path)}</div>
            </div>
        </div>"""

    if not db_exists:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ Database not found / Base de datos no encontrada</div>
            <p>The specified database file could not be found. | El archivo de base de datos especificado no pudo ser encontrado.</p>
        </div>"""
    elif not results:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No tables found / No se encontraron tablas</div>
            <p>No tables were found in the specified database. | No se encontraron tablas en la base de datos especificada.</p>
        </div>"""
    else:
        # Group tables by category
        categorized_tables = {}
        for table_name, table_data in results.items():
            category = categorize_table(table_name)
            if category not in categorized_tables:
                categorized_tables[category] = []
            categorized_tables[category].append((table_name, table_data))
        
        html += """
        <div class="table-container">"""
        
        # Create expandable sections for each category
        for category, tables in categorized_tables.items():
            color = category_colors.get(category, "#7f8c8d")
            
            html += f"""
            <div class="expandable-section">
                <button class="expandable-toggle" onclick="toggleSection(this)">
                    {category} ({len(tables)})
                    <span class="category-badge" style="background-color:{color};">{category}</span>
                </button>
                <div class="expandable-content">"""
            
            for table_name, table_data in tables:
                if "error" in table_data:
                    html += f"""
                    <div class="table-card">
                        <div class="table-header">
                            <div class="table-title">
                                <span style="margin-right:10px;">🗃️</span> {table_name}
                            </div>
                            <span class="row-count">Error</span>
                        </div>
                        <div class="error-message">{table_data["error"]}</div>
                    </div>"""
                    continue
                
                row_count = table_data.get("row_count", 0)
                html += f"""
                <div class="table-card">
                    <div class="table-header">
                        <div class="table-title">
                            <span style="margin-right:10px;">🗃️</span> {table_name}
                        </div>
                        <span class="row-count">{row_count} rows</span>
                    </div>"""
                
                if row_count > 0:
                    html += """
                    <table class="data-table">
                        <thead>
                            <tr>"""
                    
                    # Add column headers
                    for column in table_data["columns"]:
                        html += f"""
                                <th>{column}</th>"""
                    
                    html += """
                            </tr>
                        </thead>
                        <tbody>"""
                    
                    # Add rows (limit to 20 for performance)
                    max_rows = min(20, row_count)
                    for i in range(max_rows):
                        row = table_data["rows"][i]
                        html += """
                            <tr>"""
                        
                        for column in table_data["columns"]:
                            value = row.get(column, {})
                            formatted_value = value.get("formatted", "")
                            value_type = value.get("type", "")
                            
                            css_class = ""
                            if "timestamp" in value_type:
                                css_class = "timestamp"
                            elif value_type == "json":
                                css_class = "json-data"
                            elif value_type == "path":
                                css_class = "path-data"
                            elif "blob" in value_type:
                                css_class = "blob-data"
                            
                            html += f"""
                                <td>
                                    <span class="{css_class}">{formatted_value}</span>
                                    <span class="field-type">{value_type}</span>
                                </td>"""
                        
                        html += """
                            </tr>"""
                    
                    if row_count > 20:
                        html += f"""
                            <tr>
                                <td colspan="{len(table_data['columns'])}" style="text-align:center;">
                                    <i>Showing 20 rows out of {row_count} total rows</i>
                                </td>
                            </tr>"""
                    
                    html += """
                        </tbody>
                    </table>"""
                else:
                    html += """
                    <div class="warning-card">
                        <p>This table exists but contains no rows. / Esta tabla existe pero no contiene filas.</p>
                    </div>"""
                
                html += """
                </div>"""
            
            html += """
                </div>
            </div>"""
        
        html += """
        </div>"""

    # Footer
    html += f"""
        <div class="footer">
            <p>📁 Report path / Ruta del informe: <code id="reportPath">{output_path}</code></p>
            <p>📁 Database analyzed / Base de datos analizada: <code>{db_path}</code></p>
            <p>ForenSage © 2025 - Android Forensic Tool</p>
        </div>
    </div>

    <script>
        // Toggle expandable sections
        function toggleSection(el) {{
            el.classList.toggle('active');
            let content = el.nextElementSibling;
            content.style.display = content.style.display === 'block' ? 'none' : 'block';
        }}

        // Set absolute path for report
        document.getElementById('reportPath').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # Database to analyze
    db_to_analyze = "/home/adrian/ForenSage/analyze/amecho/accounts_ce.db"
    
    # For output, create relative path
    base_path = Path.home() / "ForenSage"
    output_html = base_path / "results/amecho_accounts_info.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    # Analyze SQLite database
    results, db_exists = analyze_sqlite_database(db_to_analyze)
    
    # Generate HTML report
    generate_amecho_accounts_html(results, (db_to_analyze, db_exists), str(output_html))

if __name__ == "__main__":
    main()