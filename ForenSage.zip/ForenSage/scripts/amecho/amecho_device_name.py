import os
import xml.etree.ElementTree as ET
import datetime
from pathlib import Path

def analyze_device_name(xml_path):
    """Analyzes the device name XML file and extracts the device name."""
    result = {
        "device_name": "Unknown",
        "file_exists": False,
        "error": None
    }
    
    try:
        # Check if file exists
        if not os.path.exists(xml_path):
            result["error"] = f"File not found: {xml_path}"
            return result
        
        result["file_exists"] = True
        
        # Parse XML
        tree = ET.parse(xml_path)
        root = tree.getroot()
        
        # Extract device name from XML
        for child in root:
            if 'name' in child.attrib and child.attrib['name'] == 'device_name':
                result["device_name"] = child.text if child.text else "Not Set"
                break
            
            # Fallback: try to find any element that might contain device name
            if 'name' in child.attrib and ('device' in child.attrib['name'].lower() or 
                                           'name' in child.attrib['name'].lower()):
                result["device_name"] = child.text if child.text else "Not Set"
                
        return result
        
    except Exception as e:
        result["error"] = str(e)
        return result

def generate_amecho_name_html(result, xml_path, output_path):
    """Generates an HTML report showing the device name."""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    device_name = result["device_name"]
    file_exists = result["file_exists"]
    error = result["error"]
    
    # Generate HTML with futuristic design for device name display
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Device Name Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #1a1a2e;
            --primary: #16213e;
            --primary-light: #0f3460;
            --accent: #4361ee;
            --accent-light: #4895ef;
            --accent-glow: rgba(67, 97, 238, 0.5);
            --text: #e2e2e2;
            --text-secondary: #b2becd;
            --background: #0a0a1a;
            --card-bg: #16213e;
            --border-color: rgba(255, 255, 255, 0.1);
            --success: #2ecc71;
            --warning: #f39c12;
            --danger: #e74c3c;
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Montserrat', sans-serif;
            background-color: var(--background);
            color: var(--text);
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(67, 97, 238, 0.03) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(67, 97, 238, 0.02) 100%);
            background-attachment: fixed;
            position: relative;
            overflow-x: hidden;
            min-height: 100vh;
        }}

        body::before {{
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(90deg, rgba(67, 97, 238, 0.05) 1px, transparent 1px),
                linear-gradient(0deg, rgba(67, 97, 238, 0.05) 1px, transparent 1px);
            background-size: 20px 20px;
            z-index: -1;
            opacity: 0.3;
        }}

        .container {{
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem;
            position: relative;
            z-index: 1;
            animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{
            text-align: center;
            margin-bottom: 3rem;
            position: relative;
        }}

        .title {{
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            display: inline-block;
        }}

        .title::after {{
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
            font-size: 1.1rem;
        }}

        .device-showcase {{
            position: relative;
            margin: 3rem auto;
            max-width: 600px;
            height: 300px;
            perspective: 1000px;
        }}

        .device-card {{
            position: relative;
            width: 100%;
            height: 100%;
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.3), 0 0 20px var(--accent-glow);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 2rem;
            transition: transform 0.6s ease, box-shadow 0.6s ease;
            overflow: hidden;
            transform-style: preserve-3d;
        }}

        .device-card:hover {{
            transform: translateY(-10px) rotateX(5deg);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4), 0 0 30px var(--accent-glow);
        }}

        .device-card::before {{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 50% 30%, rgba(67, 97, 238, 0.15), transparent 70%);
            z-index: 0;
        }}

        .device-icon {{
            font-size: 5rem;
            margin-bottom: 1.5rem;
            color: var(--accent-light);
            filter: drop-shadow(0 0 10px var(--accent-glow));
            z-index: 1;
        }}

        .device-name-label {{
            font-family: 'Orbitron', sans-serif;
            font-size: 1rem;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 3px;
            margin-bottom: 0.5rem;
            z-index: 1;
        }}

        .device-name-value {{
            font-family: 'Orbitron', sans-serif;
            font-size: 2rem;
            font-weight: 700;
            color: var(--text);
            text-align: center;
            z-index: 1;
            background: linear-gradient(135deg, var(--accent-light), var(--text));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: pulse 2s infinite;
        }}

        .circuit-lines {{
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            opacity: 0.2;
            z-index: 0;
        }}

        .device-details {{
            margin-top: 3rem;
            background-color: var(--card-bg);
            border-radius: 15px;
            padding: 1.5rem;
            border-left: 4px solid var(--accent);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }}

        .detail-item {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.8rem 0;
            border-bottom: 1px solid var(--border-color);
        }}

        .detail-item:last-child {{
            border-bottom: none;
        }}

        .detail-label {{
            font-weight: 600;
            color: var(--text-secondary);
        }}

        .detail-value {{
            font-family: monospace;
            color: var(--text);
            background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem;
            border-radius: 6px;
            font-size: 0.9rem;
        }}

        .error-message {{
            background-color: rgba(231, 76, 60, 0.2);
            border-left: 4px solid var(--danger);
            padding: 1rem;
            margin-top: 1rem;
            border-radius: 6px;
        }}

        .status-indicator {{
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
        }}

        .status-online {{
            background-color: var(--success);
            box-shadow: 0 0 8px var(--success);
        }}

        .status-offline {{
            background-color: var(--danger);
            box-shadow: 0 0 8px var(--danger);
        }}

        .footer {{
            text-align: center;
            margin-top: 3rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            border-top: 1px solid var(--border-color);
            padding-top: 1.5rem;
        }}

        @keyframes pulse {{
            0% {{ filter: drop-shadow(0 0 2px var(--accent-glow)); }}
            50% {{ filter: drop-shadow(0 0 10px var(--accent-glow)); }}
            100% {{ filter: drop-shadow(0 0 2px var(--accent-glow)); }}
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .device-name-value {{ font-size: 1.5rem; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Device Name Analysis</h1>
            <p class="subtitle">📅 Generated on {now} | Generado el {now}</p>
        </div>

        <div class="device-showcase">
            <div class="device-card">
                <div class="circuit-lines">
                    <svg width="100%" height="100%" viewBox="0 0 600 300" xmlns="http://www.w3.org/2000/svg">
                        <path d="M50,50 Q100,25 150,50 T250,50 T350,50 T450,50 T550,50" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        <path d="M50,100 Q100,75 150,100 T250,100 T350,100 T450,100 T550,100" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        <path d="M50,150 Q100,125 150,150 T250,150 T350,150 T450,150 T550,150" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        <path d="M50,200 Q100,175 150,200 T250,200 T350,200 T450,200 T550,200" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        <path d="M50,250 Q100,225 150,250 T250,250 T350,250 T450,250 T550,250" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        
                        <path d="M50,50 L50,250" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        <path d="M150,50 L150,250" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        <path d="M250,50 L250,250" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        <path d="M350,50 L350,250" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        <path d="M450,50 L450,250" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        <path d="M550,50 L550,250" stroke="var(--accent)" fill="none" stroke-width="1"/>
                        
                        <circle cx="150" cy="150" r="5" fill="var(--accent)" opacity="0.8"/>
                        <circle cx="250" cy="150" r="5" fill="var(--accent)" opacity="0.8"/>
                        <circle cx="350" cy="150" r="5" fill="var(--accent)" opacity="0.8"/>
                        <circle cx="450" cy="150" r="5" fill="var(--accent)" opacity="0.8"/>
                    </svg>
                </div>
                
                <div class="device-icon">📱</div>
                <div class="device-name-label">Device Name</div>
                <div class="device-name-value">{device_name}</div>
            </div>
        </div>

        <div class="device-details">
            <div class="detail-item">
                <span class="detail-label">Status</span>
                <span class="detail-value">
                    <span class="status-indicator {'status-online' if file_exists else 'status-offline'}"></span>
                    {('Active / Activo' if file_exists else 'Inactive / Inactivo')}
                </span>
            </div>
            <div class="detail-item">
                <span class="detail-label">XML Path / Ruta XML</span>
                <span class="detail-value">{xml_path}</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Analysis Date / Fecha de Análisis</span>
                <span class="detail-value">{now}</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">File Found / Archivo Encontrado</span>
                <span class="detail-value">{('Yes / Sí' if file_exists else 'No / No')}</span>
            </div>
        </div>

        {f'<div class="error-message">{error}</div>' if error else ''}

        <div class="footer">
            <p>📁 Report path / Ruta del informe: <code id="reportPath">{output_path}</code></p>
            <p>ForenSage © 2025 - Android Forensic Tool</p>
        </div>
    </div>

    <script>
        // Set absolute path for report
        document.getElementById('reportPath').textContent = document.location.pathname;
        
        // Add subtle hover animation for the device card
        document.querySelector('.device-card').addEventListener('mousemove', function(e) {{
            const card = this;
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const angleX = (y - centerY) / 20;
            const angleY = -(x - centerX) / 20;
            
            card.style.transform = `perspective(1000px) rotateX(${{angleX}}deg) rotateY(${{angleY}}deg)`;
        }});
        
        document.querySelector('.device-card').addEventListener('mouseleave', function() {{
            this.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
        }});
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    base_path = Path.home() / "ForenSage"
    xml_path = base_path / "analyze/amecho/deviceNameSharedPref.xml"
    
    # Configurar la ruta de salida basada en la misma estructura
   
    output_html = base_path / "results/amecho_device_name.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    # Analyze device name XML
    result = analyze_device_name(xml_path)
    
    # Generate HTML report
    generate_amecho_name_html(result, xml_path, str(output_html))

if __name__ == "__main__":
    main()