import os
import datetime
from pathlib import Path
import re

def analyze_property_files(serialno_path, hostname_path):
    """Analyzes drone property files that contain serial number and hostname information."""
    results = {}
    
    try:
        # Check if the paths exist
        serialno_exists = os.path.exists(serialno_path)
        hostname_exists = os.path.exists(hostname_path)
        
        print(f"Checking serial number file: {serialno_path} - {'Found' if serialno_exists else 'Not Found'}")
        print(f"Checking hostname file: {hostname_path} - {'Found' if hostname_exists else 'Not Found'}")
        
        # Extract serial number
        serialno_data = {}
        if serialno_exists:
            try:
                with open(serialno_path, 'r', encoding='utf-8', errors='replace') as f:
                    serialno_content = f.read().strip()
                    serialno_data = {
                        "content": serialno_content,
                        "exists": True,
                        "file_path": serialno_path,
                        "size": os.path.getsize(serialno_path),
                        "modified": datetime.datetime.fromtimestamp(os.path.getmtime(serialno_path)).strftime("%Y-%m-%d %H:%M:%S")
                    }
            except Exception as e:
                print(f"Error reading serial number file: {e}")
                serialno_data = {
                    "exists": True,
                    "file_path": serialno_path,
                    "error": str(e)
                }
        else:
            serialno_data = {
                "exists": False,
                "file_path": serialno_path
            }
        
        # Extract hostname
        hostname_data = {}
        if hostname_exists:
            try:
                with open(hostname_path, 'r', encoding='utf-8', errors='replace') as f:
                    hostname_content = f.read().strip()
                    hostname_data = {
                        "content": hostname_content,
                        "exists": True,
                        "file_path": hostname_path,
                        "size": os.path.getsize(hostname_path),
                        "modified": datetime.datetime.fromtimestamp(os.path.getmtime(hostname_path)).strftime("%Y-%m-%d %H:%M:%S")
                    }
            except Exception as e:
                print(f"Error reading hostname file: {e}")
                hostname_data = {
                    "exists": True,
                    "file_path": hostname_path,
                    "error": str(e)
                }
        else:
            hostname_data = {
                "exists": False,
                "file_path": hostname_path
            }
        
        results = {
            "serialno": serialno_data,
            "hostname": hostname_data,
            "both_exist": serialno_exists and hostname_exists
        }
        
        return results, True
        
    except Exception as e:
        print(f"General error: {e}")
        return results, False

def extract_additional_info(content):
    """Extracts additional information from property content if possible."""
    info = {}
    
    # Look for possible model number patterns
    model_pattern = re.compile(r'([A-Z]{2}\d{3})')
    model_match = model_pattern.search(content) if content else None
    if model_match:
        info["model"] = model_match.group(1)
    
    # Look for manufacturing date patterns (YYYYMMDD or similar)
    date_pattern = re.compile(r'(\d{4})(\d{2})(\d{2})')
    date_match = date_pattern.search(content) if content else None
    if date_match:
        year, month, day = date_match.groups()
        info["manufacture_date"] = f"{year}-{month}-{day}"
    
    # Look for firmware version patterns
    fw_pattern = re.compile(r'v(\d+\.\d+\.\d+)')
    fw_match = fw_pattern.search(content) if content else None
    if fw_match:
        info["firmware"] = fw_match.group(1)
    
    return info

def verify_device_authenticity(serialno, hostname):
    """Basic function to check if serial number and hostname patterns match known DJI formats."""
    results = {}
    
    # Check serial number pattern (common DJI format is alphanumeric with specific length)
    if serialno:
        # DJI often uses 10-15 character alphanumeric serials
        is_valid_serialno = bool(re.match(r'^[A-Z0-9]{10,15}$', serialno))
        results["serialno_valid"] = is_valid_serialno
        
        # Some DJI models have specific prefixes
        if serialno.startswith('DJ'):
            results["manufacturer"] = "DJI"
            
    # Check hostname pattern (DJI devices often have hostnames containing model info)
    if hostname:
        # Look for DJI model identifiers in hostname
        dji_model_pattern = re.compile(r'(Mavic|Phantom|Inspire|Spark|Matrice|Mini)')
        model_match = dji_model_pattern.search(hostname)
        if model_match:
            results["device_model"] = model_match.group(1)
            results["hostname_valid"] = True
        else:
            results["hostname_valid"] = False
    
    # Check consistency between serial and hostname if both exist
    if serialno and hostname:
        # Some DJI devices have serial embedded in hostname or vice versa
        results["consistent"] = serialno in hostname or hostname in serialno
    
    return results

def generate_property_analysis_html(results, output_path):
    """Generates an HTML report for the drone property analysis."""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Extract serialno and hostname values for analysis
    serialno_content = results.get("serialno", {}).get("content", "")
    hostname_content = results.get("hostname", {}).get("content", "")
    
    # Extract additional information
    serialno_info = extract_additional_info(serialno_content)
    hostname_info = extract_additional_info(hostname_content)
    
    # Verify device authenticity
    auth_results = verify_device_authenticity(serialno_content, hostname_content)
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drone Property Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #1a2b3c; --primary: #23374d; --primary-light: #345678;
            --accent: #00a8ff; --accent-light: #29b6f6; --text: #e0e6ed;
            --text-secondary: #a7b9cc; --background: #0a1622; --card-bg: #12202e;
            --border-color: rgba(0, 168, 255, 0.2); --success: #00e676;
            --warning: #ffab00; --danger: #ff1744; --grid-line: rgba(0, 168, 255, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Rajdhani', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(0, 168, 255, 0.05) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(0, 168, 255, 0.03) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.2;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Share Tech Mono', monospace; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}

        .property-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .property-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}

        .property-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .property-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}

        .property-title {{
            font-family: 'Share Tech Mono', monospace; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; display: flex; align-items: center;
        }}

        .property-path {{
            font-family: 'Share Tech Mono', monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem;
            width: 100%; overflow-x: auto; margin-top: 0.5rem; white-space: nowrap;
        }}

        .property-status {{
            font-size: 0.8rem; padding: 0.3rem 0.8rem; border-radius: 12px;
            font-weight: 600; letter-spacing: 0.5px;
        }}

        .property-found {{ background-color: var(--success); color: #000; }}
        .property-not-found {{ background-color: var(--danger); color: var(--text); }}

        .property-content {{
            background-color: var(--card-bg); border-radius: 8px; padding: 1rem;
            margin-top: 1rem; font-family: 'Share Tech Mono', monospace;
            font-size: 1.2rem; word-break: break-all;
        }}

        .property-details {{
            margin-top: 1.5rem;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
        }}

        .property-detail-item {{
            background-color: rgba(0, 0, 0, 0.2);
            padding: 0.8rem;
            border-radius: 6px;
            text-align: center;
        }}

        .property-detail-label {{
            font-size: 0.8rem;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 1px;
        }}

        .property-detail-value {{
            font-family: 'Share Tech Mono', monospace;
            font-size: 1.1rem;
            color: var(--accent);
            margin-top: 0.3rem;
        }}

        .drone-icon-container {{
            position: relative;
            text-align: center;
            margin: 2rem 0;
        }}

        .drone-icon {{
            width: 100px;
            height: 100px;
            position: relative;
            display: inline-block;
        }}

        .drone-body {{
            width: 40px;
            height: 10px;
            background-color: var(--accent);
            position: absolute;
            top: 45px;
            left: 30px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 168, 255, 0.5);
        }}

        .drone-arm1, .drone-arm2, .drone-arm3, .drone-arm4 {{
            width: 50px;
            height: 4px;
            background-color: var(--accent-light);
            position: absolute;
            border-radius: 2px;
        }}

        .drone-arm1 {{ transform: rotate(45deg); top: 35px; left: 15px; }}
        .drone-arm2 {{ transform: rotate(-45deg); top: 35px; left: 35px; }}
        .drone-arm3 {{ transform: rotate(135deg); top: 60px; left: 15px; }}
        .drone-arm4 {{ transform: rotate(-135deg); top: 60px; left: 35px; }}
        
        .drone-prop1, .drone-prop2, .drone-prop3, .drone-prop4 {{
            width: 20px;
            height: 4px;
            background-color: var(--accent);
            position: absolute;
            border-radius: 2px;
            animation: spin 1s linear infinite;
        }}
        
        .drone-prop1 {{ top: 25px; left: 10px; }}
        .drone-prop2 {{ top: 25px; left: 70px; }}
        .drone-prop3 {{ top: 70px; left: 10px; }}
        .drone-prop4 {{ top: 70px; left: 70px; }}
        
        @keyframes spin {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}

        .drone-shadow {{
            width: 60px;
            height: 12px;
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 50%;
            position: absolute;
            bottom: -20px;
            left: 20px;
            filter: blur(5px);
        }}

        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}

        .error-message {{ color: var(--danger); margin-top: 0.5rem; font-style: italic; font-size: 0.9rem; }}

        .authenticity-section {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; margin-top: 2rem;
            position: relative; overflow: hidden;
            border-left: 4px solid var(--accent);
        }}

        .authenticity-title {{
            font-family: 'Share Tech Mono', monospace; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; margin-bottom: 1rem;
            border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem;
        }}

        .authenticity-result {{
            display: flex; align-items: center; margin: 0.5rem 0;
        }}

        .authenticity-label {{
            min-width: 160px; font-size: 0.9rem; color: var(--text-secondary);
        }}

        .authenticity-value {{
            font-family: 'Share Tech Mono', monospace; font-size: 1rem;
            padding: 0.3rem 0.8rem; border-radius: 12px; font-weight: 600;
        }}

        .authenticity-valid {{ background-color: var(--success); color: #000; }}
        .authenticity-invalid {{ background-color: var(--danger); color: var(--text); }}
        .authenticity-warning {{ background-color: var(--warning); color: #000; }}
        .authenticity-info {{ background-color: var(--accent); color: var(--text); }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .property-header {{ flex-direction: column; align-items: flex-start; }}
            .property-status {{ margin-top: 0.5rem; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Drone Property Analysis</h1>
            <p class="subtitle">📅 Analysis Generated on {now}</p>
        </div>

        <!-- Animated Drone Icon -->
        <div class="drone-icon-container">
            <div class="drone-icon">
                <div class="drone-body"></div>
                <div class="drone-arm1"></div>
                <div class="drone-arm2"></div>
                <div class="drone-arm3"></div>
                <div class="drone-arm4"></div>
                <div class="drone-prop1"></div>
                <div class="drone-prop2"></div>
                <div class="drone-prop3"></div>
                <div class="drone-prop4"></div>
                <div class="drone-shadow"></div>
            </div>
        </div>

        <!-- Property Cards -->
        <div class="dashboard">"""
        
    # Serial Number Card
    serialno_data = results.get("serialno", {})
    serialno_exists = serialno_data.get("exists", False)
    serialno_content = serialno_data.get("content", "")
    serialno_path = serialno_data.get("file_path", "")
    serialno_error = serialno_data.get("error", "")
    serialno_mod_date = serialno_data.get("modified", "Unknown")
    serialno_size = serialno_data.get("size", 0)
    
    html += f"""
            <div class="property-card">
                <div class="property-header">
                    <div class="property-title">
                        <span style="margin-right:10px;">🔢</span> Serial Number
                    </div>
                    <span class="property-status {'property-found' if serialno_exists else 'property-not-found'}">
                        {'Found' if serialno_exists else 'Not Found'}
                    </span>
                </div>
                <div class="property-path">{serialno_path}</div>"""
            
    if serialno_error:
        html += f"""
                <div class="error-message">Error: {serialno_error}</div>"""
    
    if serialno_exists and serialno_content:
        html += f"""
                <div class="property-content">{serialno_content}</div>
                <div class="property-details">
                    <div class="property-detail-item">
                        <div class="property-detail-label">File Size</div>
                        <div class="property-detail-value">{serialno_size} bytes</div>
                    </div>
                    <div class="property-detail-item">
                        <div class="property-detail-label">Modified</div>
                        <div class="property-detail-value">{serialno_mod_date.split()[0]}</div>
                    </div>"""
                    
        # Add additional serial number details if available
        for key, value in serialno_info.items():
            html += f"""
                    <div class="property-detail-item">
                        <div class="property-detail-label">{key.replace('_', ' ').title()}</div>
                        <div class="property-detail-value">{value}</div>
                    </div>"""
        
        html += """
                </div>"""
    
    html += """
            </div>"""
    
    # Hostname Card
    hostname_data = results.get("hostname", {})
    hostname_exists = hostname_data.get("exists", False)
    hostname_content = hostname_data.get("content", "")
    hostname_path = hostname_data.get("file_path", "")
    hostname_error = hostname_data.get("error", "")
    hostname_mod_date = hostname_data.get("modified", "Unknown")
    hostname_size = hostname_data.get("size", 0)
    
    html += f"""
            <div class="property-card">
                <div class="property-header">
                    <div class="property-title">
                        <span style="margin-right:10px;">🌐</span> Hostname
                    </div>
                    <span class="property-status {'property-found' if hostname_exists else 'property-not-found'}">
                        {'Found' if hostname_exists else 'Not Found'}
                    </span>
                </div>
                <div class="property-path">{hostname_path}</div>"""
            
    if hostname_error:
        html += f"""
                <div class="error-message">Error: {hostname_error}</div>"""
    
    if hostname_exists and hostname_content:
        html += f"""
                <div class="property-content">{hostname_content}</div>
                <div class="property-details">
                    <div class="property-detail-item">
                        <div class="property-detail-label">File Size</div>
                        <div class="property-detail-value">{hostname_size} bytes</div>
                    </div>
                    <div class="property-detail-item">
                        <div class="property-detail-label">Modified</div>
                        <div class="property-detail-value">{hostname_mod_date.split()[0]}</div>
                    </div>"""
                    
        # Add additional hostname details if available
        for key, value in hostname_info.items():
            html += f"""
                    <div class="property-detail-item">
                        <div class="property-detail-label">{key.replace('_', ' ').title()}</div>
                        <div class="property-detail-value">{value}</div>
                    </div>"""
        
        html += """
                </div>"""
    
    html += """
            </div>
        </div>"""
    
    # Authenticity Section
    html += f"""
        <div class="authenticity-section">
            <div class="authenticity-title">Device Authenticity Analysis</div>"""
    
    if auth_results:
        if "manufacturer" in auth_results:
            html += f"""
            <div class="authenticity-result">
                <div class="authenticity-label">Manufacturer</div>
                <div class="authenticity-value authenticity-info">{auth_results['manufacturer']}</div>
            </div>"""
        
        if "device_model" in auth_results:
            html += f"""
            <div class="authenticity-result">
                <div class="authenticity-label">Device Model</div>
                <div class="authenticity-value authenticity-info">{auth_results['device_model']}</div>
            </div>"""
        
        if "serialno_valid" in auth_results:
            html += f"""
            <div class="authenticity-result">
                <div class="authenticity-label">Serial Number Format</div>
                <div class="authenticity-value {'authenticity-valid' if auth_results['serialno_valid'] else 'authenticity-invalid'}">
                    {'Valid' if auth_results['serialno_valid'] else 'Invalid'}
                </div>
            </div>"""
        
        if "hostname_valid" in auth_results:
            html += f"""
            <div class="authenticity-result">
                <div class="authenticity-label">Hostname Format</div>
                <div class="authenticity-value {'authenticity-valid' if auth_results['hostname_valid'] else 'authenticity-invalid'}">
                    {'Valid' if auth_results['hostname_valid'] else 'Invalid'}
                </div>
            </div>"""
        
        if "consistent" in auth_results:
            html += f"""
            <div class="authenticity-result">
                <div class="authenticity-label">Serialno/Hostname Consistency</div>
                <div class="authenticity-value {'authenticity-valid' if auth_results['consistent'] else 'authenticity-warning'}">
                    {'Consistent' if auth_results['consistent'] else 'Inconsistent'}
                </div>
            </div>"""
    else:
        html += """
            <div class="warning-card">
                <div class="warning-title">⚠️ Insufficient Data</div>
                <p>Not enough data to perform authenticity analysis.</p>
            </div>"""
    
    html += """
        </div>"""
    
    # Warning if files not found
    if not results.get("both_exist", False):
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ Missing Files</div>
            <p>One or both property files could not be found. This may indicate incomplete data extraction or device specifics.</p>
        </div>"""
    
    # Footer
    html += f"""
        <div class="footer">
            <p>📁 Report path: <code id="reportPath">{output_path}</code></p>
            <p>DroneSage © 2025 - Drone Property Analyzer</p>
        </div>
    </div>

    <script>
        // Set absolute path for report
        document.getElementById('reportPath').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # Use relative paths for files to analyze
    base_path = Path.home() / "ForenSage"
    serialno_path = base_path / "analyze/drone/property/ro.serialno"
    hostname_path = base_path / "analyze/drone/property/net.hostname"
    
    # For output, use a results directory
    output_html = base_path / "results/drone_device_info.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    print(f"Analyzing serial number file: {os.path.abspath(serialno_path)}")
    print(f"Analyzing hostname file: {os.path.abspath(hostname_path)}")
    print(f"Output will be saved to: {os.path.abspath(output_html)}")
    
    # Analyze property files
    results, success = analyze_property_files(serialno_path, hostname_path)
    
    # Generate HTML report
    generate_property_analysis_html(results, output_html)

if __name__ == "__main__":
    main()