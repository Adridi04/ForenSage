import os
import datetime
from pathlib import Path
import re

def analyze_txt_files(directory_path):
    """Analyzes all TXT files in the given directory and extracts basic information."""
    results = {}
    
    try:
        abs_directory = os.path.abspath(directory_path)
        if not os.path.exists(abs_directory):
            print(f"Error: Directory not found: {abs_directory}")
            return results, False
        
        print(f"Scanning directory: {abs_directory}")
        all_files = os.listdir(abs_directory)
        print(f"Found {len(all_files)} files in directory")
        
        txt_files = [f for f in all_files if f.lower().endswith('.txt')]
        print(f"Found {len(txt_files)} TXT files: {txt_files[:5]}")
        
        if not txt_files:
            print(f"No TXT files found in: {abs_directory}")
            return results, True
        
        for txt_file in txt_files:
            file_path = os.path.join(directory_path, txt_file)
            file_data = {}
            
            try:
                # Get file metadata
                file_stat = os.stat(file_path)
                file_size = file_stat.st_size
                mod_time = datetime.datetime.fromtimestamp(file_stat.st_mtime)
                
                # Read first few lines to get an idea of content
                preview_lines = []
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                        for i, line in enumerate(f):
                            if i >= 10:  # Limit to first 10 lines
                                break
                            preview_lines.append(line.strip())
                except Exception as read_error:
                    print(f"Warning: Could not read {file_path}: {read_error}")
                    # Try binary read as fallback
                    try:
                        with open(file_path, 'rb') as f:
                            binary_data = f.read(500)  # Read first 500 bytes
                            preview_lines = [f"Binary file: {binary_data[:50].hex()}..."]
                    except Exception as bin_error:
                        preview_lines = [f"File unreadable: {bin_error}"]
                
                # Extract flight data patterns (basic patterns that might be in DJI flight logs)
                coords_pattern = re.compile(r'(\d+\.\d+),\s*(\d+\.\d+)')
                time_pattern = re.compile(r'\d{2}:\d{2}:\d{2}')
                altitude_pattern = re.compile(r'alt[:\s]+(\d+\.?\d*)', re.IGNORECASE)
                battery_pattern = re.compile(r'batt[ery\s]*[:\s]+(\d+)', re.IGNORECASE)
                
                coords_found = []
                times_found = []
                altitude_found = []
                battery_found = []
                
                for line in preview_lines:
                    coords_matches = coords_pattern.findall(line)
                    if coords_matches:
                        coords_found.extend(coords_matches[:2])  # Limit to prevent overload
                    
                    time_matches = time_pattern.findall(line)
                    if time_matches:
                        times_found.extend(time_matches[:2])
                    
                    altitude_match = altitude_pattern.search(line)
                    if altitude_match:
                        altitude_found.append(altitude_match.group(1))
                    
                    battery_match = battery_pattern.search(line)
                    if battery_match:
                        battery_found.append(battery_match.group(1))
                
                # Store data
                file_data = {
                    "size": file_size,
                    "modified": mod_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "preview": preview_lines,
                    "coords": coords_found[:2],
                    "times": times_found[:2],
                    "altitude": altitude_found[:1],
                    "battery": battery_found[:1]
                }
                
                results[txt_file] = {
                    "data": file_data,
                    "file_path": file_path,
                    "file_exists": True
                }
                
            except Exception as e:
                print(f"Error analyzing {file_path}: {e}")
                results[txt_file] = {
                    "data": {},
                    "file_path": file_path,
                    "file_exists": os.path.exists(file_path),
                    "error": str(e)
                }
        
        return results, True
        
    except Exception as e:
        print(f"General error: {e}")
        return results, False

def categorize_flight_record(filename, data):
    """Categorizes flight records based on file content, not assuming anything about filenames"""
    
    # Try to determine category based on content keywords in preview
    preview_text = " ".join(data.get("preview", [])).lower() if data else ""
    
    if preview_text:
        if any(keyword in preview_text for keyword in ["calib", "gimbal", "imu"]):
            return "Calibration"
        elif any(keyword in preview_text for keyword in ["crash", "error", "fail", "emerg"]):
            return "Incident"
        elif any(keyword in preview_text for keyword in ["test", "debug", "init"]):
            return "Test Flight"
        elif any(keyword in preview_text for keyword in ["mission", "waypoint", "auto", "path"]):
            return "Planned Mission"
        elif any(keyword in preview_text for keyword in ["record", "flight", "log", "dji"]):
            return "Flight Record"
    
    # Try to determine flight date from filename as fallback
    filename_lower = filename.lower()
    date_pattern = re.compile(r'(\d{4})[_\-]?(\d{2})[_\-]?(\d{2})')
    date_match = date_pattern.search(filename_lower)
    
    if date_match:
        year, month, day = date_match.groups()
        return f"Flight {year}-{month}-{day}"
    
    # Default
    return "Flight Data"

def generate_flight_records_html(results, directory_info, output_path):
    """Generates an HTML report with the analyzed TXT files"""
    if not os.path.exists(os.path.dirname(output_path)):
        try:
            os.makedirs(os.path.dirname(output_path))
        except Exception as e:
            print(f"Error creating output directory: {e}")
            return False
    
    directory_path, directory_exists = directory_info
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    file_count = len(results)

            # Generate colors for different categories
    category_colors = {
        "Flight Record": "#3498db", 
        "Flight Data": "#3498db",
        "Calibration": "#2ecc71", 
        "Incident": "#e74c3c",
        "Test Flight": "#f39c12", 
        "Planned Mission": "#9b59b6"
    }
    
    # Add colors for dynamic Flight date categories
    for key in results.keys():
        category = categorize_flight_record(key, results[key].get("data", {}))
        if category.startswith("Flight 20") and category not in category_colors:
            category_colors[category] = "#3498db"  # Use the same blue for all flight dates
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DJI Drone Flight Records Analysis</title>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary-dark: #1a2b3c; --primary: #23374d; --primary-light: #345678;
            --accent: #00a8ff; --accent-light: #29b6f6; --text: #e0e6ed;
            --text-secondary: #a7b9cc; --background: #0a1622; --card-bg: #12202e;
            --border-color: rgba(0, 168, 255, 0.2); --success: #00e676;
            --warning: #ffab00; --danger: #ff1744; --grid-line: rgba(0, 168, 255, 0.1);
        }}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            font-family: 'Rajdhani', sans-serif; background-color: var(--background);
            color: var(--text); line-height: 1.6; margin: 0; padding: 0;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(0, 168, 255, 0.05) 0%, transparent 80%),
                linear-gradient(to bottom, transparent 0%, rgba(0, 168, 255, 0.03) 100%);
            background-attachment: fixed; position: relative; overflow-x: hidden;
        }}

        body::before {{
            content: ''; position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background-image: 
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px),
                linear-gradient(0deg, var(--grid-line) 1px, transparent 1px);
            background-size: 20px 20px; z-index: -1; opacity: 0.2;
        }}

        .container {{
            max-width: 1200px; margin: 0 auto; padding: 2rem;
            position: relative; z-index: 1; animation: fadeIn 0.7s ease-in-out;
        }}

        .header {{ text-align: center; margin-bottom: 3rem; position: relative; }}

        .title {{
            font-family: 'Share Tech Mono', monospace; font-size: 2.5rem; font-weight: 700;
            margin-bottom: 0.5rem; background: linear-gradient(135deg, var(--accent), var(--accent-light));
            -webkit-background-clip: text; background-clip: text; color: transparent;
            text-transform: uppercase; letter-spacing: 2px; position: relative; display: inline-block;
        }}

        .title::after {{
            content: ''; position: absolute; bottom: -10px; left: 50%;
            transform: translateX(-50%); width: 100px; height: 3px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }}

        .subtitle {{ color: var(--text-secondary); margin-bottom: 2rem; font-size: 1.1rem; }}

        .dashboard {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }}

        .stat-card {{
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            border-radius: 15px; padding: 1.5rem; box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            position: relative; overflow: hidden; transition: transform 0.3s ease, box-shadow 0.3s ease;
            display: flex; flex-direction: column; justify-content: center; align-items: center;
        }}

        .stat-card:hover {{ transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3); }}

        .stat-card::before {{
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 4px; background: linear-gradient(90deg, var(--accent), var(--accent-light));
        }}

        .stat-label {{
            font-size: 0.9rem; color: var(--text-secondary);
            text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;
        }}

        .stat-value {{ font-size: 2rem; font-weight: 700; color: var(--accent-light); }}

        .source-container {{ 
            margin-top: 2rem; margin-bottom: 2rem; 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }}

        .source-card {{
            background-color: var(--primary); border-radius: 12px;
            padding: 1.5rem; border-left: 4px solid var(--accent);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); position: relative; overflow: hidden;
            height: 100%; display: flex; flex-direction: column;
        }}

        .source-header {{
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;
        }}

        .source-title {{
            font-family: 'Share Tech Mono', monospace; font-size: 1.3rem;
            color: var(--accent-light); font-weight: 600; display: flex; align-items: center;
        }}

        .source-path {{
            font-family: 'Share Tech Mono', monospace; color: var(--text); background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem; border-radius: 6px; font-size: 0.9rem;
            width: 100%; overflow-x: auto; margin-top: 0.5rem; white-space: nowrap;
        }}

        .source-status {{
            font-size: 0.8rem; padding: 0.3rem 0.8rem; border-radius: 12px;
            font-weight: 600; letter-spacing: 0.5px;
        }}

        .source-found {{ background-color: var(--success); color: #000; }}
        .source-not-found {{ background-color: var(--danger); color: var(--text); }}

        .flight-info {{
            background-color: var(--card-bg); border-radius: 8px; padding: 1rem;
            margin-top: 1rem; border-left: 4px solid var(--accent);
            display: flex; flex-direction: column; flex-grow: 1;
        }}

        .flight-stats {{
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 0.8rem;
            margin-top: 1rem;
        }}

        .flight-stat-item {{
            background-color: rgba(0, 0, 0, 0.2);
            padding: 0.5rem;
            border-radius: 6px;
            text-align: center;
        }}

        .flight-stat-label {{
            font-size: 0.7rem;
            color: var(--text-secondary);
            text-transform: uppercase;
        }}

        .flight-stat-value {{
            font-family: 'Share Tech Mono', monospace;
            font-size: 1rem;
            color: var(--accent);
        }}

        .preview-section {{
            margin-top: 1rem;
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.8rem;
            background-color: #0a1622;
            padding: 0.8rem;
            border-radius: 6px;
            max-height: 100px;
            overflow-y: auto;
            color: #a7b9cc;
        }}

        .preview-line {{
            margin-bottom: 2px;
            white-space: nowrap;
            overflow-x: hidden;
            text-overflow: ellipsis;
        }}

        .drone-icon-container {{
            position: relative;
            text-align: center;
            margin: 2rem 0;
        }}

        .drone-icon {{
            width: 100px;
            height: 100px;
            position: relative;
            display: inline-block;
        }}

        .drone-body {{
            width: 40px;
            height: 10px;
            background-color: var(--accent);
            position: absolute;
            top: 45px;
            left: 30px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 168, 255, 0.5);
        }}

        .drone-arm1, .drone-arm2, .drone-arm3, .drone-arm4 {{
            width: 50px;
            height: 4px;
            background-color: var(--accent-light);
            position: absolute;
            border-radius: 2px;
        }}

        .drone-arm1 {{ transform: rotate(45deg); top: 35px; left: 15px; }}
        .drone-arm2 {{ transform: rotate(-45deg); top: 35px; left: 35px; }}
        .drone-arm3 {{ transform: rotate(135deg); top: 60px; left: 15px; }}
        .drone-arm4 {{ transform: rotate(-135deg); top: 60px; left: 35px; }}
        
        .drone-prop1, .drone-prop2, .drone-prop3, .drone-prop4 {{
            width: 20px;
            height: 4px;
            background-color: var(--accent);
            position: absolute;
            border-radius: 2px;
            animation: spin 1s linear infinite;
        }}
        
        .drone-prop1 {{ top: 25px; left: 10px; }}
        .drone-prop2 {{ top: 25px; left: 70px; }}
        .drone-prop3 {{ top: 70px; left: 10px; }}
        .drone-prop4 {{ top: 70px; left: 70px; }}
        
        @keyframes spin {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}

        .drone-shadow {{
            width: 60px;
            height: 12px;
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 50%;
            position: absolute;
            bottom: -20px;
            left: 20px;
            filter: blur(5px);
        }}

        .warning-card {{
            background-color: var(--card-bg); border-left: 4px solid var(--warning);
            border-radius: 10px; padding: 1.5rem; margin: 2rem auto;
            max-width: 600px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }}

        .warning-title {{
            color: var(--warning); font-size: 1.2rem; font-weight: 600;
            margin-bottom: 0.5rem; display: flex; align-items: center;
        }}

        .footer {{
            text-align: center; margin-top: 3rem; color: var(--text-secondary);
            font-size: 0.9rem; border-top: 1px solid var(--border-color);
            padding-top: 1.5rem; position: relative;
        }}

        .error-message {{ color: var(--danger); margin-top: 0.5rem; font-style: italic; font-size: 0.9rem; }}

        .category-badge {{
            padding: 0.2rem 0.6rem; border-radius: 10px; font-size: 0.75rem; 
            font-weight: 600; margin-top: 0.5rem; align-self: flex-start;
        }}

        @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(20px); }} to {{ opacity: 1; transform: translateY(0); }} }}

        @media (max-width: 768px) {{
            .container {{ padding: 1rem; }}
            .title {{ font-size: 1.8rem; }}
            .source-header {{ flex-direction: column; align-items: flex-start; }}
            .source-status {{ margin-top: 0.5rem; }}
            .source-container {{ grid-template-columns: 1fr; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">DJI Drone Flight Records</h1>
            <p class="subtitle">📅 Analysis Generated on {now}</p>
        </div>

        <!-- Animated Drone Icon -->
        <div class="drone-icon-container">
            <div class="drone-icon">
                <div class="drone-body"></div>
                <div class="drone-arm1"></div>
                <div class="drone-arm2"></div>
                <div class="drone-arm3"></div>
                <div class="drone-arm4"></div>
                <div class="drone-prop1"></div>
                <div class="drone-prop2"></div>
                <div class="drone-prop3"></div>
                <div class="drone-prop4"></div>
                <div class="drone-shadow"></div>
            </div>
        </div>

        <!-- Dashboard Stats -->
        <div class="dashboard">
            <div class="stat-card">
                <div class="stat-label">Flight Records</div>
                <div class="stat-value">{file_count}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Directory</div>
                <div class="stat-value">{os.path.basename(directory_path)}</div>
            </div>
        </div>"""

    if not directory_exists:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ Directory not found</div>
            <p>The specified flight records directory could not be found.</p>
        </div>"""
    elif not results:
        html += """
        <div class="warning-card">
            <div class="warning-title">⚠️ No TXT files found</div>
            <p>No TXT flight record files were found in the specified directory.</p>
        </div>"""
    else:
        # Process files
        html += """
        <div class="source-container">"""
        
        for file_name, file_info in results.items():
            file_path = file_info["file_path"]
            file_exists = file_info["file_exists"]
            status_text = "Found" if file_exists else "Not Found"
            status_class = "source-found" if file_exists else "source-not-found"
            
            category = categorize_flight_record(file_name, file_info.get("data", {}))
            color = category_colors.get(category, "#7f8c8d")
            
            html += f"""
            <div class="source-card">
                <div class="source-header">
                    <div class="source-title">
                        <span style="margin-right:10px;">📄</span> {file_name}
                    </div>
                    <span class="source-status {status_class}">{status_text}</span>
                </div>
                <div class="source-path">{file_path}</div>"""
            
            if "error" in file_info:
                html += f"""
                <div class="error-message">Error: {file_info["error"]}</div>"""
            
            if file_exists and "data" in file_info:
                data = file_info["data"]
                
                # Extract information
                file_size = data.get("size", 0)
                file_size_kb = file_size / 1024
                modified = data.get("modified", "Unknown")
                coords = data.get("coords", [])
                times = data.get("times", [])
                altitude = data.get("altitude", ["--"])
                battery = data.get("battery", ["--"])
                preview = data.get("preview", [])
                
                html += f"""
                <div class="flight-info">
                    <div class="flight-stats">
                        <div class="flight-stat-item">
                            <div class="flight-stat-label">Size</div>
                            <div class="flight-stat-value">{file_size_kb:.1f} KB</div>
                        </div>
                        <div class="flight-stat-item">
                            <div class="flight-stat-label">Modified</div>
                            <div class="flight-stat-value">{modified.split()[0]}</div>
                        </div>"""
                
                if altitude and altitude[0] != "--":
                    html += f"""
                        <div class="flight-stat-item">
                            <div class="flight-stat-label">Altitude</div>
                            <div class="flight-stat-value">{altitude[0]} m</div>
                        </div>"""
                
                if battery and battery[0] != "--":
                    html += f"""
                        <div class="flight-stat-item">
                            <div class="flight-stat-label">Battery</div>
                            <div class="flight-stat-value">{battery[0]}%</div>
                        </div>"""
                
                html += """
                    </div>"""
                
                if preview:
                    html += """
                    <div class="preview-section">"""
                    for line in preview:
                        html += f"""
                        <div class="preview-line">{line}</div>"""
                    html += """
                    </div>"""
                
                html += f"""
                    <span class="category-badge" style="background-color:{color};">{category}</span>
                </div>"""
            
            html += """
            </div>"""
        
        html += """
        </div>"""

    # Footer
    html += f"""
        <div class="footer">
            <p>📁 Report path: <code id="reportPath">{output_path}</code></p>
            <p>📁 Directory analyzed: <code>{directory_path}</code></p>
            <p>DroneSage © 2025 - Drone Flight Records Analyzer</p>
        </div>
    </div>

   <script>
        // Set absolute path for report
        document.getElementById('reportPath').textContent = document.location.pathname;
    </script>
</body>
</html>"""

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"✅ Report generated at: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return False

def main():
    # Use relative paths for directory to analyze
    # Using the path provided by the user

    base_path = Path.home() / "ForenSage"
    directory_to_analyze = base_path / "analyze/drone/sdcard/DJI/dji.go.v4/FlightRecord/"
    abs_directory = os.path.abspath(directory_to_analyze)
    
    # For output, use the specified path
    output_html = base_path / "results/drone_fligths_record.html"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    
    print(f"Analyzing directory: {abs_directory}")
    print(f"Output will be saved to: {os.path.abspath(output_html)}")
    
    # Analyze TXT files
    results, directory_exists = analyze_txt_files(directory_to_analyze)
    
    # Generate HTML report
    generate_flight_records_html(results, (directory_to_analyze, directory_exists), output_html)

if __name__ == "__main__":
    main()