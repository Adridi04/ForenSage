from flask import Flask, render_template, request, send_file, redirect, url_for, flash
from flask import send_from_directory
from flask import Flask, send_file
import os
from datetime import datetime
from pathlib import Path

app = Flask(__name__)
# Create results directory if it doesn't exist / Crear directorio results si no existe
os.makedirs('results', exist_ok=True)

# -------------------- Import Scripts Android / Importar Scripts Android --------------------

from scripts.android.and_device_info import analizar_settings,generar_html
from scripts.android.and_sim_info import extract_sim_info, create_visual_sim_html
from scripts.android.and_sim_blockphone import analyze_blocked_numbers_db
from scripts.android.and_media_info import buscar_multimedia, generar_html_multimedia
from scripts.android.and_app_install import obtener_datos_apps , generar_html_app
from scripts.android.and_calllog_info import obtener_datos_llamadas, generar_html_calllog
from scripts.android.and_accounts_info import obtener_datos_cuentas_xml,obtener_datos_db, obtener_dashboard_xml,combinar_datos, generar_html_accounts
from scripts.android.and_browserhistoy_info import analizar_historial_chrome, generar_html_browserhistory
from scripts.android.and_whatsapp_info import analizar_db_whatsapp, generar_html_whatsapp
from scripts.android.and_calendar_info import analizar_db_calendario, generar_html_calendario
from scripts.android.and_numbers_info import analizar_db_contactos, merge_resultados, generar_html_contactos, analizar_archivos_especiales
from scripts.android.and_wifi_info import leer_xml_archivo, generar_html_xml_viewer
from scripts.android.and_bluetooth_info import analizar_bluetooth_db, analizar_bluetooth_xml, generar_html_bluetooth_analysis



# -------------------- Define HTMLS / Definir HTMLS --------------------

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/android')
def android():
    return render_template('android.html')

@app.route('/IOS')
def ios():
    return render_template('IOS.html')

@app.route('/amecho')
def amecho():
    return render_template('amazon_echo.html')

@app.route('/drone')
def drone():
    return render_template('drone.html')



# -------------------- SCRIPTS ANDORID --------------------

# android device info 

@app.route('/and_device_info')
def and_device_info_gen():
    
    archivo_xml = Path.home() / "ForenSage" / "analyze" / "android" / "data" / "system" / "users" / "0" / "settings_system.xml"
    archivo_xml = Path.home() / "ForenSage" / "analyze" / "android" / "data" / "system" / "users" / "0" / "settings_global.xml"
    salida_html = Path.home() / "ForenSage" / "results" / "and_device_info.html"

    configuraciones = analizar_settings(archivo_xml)
    if configuraciones:
        generar_html(configuraciones, salida_html)

    return send_from_directory(salida_html.parent, salida_html.name)



# android sim info

@app.route('/and_sim_info')
def and_sim_info_gen():

    db_path = Path.home() / "ForenSage" / "analyze" / "android" / "data" / "user_de" / "0" / "com.android.providers.telephony" / "databases" / "telephony.db"
    salida_html = Path.home() / "ForenSage" / "results" / "and_sim_info.html"
    
    columns, rows = extract_sim_info(db_path)
    
    if columns and rows:
        create_visual_sim_html(columns, rows, salida_html)
    else:
        return "No se pudieron encontrar datos de SIM"
    
    return send_from_directory(salida_html.parent, salida_html.name)



# android sim blocked numbers

@app.route('/and_blocked_numbers')
def and_blocked_numbers_gen():
    base_dir = Path.home() / "ForenSage"
    db_path = base_dir / "analyze/android/data/user_de/0/com.android.providers.blockednumber/databases/blockednumbers.db"
    results_dir = base_dir / "results"
    output_html = results_dir / "blocked_numbers_report.html"

    analyze_blocked_numbers_db(db_path, output_html)
    
    return send_from_directory(output_html.parent, output_html.name)



# android numbers phone

@app.route('/android_contacts')
def android_contacts():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "Android_contacts_report.html"
    
    contact_paths = {
        'db1': base_dir / "analyze/android/data/data/com.android.providers.contacts/databases/contacts2.db",
        'db2': base_dir / "analyze/android/data/data/com.google.android.contacts/databases/contacts.db",
        'vdex': base_dir / "analyze/android/product/app/GoogleContacts/oat/arm64/GoogleContacts.vdex",
        'dict': base_dir / "analyze/android/data/data/com.google.android.inputmethod.latin/files/personal/Contacts.dict"
    }
    
    os.makedirs(results_dir, exist_ok=True)
    
    todos_resultados = []
    
    for db_key in ['db1', 'db2']:
        if contact_paths[db_key].exists():
            resultados = analizar_db_contactos(str(contact_paths[db_key]))
            todos_resultados.append(resultados)
    
    for key, tipo in [('vdex', 'VDEX'), ('dict', 'Dict')]:
        if contact_paths[key].exists():
            resultados = analizar_archivos_especiales(str(contact_paths[key]), tipo)
            todos_resultados.append(resultados)
    
    resultados_combinados = merge_resultados(todos_resultados)
    
    generar_html_contactos(resultados_combinados, str(output_html))
    return send_from_directory(results_dir, "Android_contacts_report.html")
    
    
# android multimedia

@app.route('/media/<path:filename>')
def serve_media(filename):
    base_dir = Path.home() / "ForenSage"
    return send_from_directory(base_dir, filename)

@app.route('/and_media_info')
def and_multimedia_gen():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "adn_media.html"
    
    rutas_multimedia_relativas = [
        "analyze/android/data/media/0/DCIM/Camera/",
        "analyze/android/data/media/0/DCIM/Restored/",
        "analyze/android/data/media/0/DCIM/imo/",
        "analyze/android/data/media/0/Pictures/",
        "analyze/android/data/media/0/Download/"
    ]
    archivos = buscar_multimedia(rutas_multimedia_relativas)
    
    if archivos:
        generar_html_multimedia(archivos, Path("results/adn_media.html"), web_mode=True)
    
    return send_from_directory(output_html.parent, output_html.name)


# app install

@app.route('/and_app_install')
def and_app_install_gen():
    base_dir = Path.home() / "ForenSage"
    db_path = base_dir / "analyze/android/data/data/com.android.vending/databases/localappstate.db"
    results_dir = base_dir / "results"
    output_html = results_dir / "and_app_install.html"
    
    os.makedirs(results_dir, exist_ok=True)
    
    datos_apps = obtener_datos_apps(db_path)
    
    if datos_apps:
        html_content = generar_html_app(datos_apps)
        with open(output_html, 'w', encoding='utf-8') as f:
            f.write(html_content)
    return send_from_directory(output_html.parent, output_html.name)


# Call Logs

@app.route('/and_calllog_info')
def call_logs_gen():
    base_dir = Path.home() / "ForenSage"
    db_path = base_dir / "analyze/android/data/data/com.android.providers.contacts/databases/calllog.db"
    results_dir = base_dir / "results"
    output_html = results_dir / "call_logs.html"
    
    os.makedirs(results_dir, exist_ok=True)
    
    datos_llamadas = obtener_datos_llamadas(db_path)
    
    if datos_llamadas:
        html_content = generar_html_calllog(datos_llamadas)
        with open(output_html, 'w', encoding='utf-8') as f:
            f.write(html_content)
    return send_from_directory(output_html.parent, output_html.name)



# Accounts Information

@app.route('/and_accounts_info')
def accounts_sync_gen():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "accounts_sync.html"
    
    xml_path = base_dir / "analyze/android/data/system/sync/accounts.xml"
    db_path = base_dir / "analyze/android/data/system_ce/0/accounts_ce.db"
    dashboard_pattern = "analyze/android/data/system_ce/0/launch*params/com.android.settings*.Settings$AccountDashboardActivity.xml"
    
    os.makedirs(results_dir, exist_ok=True)
    
    datos = combinar_datos(
        obtener_datos_cuentas_xml(xml_path),
        obtener_datos_db(db_path),
        obtener_dashboard_xml(dashboard_pattern)
    )
    
    if datos and datos['stats']['total'] > 0:
        with open(output_html, 'w', encoding='utf-8') as f:
            f.write(generar_html_accounts(datos))
        app.logger.info(f"Informe de cuentas generado: {datos['stats']['total']} cuentas")
    else:
        app.logger.warning("No se encontraron datos de cuentas")
        
    return send_from_directory(output_html.parent, output_html.name)



# Browser History

@app.route('/and_browserhistoy_info')
def chrome_history_gen():

    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "chrome_history_report.html"
    ruta_historial = base_dir / "analyze/android/data/data/com.android.chrome/app_chrome/Default/History"
    
    os.makedirs(results_dir, exist_ok=True)
    
    app.logger.info(f"Analizando historial Chrome: {ruta_historial}")
    resultados = analizar_historial_chrome(ruta_historial)
    
    if resultados:
        app.logger.info(f"Entradas encontradas: {len(resultados)}")
        generar_html_browserhistory(resultados, output_html)
        return send_from_directory(output_html.parent, output_html.name)
    else:
        app.logger.warning("No se encontraron entradas de historial")
        return "No se encontraron datos de historial de Chrome", 404



# Whatsapp info

@app.route('/and_whatsapp_info')
def whatsapp_analysis_gen():
    db_path = Path.home() / "ForenSage/analyze/android/data/data/com.whatsapp/databases/msgstore.db"
    output_html = Path.home() / "ForenSage/results/whatsapp_analysis.html"
    
    if not db_path.exists():
        return "Base de datos de WhatsApp no encontrada", 404
    
    resultados = analizar_db_whatsapp(db_path)
    
    if not any(resultados.values()):
        return "No se encontraron datos en la base de datos", 404
    
    os.makedirs(output_html.parent, exist_ok=True)
    generar_html_whatsapp(resultados, output_html)
    return send_from_directory(output_html.parent, output_html.name)



# Calendar Info

@app.route('/and_calendar')
def analyze_android_calendar():
    """Endpoint para analizar la base de datos del calendario Android"""

    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "and_calendar_info.html"
    db_path = base_dir / "analyze/android/data/data/com.android.providers.calendar/databases/calendar.db"
    
    os.makedirs(results_dir, exist_ok=True)
    
    if not db_path.exists():
        return "Base de datos no encontrada", 404
    
    resultados = analizar_db_calendario(db_path)
    
    generar_html_calendario(resultados, output_html)

    return send_from_directory(results_dir, "and_calendar_info.html")




# Wifi Info

@app.route('/and_wifi_info')
def android_xml_viewer():

    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "Android_XML_viewer.html"
    
    rutas_a_analizar = [
        base_dir / "analyze/android/data/misc/wifi/WifiConfigStore.xml",
        base_dir / "analyze/android/data/misc_ce/0/wifi/WifiConfigStore.xml"
    ]
    
    os.makedirs(results_dir, exist_ok=True)
    
    archivos_contenido = []
    archivos_info = []
    
    for ruta in rutas_a_analizar:
        contenido, existe = leer_xml_archivo(str(ruta))
        archivos_contenido.append(contenido)
        archivos_info.append((str(ruta), existe))
    
    generar_html_xml_viewer(archivos_contenido, archivos_info, str(output_html))
    
    return send_from_directory(results_dir, "Android_XML_viewer.html")
    


# Bluetooth Info

@app.route('/android_bluetooth')
def android_bluetooth():

    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "and_Bluetooth_info.html"

    bluetooth_paths = {
        'db': base_dir / "analyze/android/data/user_de/0/com.android.bluetooth/databases/bluetooth_db",
        'prefs': base_dir / "analyze/android/data/user_de/0/com.android.bluetooth/shared_prefs/com.android.bluetooth_preferences.xml",
        'volume': base_dir / "analyze/android/data/user_de/0/com.android.bluetooth/shared_prefs/bluetooth_volume_map.xml"
    }
    
    os.makedirs(results_dir, exist_ok=True)
    
    db_datos, db_existe = analizar_bluetooth_db(str(bluetooth_paths['db']))
    prefs_datos, prefs_existe = analizar_bluetooth_xml(str(bluetooth_paths['prefs']))
    volume_datos, volume_existe = analizar_bluetooth_xml(str(bluetooth_paths['volume']))
    
    archivos_info = [
        (str(bluetooth_paths['db']), db_existe),
        (str(bluetooth_paths['prefs']), prefs_existe),
        (str(bluetooth_paths['volume']), volume_existe)
    ]
    generar_html_bluetooth_analysis(
        db_datos, prefs_datos, volume_datos, 
        archivos_info, str(output_html)
    )
    return send_from_directory(results_dir, "and_Bluetooth_info.html")



# -------------------- Import Scripts IOS / Importar Scripts IOS --------------------

from scripts.ios.IOS_SystemInfo1 import analizar_system_version_plist, generar_html_SystemInfo1
from scripts.ios.IOS_SystemInfo2 import analizar_effective_user_settings, generar_html_SystemInfo2
from scripts.ios.IOS_SystemInfo3 import analizar_data_ark_plist,generar_html_SystemInfo3
from scripts.ios.IOS_sms_info import analizar_db_mensajes,generar_html_ConversacionAnalysis
from scripts.ios.IOS_SIM_info import analizar_commcenter_plist, generar_html_SimCardInfo
from scripts.ios.IOS_app_installed import analizar_db_appstore, generar_html_AppStoreAnalysis
from scripts.ios.IOS_location_info import analizar_location_db, generar_html_mapa
from scripts.ios.IOS_calendar_info import analizar_calendario_sqlite, generar_html_calendario
from scripts.ios.IOS_SimUsage import analizar_db_cellular_usage, generar_html_CellularUsageAnalysis
from scripts.ios.IOS_browserhistory import analizar_safari_history, generar_html_BrowserHistory
from scripts.ios.IOS_img_info import extraer_imagenes, generar_html_imagenes
from scripts.ios.IOS_accounts_info import analizar_accounts_plist, generar_html_AccountsInfo
from scripts.ios.IOS_IconSatete import analizar_iconstate_plist , generar_html_simplificado
from scripts.ios.IOS_files_info import analyze_downloads_folder, generate_html_files
from scripts.ios.IOS_contactas_info import analyze_addressbook_db , generate_html_AddressBookAnalysis
from scripts.ios.IOS_whatsapp import extract_messages_from_zwamessage, connect_to_db

# -------------------- SCRIPTS IOS --------------------

# SystemInfo 1

@app.route('/ios_system_info1')
def ios_system_info_gen():
    # Configuration paths
    plist_path = Path("analyze/ios/System/Library/CoreServices/SystemVersion.plist")
    output_html = Path.home() / "ForenSage/results/IOS_SystemInfo1.html"
    
    # Verify and analyze
    if not plist_path.exists():
        return "SystemVersion.plist file not found", 404
    
    data, exists = analizar_system_version_plist(plist_path)
    
    if not data:
        return "No system information could be extracted", 404
    
    # Generate and return report
    os.makedirs(output_html.parent, exist_ok=True)
    if generar_html_SystemInfo1(data, (str(plist_path), exists), output_html):
        return send_from_directory(output_html.parent, output_html.name)
    else:
        return "Error generating report", 500



# SystemInfo 2

@app.route('/ios_system_info2')
def ios_user_settings_gen():
    # Configuration paths
    plist_path = Path("analyze/ios/private/var/mobile/Library/UserConfigurationProfiles/EffectiveUserSettings.plist")
    output_html = Path.home() / "ForenSage/results/IOS_SystemInfo2.html"
    
    # Verify and analyze
    if not plist_path.exists():
        return "EffectiveUserSettings.plist file not found", 404
    
    data, exists = analizar_effective_user_settings(plist_path)
    
    if not data:
        return "No user settings could be extracted", 404
    
    # Generate and return report
    os.makedirs(output_html.parent, exist_ok=True)
    if generar_html_SystemInfo2(data, (str(plist_path), exists), output_html):
        return send_from_directory(output_html.parent, output_html.name)
    else:
        return "Error generating report", 500



# SystemInfo 3

@app.route('/ios_system_info3')
def ios_data_ark_gen():
    # Configuration paths
    plist_path = Path("analyze/ios/private/var/root/Library/Lockdown/data_ark.plist")
    output_html = Path.home() / "ForenSage/results/IOS_SystemInfo3.html"
    
    # Verify and analyze
    if not plist_path.exists():
        return "data_ark.plist file not found", 404
    
    data, exists = analizar_data_ark_plist(plist_path)
    
    if not data:
        return "No device information could be extracted", 404
    
    # Generate and return report
    os.makedirs(output_html.parent, exist_ok=True)
    if generar_html_SystemInfo3(data, (str(plist_path), exists), output_html):
        return send_from_directory(output_html.parent, output_html.name)
    else:
        return "Error generating report", 500
    

#Sim Usage


@app.route('/ios_cellular_usage')
def ios_cellular_usage():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "iOS_SimUsage.html"
    
    # Ruta a la base de datos de uso celular
    db_path = base_dir / "analyze/ios/private/var/wireless/Library/Databases/CellularUsage.db"
    
    # Asegurar que el directorio de resultados existe
    os.makedirs(results_dir, exist_ok=True)
    
    # Analizar la base de datos de uso celular
    datos, existe = analizar_db_cellular_usage(str(db_path))
    
    # Generar el informe HTML
    if generar_html_CellularUsageAnalysis(datos, (str(db_path), existe), str(output_html)):
        app.logger.info(f"Informe de uso celular generado: {output_html}")
    else:
        app.logger.warning("No se pudo generar el informe de uso celular")
    
    return send_from_directory(output_html.parent, output_html.name)



# Sim Info


@app.route('/ios_sim_info')
def ios_simcard_info():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "IOS_sim_Info.html"
    
    # Ruta al archivo plist que contiene la información de la tarjeta SIM
    plist_path = base_dir / "analyze/ios/private/var/wireless/Library/Preferences/com.apple.commcenter.plist"
    
    # Asegurar que el directorio de resultados existe
    os.makedirs(results_dir, exist_ok=True)
    
    # Analizar el archivo
    datos, existe = analizar_commcenter_plist(str(plist_path))
    
    # Generar el informe HTML
    if generar_html_SimCardInfo(datos, (str(plist_path), existe), str(output_html)):
        app.logger.info(f"Informe de tarjeta SIM generado: {output_html}")
    else:
        app.logger.warning("No se pudo generar el informe de tarjeta SIM")
    
    return send_from_directory(output_html.parent, output_html.name)


# Sms Info

@app.route('/ios_messages_analysis')
def ios_messages_analysis_gen():
    # Configuration paths
    db_path = "/home/adrian/ForenSage/analyze/ios/private/var/mobile/Library/SMS/sms.db"
    output_html = Path.home() / "ForenSage/results/iOS_Messages_Analysis.html"
    
    # Verify and analyze
    if not os.path.exists(db_path):
        return "SMS database file not found", 404
    
    data, exists = analizar_db_mensajes(db_path)
    
    if not data.get("mensajes"):
        return "No messages could be extracted from the database", 404
    
    # Generate and return report
    os.makedirs(output_html.parent, exist_ok=True)
    if generar_html_ConversacionAnalysis(data, (db_path, exists), output_html):
        return send_from_directory(output_html.parent, output_html.name)
    else:
        return "Error generating report", 500 


  # App Installed  
    
@app.route('/ios_app_installed')
def ios_appstore_info():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "IOS_app_installed.html"
    
    # Ruta a la base de datos del App Store
    db_path = base_dir / "analyze/ios/private/var/mobile/Library/Caches/com.apple.appstored/storeUser.db"
    
    # Asegurar que el directorio de resultados existe
    os.makedirs(results_dir, exist_ok=True)
    
    # Analizar la base de datos
    datos, existe = analizar_db_appstore(str(db_path))
    
    # Generar el informe HTML
    if generar_html_AppStoreAnalysis(datos, (str(db_path), existe), str(output_html)):
        app.logger.info(f"Informe de App Store generado: {output_html}")
    else:
        app.logger.warning("No se pudo generar el informe de App Store")
    
    return send_from_directory(output_html.parent, output_html.name)



# Location Info

@app.route('/ios_location_info')
def ios_location_info():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "IOS_location_Info.html"
    
    # Ruta a la base de datos de ubicaciones
    db_path = base_dir / "analyze/ios/private/var/root/Library/Caches/locationd/cache_encryptedB.db"
    
    # Asegurar que el directorio de resultados existe
    os.makedirs(results_dir, exist_ok=True)
    
    # Analizar la base de datos de ubicaciones
    ubicaciones, existe = analizar_location_db(str(db_path))
    
    # Generar el informe HTML con el mapa
    if generar_html_mapa(ubicaciones, (str(db_path), existe), str(output_html)):
        app.logger.info(f"Informe de ubicaciones generado: {output_html}")
    else:
        app.logger.warning("No se pudo generar el informe de ubicaciones")
    
    return send_from_directory(output_html.parent, output_html.name)


# Calendar Info

@app.route('/ios_calendar_info')
def ios_calendar_info():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "IOS_calendar_Info.html"
    
    # Ruta a la base de datos del calendario
    db_path = base_dir / "analyze/ios/private/var/mobile/Library/Calendar/Calendar.sqlitedb"
    
    # Asegurar que el directorio de resultados existe
    os.makedirs(results_dir, exist_ok=True)
    
    # Analizar la base de datos del calendario
    datos, exito = analizar_calendario_sqlite(str(db_path))
    
    # Generar el informe HTML
    if generar_html_calendario(datos, (str(db_path), exito), str(output_html)):
        app.logger.info(f"Informe de calendario generado: {output_html}")
    else:
        app.logger.warning("No se pudo generar el informe de calendario")
    
    return send_from_directory(output_html.parent, output_html.name)


# Browserhistory

@app.route('/ios_browser_history')
def ios_browser_history():
    # Configurar rutas
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "IOS_browserhistory.html"
    
    # Ruta a la base de datos de Safari
    db_path = base_dir / "analyze/ios/var/mobile/Library/Safari/History.db"
    
    # Asegurar que el directorio de resultados existe
    os.makedirs(results_dir, exist_ok=True)
    
    # Analizar el historial
    datos, existe, stats, top_domains = analizar_safari_history(str(db_path))
    
    # Generar el informe HTML
    generar_html_BrowserHistory(
        datos, 
        (str(db_path), existe),
        stats,
        top_domains,
        str(output_html)
    )
    
    return send_from_directory(results_dir, "IOS_browserhistory.html")

# Img_Info

@app.route('/ios_images')
def ios_images():
    # Configurar rutas (mismo patrón que ios_browser_history)
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    images_dir = results_dir / "images"
    output_html = results_dir / "IOS_images_report.html"
    
    # Rutas a analizar (ajusta según tu necesidad)
    rutas_a_analizar = [
        base_dir / "analyze/ios/private/var/mobile/Media/DCIM/100APPLE/",
        base_dir / "analyze/ios/private/var/mobile/Media/PhotoData/Metadata/DCIM/100APPLE/",
        base_dir / "analyze/ios/private/var/mobile/Media/PhotoData/Thumbnails/V2/DCIM/100APPLE/"
    ]
    
    # Asegurar directorios
    os.makedirs(images_dir, exist_ok=True)
    
    # Extraer imágenes (usando tu función existente)
    imagenes_info = extraer_imagenes([str(path) for path in rutas_a_analizar], str(images_dir))
    
    # Generar HTML (usando tu función existente)
    generar_html_imagenes(imagenes_info, str(output_html))
    
    # Servir el reporte (igual que en browser_history)
    return send_from_directory(results_dir, "IOS_images_report.html")

# Ruta para servir las imágenes (necesaria para que se muestren en el reporte)
@app.route('/images/<path:filename>')
def serve_images(filename):
    images_dir = Path.home() / "ForenSage/results/images"
    return send_from_directory(images_dir, filename)


# Accounts Info

@app.route('/ios_accounts')
def ios_accounts():
    # Configurar rutas (mismo patrón que ios_browser_history)
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "IOS_accounts_info.html"
    
    # Ruta al archivo plist
    plist_path = base_dir / "analyze/ios/private/var/mobile/Library/Preferences/com.apple.accountsd.plist"
    
    # Asegurar que el directorio de resultados existe
    os.makedirs(results_dir, exist_ok=True)
    
    # Analizar el archivo plist
    datos, estructura, existe = analizar_accounts_plist(str(plist_path))
    
    # Generar el informe HTML
    generar_html_AccountsInfo(
        datos,
        estructura,
        (str(plist_path), existe),
        str(output_html)
    )
    
    # Servir el HTML generado
    return send_from_directory(results_dir, "IOS_accounts_info.html")



# Icons Info

@app.route('/ios_homescreen')
def ios_homescreen():  
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "iOS_HomeScreen_Analysis.html"

    rutas_posibles = [
        base_dir / "analyze/ios/private/var/mobile/Library/SpringBoard/IconState.plist",
        base_dir / "extract/ios/private/var/mobile/Library/SpringBoard/IconState.plist",
        base_dir / "data/ios/private/var/mobile/Library/SpringBoard/IconState.plist"
    ]
    
    rutas_str = [str(ruta) for ruta in rutas_posibles]
    
    os.makedirs(results_dir, exist_ok=True)
    
    datos, archivo_encontrado, ruta_usada = analizar_iconstate_plist(rutas_str)

    generar_html_simplificado(
        datos,
        ruta_usada if archivo_encontrado else "Archivo no encontrado",
        str(output_html)
    )
    
    return send_from_directory(results_dir, "iOS_HomeScreen_Analysis.html")


# Files Info

@app.route('/ios_file_info')
def ios_downloads():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "IOS_downloads_report.html"
    
    downloads_path = base_dir / "analyze/ios/private/var/mobile/Library/Mobile Documents/com~apple~CloudDocs/Downloads/"
    
    os.makedirs(results_dir, exist_ok=True)
    
    file_data, extensions_data, total_size, folder_exists = analyze_downloads_folder(str(downloads_path))
    
    generate_html_files(
        file_data,
        extensions_data,
        total_size,
        (str(downloads_path), folder_exists),
        str(output_html)
    )
    
    return send_from_directory(results_dir, "IOS_downloads_report.html")



#Contacts Info

@app.route('/ios_contacts')
def ios_contacts():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "IOS_contacts_report.html"
    
    contacts_db_path = base_dir / "analyze/ios/private/var/mobile/Library/AddressBook/AddressBook.sqlitedb"

    os.makedirs(results_dir, exist_ok=True)

    datos, existe = analyze_addressbook_db(str(contacts_db_path))

    generate_html_AddressBookAnalysis(
        datos,
        (str(contacts_db_path), existe),
        str(output_html)
    )

    return send_from_directory(results_dir, "IOS_contacts_report.html")


@app.route('/analyze_ios_whatsapp')
def analyze_ios_whatsapp():
    """Endpoint para analizar la base de datos de WhatsApp en iOS"""
    # Configuración de rutas
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "IOS_whatsapp.html"
    db_path = base_dir / "analyze/ios/private/var/mobile/Containers/Shared/AppGroup/BAF442BF-69A8-4336-86BC-37604B5C9A7C/ChatStorage.sqlite"
    
    # Asegurar que existen los directorios
    os.makedirs(results_dir, exist_ok=True)
    
    # Verificar si la base de datos existe
    if not db_path.exists():
        return "Base de datos no encontrada", 404
    
    # Conectar a la base de datos
    conn = connect_to_db(db_path)
    if not conn:
        return "Error al conectar a la base de datos", 500
    
    # Realizar análisis
    messages = extract_messages_from_zwamessage(conn)
    conn.close()
    
    # Generar reporte HTML (usa tu función original)
    generate_html_report(messages, output_html)
    
    # Servir el archivo generado
    return send_from_directory(results_dir, "IOS_whatsapp.html")

# -------------------- Import Scripts Amazon Echo / Importar Scripts Amazon Echo --------------------

from scripts.amecho.amecho_device_info import analyze_xml_files, generate_html_report
from scripts.amecho.amecho_wifi_info import analyze_wifi_config, generate_amecho_wifi_html
from scripts.amecho.amecho_images_info import analyze_images, generate_amecho_images_html
from scripts.amecho.amecho_device_name import analyze_device_name, generate_amecho_name_html
from scripts.amecho.amecho_accounts_info import analyze_sqlite_database, generate_amecho_accounts_html
from scripts.amecho.amecho_user_info import analyze_xml_file, generate_amecho_user_html
from scripts.amecho.amecho_bt_info import analyze_bt_config, generate_amecho_bt_html
from scripts.amecho.amecho_url_info import analyze_history_database, generate_amecho_url_html
from scripts.amecho.amecho_search_info import analyze_history_database2, generate_amecho_search_html


# -------------------- SCRIPTS AMAZON ECHO  --------------------

#Device Info


@app.route('/amecho_device_info')
def amecho_divice_info():

    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "amecho_divice_info.html"
    prefs_path = base_dir / "/media/adrian/data/data/com.android.settings/shared_prefs"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results, directory_exists = analyze_xml_files(str(prefs_path))
    
    generate_html_report(
        results,
        (str(prefs_path), directory_exists),
        str(output_html)
    )
    return send_from_directory(results_dir, "amecho_divice_info.html")



#Image Info

@app.route('/analyze_echo_images')
def analyze_echo_images():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "amecho_images_info.html"
    
    images_dir = "/media/adrian/data/system_ce/0/snapshots"
    
    os.makedirs(results_dir, exist_ok=True)
    results, dir_exists = analyze_images(images_dir)
    generate_amecho_images_html(
        results,
        (images_dir, dir_exists),
        str(output_html)
    )
    return send_from_directory(results_dir, "amecho_images_info.html")

#Wifi Info

@app.route('/amecho_wifi')
def echo_wifi():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "Echo_WiFi_Report.html"
    
    wifi_config = base_dir / "analyze/amecho/WifiConfigStore.xml"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results, file_exists = analyze_wifi_config(str(wifi_config))
    
    generate_amecho_wifi_html(
        results,
        str(wifi_config), 
        str(output_html)
    )
    return send_from_directory(results_dir, "Echo_WiFi_Report.html")


#Device Name

@app.route('/amecho_device_name')
def amecho_device_name():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "amecho_device_name.html"
    xml_path = base_dir / "analyze/amecho/deviceNameSharedPref.xml"
    
    os.makedirs(results_dir, exist_ok=True)

    result = analyze_device_name(xml_path)
    
    generate_amecho_name_html(result, str(xml_path), str(output_html))   
    return send_from_directory(results_dir, "amecho_device_name.html")



#Accounts

@app.route('/amecho_accounts')
def amecho_accounts_db():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "amecho_accounts_info.html"
    db_path = base_dir / "analyze/amecho/accounts_ce.db"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results, db_exists = analyze_sqlite_database(str(db_path))
    
    generate_amecho_accounts_html(results, (str(db_path), db_exists), str(output_html))
    
    return send_from_directory(results_dir, "amecho_accounts_info.html")



#User Info

@app.route('/amecho_user_info')
def amecho_user():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "amecho_user_info.html"
    xml_path = base_dir / "analyze/amecho/0.xml"
    
    os.makedirs(results_dir, exist_ok=True)
    
    file_data, success = analyze_xml_file(xml_path)
    
    print(f"Analyzing: {xml_path}")
    print(f"Extracted data: {len(file_data)} elements")
    if success and file_data:
        print("First 5 elements found:")
        for i, (key, value) in enumerate(list(file_data.items())[:5]):
            print(f"- {key}: {value}")
    generate_amecho_user_html(file_data, str(xml_path), str(output_html))
    
    return send_from_directory(results_dir, "amecho_user_info.html")



#bt info

@app.route('/amecho_bt')
def amecho_bluetooth():
    # Use exact paths from your script
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "amecho_bt_info.html"
    bt_config_path = base_dir / "analyze/amecho/bt_config.conf"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results, file_exists = analyze_bt_config(bt_config_path)
    
    generate_amecho_bt_html(
        results, 
        (str(bt_config_path), file_exists), 
        str(output_html)
    )
    return send_from_directory(results_dir, "amecho_bt_info.html")



#url info

@app.route('/amecho_url')
def amecho_url_history():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "amecho_url_info.html"
    db_path = base_dir / "analyze/amecho/History"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results, success = analyze_history_database(str(db_path))
    
    if success:
        generate_amecho_url_html(results, str(db_path), str(output_html))
        if os.path.exists(output_html):
            return send_from_directory(str(results_dir), "amecho_url_info.html")
        else:
            return "Error: No se pudo generar el informe HTML", 500
    else:
        return f"Error: No se pudo analizar la base de datos en {db_path}", 500


#serch info

@app.route('/amecho_search')
def amecho_browser_history():
    # Use exact paths from your script
    base_dir = Path.home() /"ForenSage"
    results_dir = base_dir /"results"
    output_html = results_dir /"amecho_search_info.html"
    db_path = base_dir / "analyze/amecho/History"
    
    os.makedirs(results_dir, exist_ok=True)

    results, db_exists = analyze_history_database2(str(db_path))
    
    generate_amecho_search_html(results, (str(db_path), db_exists), str(output_html))
    
    return send_from_directory(results_dir, "amecho_search_info.html")


# -------------------- Import Scripts Drone / Importar Scripts Drone --------------------

from scripts.drone.drone_fligths_record import analyze_txt_files, generate_flight_records_html
from scripts.drone.drone_video_record import analyze_media_files, generate_video_records_html
from scripts.drone.drone_images_info import analyze_cache_images, generate_drone_images_html
from scripts.drone.drone_device_info import analyze_property_files, generate_property_analysis_html
from scripts.drone.drone_errorlog_info import analyze_error_logs, generate_error_log_report
from scripts.drone.drone_log_info import analyze_dji_log_cache, generate_log_html


# -------------------- SCRIPTS DRONE --------------------

@app.route('/drone_flight_records')
def drone_flight_records():

    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "drone_flights_record.html"
    flight_dir = base_dir / "analyze/drone/sdcard/DJI/dji.go.v4/FlightRecord/"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results, dir_exists = analyze_txt_files(str(flight_dir))
    
    generate_flight_records_html(results, (str(flight_dir), dir_exists), str(output_html))
    return send_from_directory(results_dir, "drone_flights_record.html")
        
        
@app.route('/drone_video_records')
def dji_media_analysis():

    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "drone_media_analysis.html"
    media_dir = base_dir / "analyze/drone/sdcard/DJI/dji.go.v4/DJI_RECORD/"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results, dir_exists = analyze_media_files(str(media_dir))
    
    generate_video_records_html(results, (str(media_dir), dir_exists), str(output_html))
    return send_from_directory(results_dir, "drone_media_analysis.html")


@app.route('/drone_images_info')
def analyze_drone_images():
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "drone_images_info.html"
    images_dir = base_dir / "analyze/drone/sdcard/DJI/dji.go.v4/CACHE_IMAGE"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results, dir_exists = analyze_cache_images(images_dir)
    
    generate_drone_images_html(
        results,
        (str(images_dir), dir_exists),
        str(output_html)
    )
    return send_from_directory(results_dir, "drone_images_info.html")



@app.route('/drone_device_info')
def analyze_drone_properties():
    """Endpoint para analizar las propiedades del dron (serial number y hostname)"""
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "drone_device_info.html"
    
    serialno_path = base_dir / "analyze/drone/property/ro.serialno"
    hostname_path = base_dir / "analyze/drone/property/net.hostname"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results, success = analyze_property_files(serialno_path, hostname_path)
    
    generate_property_analysis_html(results, output_html)
    
    return send_from_directory(results_dir, "drone_device_info.html")



@app.route('/analyze_drone_error_logs')
def analyze_drone_error_logs():
    """Endpoint para analizar los logs de error del dron DJI"""
    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "drone_errorlog_info.html"
    log_dir = base_dir / "analyze/drone/sdcard/DJI/dji.pilot/LOG/ERROR_POP_LOG"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results, success = analyze_error_logs(log_dir)
    
    if success:
        generate_error_log_report(results, output_html)
        return send_from_directory(results_dir, "drone_errorlog_info.html")
    else:
        return "Error al analizar los logs", 500
    


@app.route('/drone_log_info')
def analyze_dji_logs():
    """Endpoint para analizar los logs de DJI"""

    base_dir = Path.home() / "ForenSage"
    results_dir = base_dir / "results"
    output_html = results_dir / "drone_log_info.html"
    log_dir = base_dir / "analyze/drone/sdcard/DJI/dji.pilot/LOG/CACHE"
    
    os.makedirs(results_dir, exist_ok=True)
    
    results = analyze_dji_log_cache(log_dir)
    
    generate_log_html(results, output_html)
    
    return send_from_directory(results_dir, "drone_log_info.html")


if __name__ == '__main__':
    app.run(debug=True)